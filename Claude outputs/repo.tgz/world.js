      (function () {
        // === Time-scaling: speed multiplier affects ALL entities ===
        // setTimeout/setInterval delays are divided by current speed at call time,
        // CSS transitions get playbackRate set via a polling interval.
        const SPEED_OPTIONS = [1, 2, 3];
        let speedIdx = 0;
        function getSpeed() { return SPEED_OPTIONS[speedIdx]; }
        const _setTimeout  = window.setTimeout.bind(window);
        const _setInterval = window.setInterval.bind(window);
        const setTimeout  = (fn, ms, ...rest) => _setTimeout(fn, (ms || 0) / getSpeed(), ...rest);
        const setInterval = (fn, ms, ...rest) => _setInterval(fn, (ms || 0) / getSpeed(), ...rest);

        const world = document.querySelector(".world");
        const peopleLayer = world.querySelector(".people-layer");
        const dragonsLayer = world.querySelector(".dragons-layer");
        const treesLayer = world.querySelector(".trees-layer");
        const backTreesLayer = world.querySelector(".back-trees-layer");
        const hillTreesFarLayer = world.querySelector(".hill-trees-far");
        const hillTreesNearLayer = world.querySelector(".hill-trees-near");
        const cloudsLayer = world.querySelector(".clouds-layer");
        const skyLifeLayer = world.querySelector(".sky-life-layer");
        const tracksLayer = world.querySelector(".tracks-layer");
        const groundDecorLayer = world.querySelector(".ground-decor-layer");
        const ambientParticleLayer = world.querySelector(".ambient-particle-layer");
        const lightning = world.querySelector(".lightning");
        const hudTime = document.getElementById("hud-time");
        const hudWeather = document.getElementById("hud-weather");
        const hudSeason = document.getElementById("hud-season");
        const hudUi = document.getElementById("hud-ui");
        const logEl = document.getElementById("log");
        const heroSeason = document.getElementById("hero-season");
        const heroWeather = document.getElementById("hero-weather");
        const heroTime = document.getElementById("hero-time");
        const heroWorldEvents = document.getElementById("hero-world-events");
        const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;

        // Forward declaration — referenced by tickRain before season setup runs
        let currentSeason = "summer";

        // Continuously ensure all in-flight CSS animations match current speed.
        // At 1× (the default), no work needed — skip the per-animation loop entirely.
        function applySpeedToAnimations() {
          if (document.hidden || typeof document.getAnimations !== "function") return;
          const s = getSpeed();
          if (s === 1) return;
          document.getAnimations().forEach((a) => { try { if (a.playbackRate !== s) a.playbackRate = s; } catch (e) {} });
        }
        _setInterval(applySpeedToAnimations, 1000);

        const W = () => (world && world.offsetWidth) || innerWidth;
        const H = () => innerHeight;

        /* ============= LOG ============= */
        const MAX_LOG = 5;
        function logEvent(text, kind = "") {
          if (document.hidden) return;
          if (heroWorldEvents && heroWorldEvents.textContent !== text) heroWorldEvents.textContent = text;
          const e = document.createElement("div");
          e.className = "log-entry" + (kind ? " " + kind : "");
          e.textContent = text;
          logEl.appendChild(e);
          // cap entries
          const entries = logEl.querySelectorAll(".log-entry");
          if (entries.length > MAX_LOG) entries[0].remove();
          setTimeout(() => { if (e.isConnected) e.remove(); }, 16000);
        }

        /* ============= DAY / NIGHT (continuous interpolation) ============= */
        const phases = ["dawn", "day", "dusk", "night"];
        const phaseLabels = { dawn: "DAWN", day: "DAY", dusk: "DUSK", night: "NIGHT" };
        const phaseLog = {
          dawn: "Dawn breaks across the realm.",
          day: "The sun climbs high.",
          dusk: "Dusk paints the horizon.",
          night: "Night falls. Stars wake.",
        };

        const palette = {
          dawn:  { skyTop:"#333a61", skyMid:"#8b7189", skyBot:"#d3948d",
                   cloudL:"#d8c9cc", cloudD:"#a994a4",
                   sun:"#e6a39a", sunGlow:"rgba(224,143,148,0.40)",
                   sunO:0.65, moonO:0.25, starsO:0.4, bright:0.78 },
          day:   { skyTop:"#4e6287", skyMid:"#9299ad", skyBot:"#c48d94",
                   cloudL:"#d9d8d8", cloudD:"#a6adbd",
                   sun:"#e5b3a2", sunGlow:"rgba(220,151,156,0.38)",
                   sunO:1, moonO:0, starsO:0, bright:1 },
          dusk:  { skyTop:"#292e58", skyMid:"#735473", skyBot:"#ba707b",
                   cloudL:"#b4879a", cloudD:"#73576d",
                   sun:"#dc8f8d", sunGlow:"rgba(210,111,132,0.4)",
                   sunO:0.6, moonO:0.25, starsO:0.3, bright:0.78 },
          night: { skyTop:"#0c1025", skyMid:"#202344", skyBot:"#3b3152",
                   cloudL:"#2a2438", cloudD:"#14101e",
                   sun:"#1a1428", sunGlow:"rgba(20,16,32,0)",
                   sunO:0, moonO:0.95, starsO:0.95, bright:0.45 },
        };

        const BASE_DAY_LENGTH_MS = 120000;
        let dayLengthMs = BASE_DAY_LENGTH_MS;
        let dayStart = performance.now() - 0.34 * dayLengthMs; // visible afternoon sun, then dusk
        let manualOverride = null; // { startTime, fromT, toT, duration }

        // Time speed multiplier (SPEED_OPTIONS / speedIdx / getSpeed defined at top)
        const hudSpeed = document.getElementById("hud-speed");
        function cycleSpeed() {
          // Preserve current t when changing speed
          const currentT = computeT();
          speedIdx = (speedIdx + 1) % SPEED_OPTIONS.length;
          const newSpeed = SPEED_OPTIONS[speedIdx];
          dayLengthMs = BASE_DAY_LENGTH_MS / newSpeed;
          dayStart = performance.now() - currentT * dayLengthMs;
          hudSpeed.textContent = newSpeed + "×";
          // Immediately scale all in-flight CSS transitions/animations
          applySpeedToAnimations();
          logEvent("Time flows at " + newSpeed + "× speed.", "time");
        }
        hudSpeed.addEventListener("click", cycleSpeed);
        function setUiHidden(hidden) {
          document.body.classList.toggle("ui-hidden", hidden);
          document.querySelector(".site-shell").inert = hidden;
          const dock = document.querySelector(".hud");
          dock.inert = !hidden && dock.classList.contains("is-offscreen");
          logEl.setAttribute("aria-hidden", String(!hidden));
          hudUi.innerHTML = hidden ? '↩ <span>Return to page</span>' : '↗ <span>Explore</span>';
          hudUi.title = hidden ? "Return to page" : "Explore the world";
          hudUi.setAttribute("aria-label", hudUi.title);
          hudUi.setAttribute("aria-pressed", String(hidden));
          if (hidden) hudUi.focus();
        }
        hudUi.addEventListener("click", () => setUiHidden(!document.body.classList.contains("ui-hidden")));
        const heroForDock = document.querySelector(".hero");
        if (heroForDock && "IntersectionObserver" in window) {
          new IntersectionObserver(([entry]) => {
            const dock = document.querySelector(".hud");
            dock.classList.toggle("is-offscreen", !entry.isIntersecting);
            dock.inert = !entry.isIntersecting && !document.body.classList.contains("ui-hidden");
          }, { threshold: 0 }).observe(heroForDock);
        }
        for (const id of ["explore-world", "realm-enter"]) {
          document.getElementById(id)?.addEventListener("click", () => setUiHidden(true));
        }
        document.addEventListener("keydown", (event) => {
          if (event.key === "Escape" && document.body.classList.contains("ui-hidden")) setUiHidden(false);
        });

        const hudDim = document.getElementById("hud-dim");
        if (hudDim) {
          hudDim.addEventListener("click", () => {
            const dimmed = document.body.classList.toggle("dim-world");
            hudDim.setAttribute("aria-pressed", String(dimmed));
          });
        }

        const worldPanReset = document.getElementById("world-pan-reset");
        if (world && worldPanReset) {
          const THRESHOLD = 24;
          function maxPan() {
            return Math.max(0, world.offsetWidth - window.innerWidth);
          }
          function centerPan() {
            // Put the first castle beside the desktop introduction so the
            // living village reads as a destination, not a footer decoration.
            return maxPan() * (window.innerWidth >= 1050 ? 0.2 : 0.5);
          }
          let panCenter = centerPan();
          let worldPanX = panCenter;
          let startX = 0, startY = 0, startPan = 0, axis = null, dragging = false;

          function applyWorldPan() {
            world.style.transform = `translateX(${-worldPanX}px)`;
            document.body.style.setProperty("--world-pan-x", worldPanX + "px");
            const visible = Math.abs(worldPanX - centerPan()) > THRESHOLD;
            worldPanReset.classList.toggle("visible", visible);
            worldPanReset.inert = !visible;
          }
          function resetWorldPan() {
            worldPanX = centerPan();
            applyWorldPan();
          }
          applyWorldPan();
          function isOnBackground(target) {
            if (!target) return true;
            return !target.closest(".container, .hud, .world-pan-reset, .log");
          }
          function pointFromEvent(e) {
            if (e.touches && e.touches.length) return e.touches[0];
            if (e.changedTouches && e.changedTouches.length) return e.changedTouches[0];
            return e;
          }
          function onWorldDragStart(e, isTouch) {
            if (maxPan() <= 0) return;
            if (!isTouch && !isOnBackground(e.target)) return;
            const p = pointFromEvent(e);
            startX = p.clientX;
            startY = p.clientY;
            startPan = worldPanX;
            axis = null;
            dragging = true;
            world.classList.add("is-panning");
          }
          function onWorldDragMove(e) {
            if (!dragging) return;
            const p = pointFromEvent(e);
            const dx = p.clientX - startX;
            const dy = p.clientY - startY;
            if (axis === null) {
              if (Math.abs(dx) < 5 && Math.abs(dy) < 5) return;
              axis = Math.abs(dx) > Math.abs(dy) ? "x" : "y";
            }
            if (axis === "x") {
              if (e.cancelable) e.preventDefault();
              worldPanX = Math.max(0, Math.min(maxPan(), startPan - dx));
              applyWorldPan();
            } else {
              dragging = false;
              world.classList.remove("is-panning");
            }
          }
          function onWorldDragEnd() {
            dragging = false;
            axis = null;
            world.classList.remove("is-panning");
          }
          document.addEventListener("touchstart", (e) => {
            if (isOnBackground(e.target)) onWorldDragStart(e, true);
          }, { passive: true });
          document.addEventListener("touchmove", onWorldDragMove, { passive: false });
          document.addEventListener("touchend", onWorldDragEnd, { passive: true });
          document.addEventListener("touchcancel", onWorldDragEnd, { passive: true });
          document.addEventListener("mousedown", (e) => onWorldDragStart(e, false));
          document.addEventListener("mousemove", (e) => { if (dragging) onWorldDragMove(e); });
          document.addEventListener("mouseup", onWorldDragEnd);
          worldPanReset.addEventListener("click", resetWorldPan);
          function recenterAfterResize() {
            const nextCenter = centerPan();
            worldPanX = Math.abs(worldPanX - panCenter) <= THRESHOLD
              ? nextCenter
              : Math.max(0, Math.min(maxPan(), worldPanX));
            panCenter = nextCenter;
            applyWorldPan();
          }
          let panResizeFrame = 0;
          window.addEventListener("resize", () => {
            cancelAnimationFrame(panResizeFrame);
            panResizeFrame = requestAnimationFrame(recenterAfterResize);
          });
          // CSS breakpoints can change the world width after a viewport resize.
          // Observe the actual world box so a centered camera stays centered.
          if ("ResizeObserver" in window) new ResizeObserver(recenterAfterResize).observe(world);
        }

        const hudSettings = document.getElementById("hud-settings");
        const hudSettingsWrap = document.getElementById("hud-settings-wrap");
        const hudSettingsMenu = document.getElementById("hud-settings-menu");
        if (hudSettings && hudSettingsWrap && hudSettingsMenu) {
          function setSettingsOpen(open) {
            hudSettingsWrap.classList.toggle("open", open);
            hudSettings.setAttribute("aria-expanded", String(open));
            hudSettingsMenu.setAttribute("aria-hidden", String(!open));
          }
          hudSettings.addEventListener("click", (e) => {
            e.stopPropagation();
            setSettingsOpen(!hudSettingsWrap.classList.contains("open"));
          });
          document.addEventListener("click", (e) => {
            if (!hudSettingsWrap.classList.contains("open")) return;
            if (hudSettingsWrap.contains(e.target)) return;
            setSettingsOpen(false);
          });
          document.addEventListener("keydown", (e) => {
            if (e.key === "Escape" && hudSettingsWrap.classList.contains("open")) {
              setSettingsOpen(false);
              hudSettings.focus();
            }
          });
        }

        const hexRgb = (h) => { const v = parseInt(h.slice(1),16); return [(v>>16)&255,(v>>8)&255,v&255]; };
        const rgbStr = (c) => `rgb(${c[0]|0}, ${c[1]|0}, ${c[2]|0})`;
        const mix = (a,b,t) => a + (b-a)*t;
        const mixRgb = (a,b,t) => [mix(a[0],b[0],t), mix(a[1],b[1],t), mix(a[2],b[2],t)];
        const smooth = (t) => t*t*(3-2*t);

        const parseColor = (c) => {
          if (c.startsWith("#")) { const r = hexRgb(c); return [r[0],r[1],r[2],1]; }
          const m = c.match(/rgba?\(([^)]+)\)/); if (!m) return [0,0,0,0];
          const p = m[1].split(",").map((s)=>parseFloat(s));
          return [p[0],p[1],p[2], p[3] == null ? 1 : p[3]];
        };
        const rgbaStr = (c) => `rgba(${c[0]|0}, ${c[1]|0}, ${c[2]|0}, ${c[3].toFixed(3)})`;
        const mixRgba = (a,b,t) => [mix(a[0],b[0],t), mix(a[1],b[1],t), mix(a[2],b[2],t), mix(a[3],b[3],t)];

        const pp = {};
        for (const k in palette) {
          pp[k] = {
            skyTop: hexRgb(palette[k].skyTop),
            skyMid: hexRgb(palette[k].skyMid),
            skyBot: hexRgb(palette[k].skyBot),
            cloudL: hexRgb(palette[k].cloudL),
            cloudD: hexRgb(palette[k].cloudD),
            sun: hexRgb(palette[k].sun),
            sunGlow: parseColor(palette[k].sunGlow),
            sunO: palette[k].sunO,
            moonO: palette[k].moonO,
            starsO: palette[k].starsO,
            bright: palette[k].bright,
          };
        }

        let lastHudPhase = "";

        // Cache last-written values so updateDay only writes when a value actually changed.
        // Quantize numerics to ~0.02 steps so close interpolations dedupe to the same string.
        const dayCache = Object.create(null);
        const q = (n) => Math.round(n * 50) / 50;
        function setVar(name, value) {
          if (dayCache[name] === value) return;
          dayCache[name] = value;
          // These variables are only consumed inside the world. Keeping them on
          // this subtree avoids restyling every card and control four times a second.
          world.style.setProperty(name, value);
        }

        function computeT() {
          if (manualOverride) {
            const elapsed = performance.now() - manualOverride.startTime;
            if (elapsed >= manualOverride.duration) {
              const finalT = manualOverride.toT;
              dayStart = performance.now() - finalT * dayLengthMs;
              manualOverride = null;
              return finalT;
            }
            const p = elapsed / manualOverride.duration;
            const ep = smooth(p);
            // shortest signed delta on a circular [0,1)
            let delta = manualOverride.toT - manualOverride.fromT;
            if (delta > 0.5) delta -= 1;
            else if (delta < -0.5) delta += 1;
            return ((manualOverride.fromT + delta * ep) % 1 + 1) % 1;
          }
          return ((performance.now() - dayStart) % dayLengthMs) / dayLengthMs;
        }

        function updateDay() {
          if (document.hidden) return;
          const t = computeT();
          const pf = t * phases.length;
          const i = Math.floor(pf) % phases.length;
          const frac = smooth(pf - Math.floor(pf));
          const cur = phases[i];
          const nxt = phases[(i + 1) % phases.length];
          const a = pp[cur], b = pp[nxt];

          setVar("--sky-top", rgbStr(mixRgb(a.skyTop, b.skyTop, frac)));
          setVar("--sky-mid", rgbStr(mixRgb(a.skyMid, b.skyMid, frac)));
          setVar("--sky-bot", rgbStr(mixRgb(a.skyBot, b.skyBot, frac)));
          setVar("--cloud-light", rgbStr(mixRgb(a.cloudL, b.cloudL, frac)));
          setVar("--cloud-dark",  rgbStr(mixRgb(a.cloudD, b.cloudD, frac)));
          setVar("--sun-color",   rgbStr(mixRgb(a.sun, b.sun, frac)));
          setVar("--sun-glow",    rgbaStr(mixRgba(a.sunGlow, b.sunGlow, frac)));
          setVar("--sun-opacity", q(mix(a.sunO, b.sunO, frac)).toFixed(2));
          setVar("--moon-opacity", q(mix(a.moonO, b.moonO, frac)).toFixed(2));
          setVar("--stars-opacity", q(mix(a.starsO, b.starsO, frac)).toFixed(2));
          setVar("--world-brightness", q(mix(a.bright, b.bright, frac)).toFixed(2));

          if (t < 0.625) {
            const sp = t / 0.625;
            setVar("--sun-x", (Math.round((5 + sp * 90) * 2) / 2) + "%");
            setVar("--sun-y", (Math.round((50 - Math.sin(sp * Math.PI) * 40) * 2) / 2) + "%");
          }
          if (t >= 0.5) {
            const mp = (t - 0.5) / 0.5;
            setVar("--moon-x", (Math.round((5 + mp * 90) * 2) / 2) + "%");
            setVar("--moon-y", (Math.round((50 - Math.sin(mp * Math.PI) * 40) * 2) / 2) + "%");
          }

          const labelPhase = frac < 0.5 ? cur : nxt;
          if (labelPhase !== lastHudPhase) {
            lastHudPhase = labelPhase;
            world.dataset.time = labelPhase;
            hudTime.textContent = phaseLabels[labelPhase];
            if (heroTime) heroTime.textContent = phaseLabels[labelPhase];
            // Atmospheric effects only make sense by day — strip at night
            if (labelPhase === "night") {
              world.classList.remove("has-rainbow");
              world.classList.remove("has-halo");
            }
            // Adventurer camps strike at dawn
            if (labelPhase === "dawn") {
              activeCamps.slice().forEach((c) => c.endCamp());
              advanceDayOfYear();
            }
            // only log natural transitions (not manual overrides)
            if (!manualOverride) logEvent(phaseLog[labelPhase], "time");
          }
        }

        if (!reduced) {
          updateDay();
          // 250ms (~4Hz) is plenty for sky-color interpolation — used to be 66ms (~15Hz),
          // which forced re-rasterization of every filter-affected entity 15× per second.
          setInterval(updateDay, 250);
        } else {
          world.dataset.time = "day"; hudTime.textContent = "DAY";
          if (heroTime) heroTime.textContent = "DAY";
        }

        /* ============= SEASONS ============= */
        const seasons = ["spring", "summer", "autumn", "winter"];
        const seasonLabels = { spring: "SPRING", summer: "SUMMER", autumn: "AUTUMN", winter: "WINTER" };
        const seasonLog = {
          spring: "Spring arrives. Buds return to the branches.",
          summer: "Summer takes hold.",
          autumn: "Autumn settles in. Leaves blaze gold.",
          winter: "Winter falls. Snow begins to dust the realm.",
        };
        const SEASON_DAYS = 2;
        let dayOfYear = seasons.indexOf("summer") * SEASON_DAYS;
        world.dataset.season = currentSeason;
        hudSeason.textContent = seasonLabels[currentSeason];
        if (heroSeason) heroSeason.textContent = seasonLabels[currentSeason];

        function setSeason(s, isManual) {
          if (s === currentSeason) return;
          currentSeason = s;
          world.dataset.season = s;
          hudSeason.textContent = seasonLabels[s];
          if (heroSeason) heroSeason.textContent = seasonLabels[s];
          logEvent(seasonLog[s], "time");
          if (isManual) dayOfYear = seasons.indexOf(s) * SEASON_DAYS;
          scheduleAmbientRefresh(120);
          if (typeof ensureRainRaf === "function") ensureRainRaf();
        }
        function advanceDayOfYear() {
          if (reduced) return;
          dayOfYear = (dayOfYear + 1) % (seasons.length * SEASON_DAYS);
          const next = seasons[Math.floor(dayOfYear / SEASON_DAYS)];
          if (next !== currentSeason) setSeason(next, false);
        }
        hudSeason.addEventListener("click", () => {
          const i = seasons.indexOf(currentSeason);
          setSeason(seasons[(i + 1) % seasons.length], true);
        });

        /* ============= WEATHER ============= */
        const weatherTransitions = {
          clear: ["clear", "clear", "cloudy"],
          cloudy: ["clear", "cloudy", "rain"],
          rain: ["cloudy", "rain", "storm"],
          storm: ["rain", "cloudy"],
        };
        const weatherLabels = { clear:"CLEAR", cloudy:"CLOUDY", rain:"RAIN", storm:"STORM" };
        const weatherLog = {
          clear: "The clouds drift away. Skies clear.",
          cloudy: "Clouds gather overhead.",
          rain: "Rain begins to fall. Villagers run for shelter!",
          storm: "A storm rolls in. Lightning splits the sky!",
        };
        let weather = "clear";
        if (heroWeather) heroWeather.textContent = weatherLabels[weather];

        function setWeather(w, manual = false) {
          if (w === weather) return;
          const old = weather;
          weather = w;
          if (manual) {
            world.classList.add("manual-weather");
            setTimeout(() => world.classList.remove("manual-weather"), 1800);
          }
          world.dataset.weather = w;
          syncWeatherAftermath(old, w);
          hudWeather.textContent = weatherLabels[w];
          if (heroWeather) heroWeather.textContent = weatherLabels[w];
          const weatherMessage = currentSeason === "winter" && w === "rain"
            ? "Snow begins to fall across the realm."
            : currentSeason === "winter" && w === "storm"
              ? "A blizzard rolls in. Villagers seek shelter!"
              : weatherLog[w];
          logEvent(weatherMessage, "weather");
          if (w === "storm") scheduleLightning();
          if ((w === "rain" || w === "storm") && !(old === "rain" || old === "storm")) {
            fleeFromWeather();
            const liveCamps = houses.filter((h) => h.kind === "campfire" && h.stage >= 2);
            if (liveCamps.length > 0) {
              logEvent("The rain hisses on the campfires, dousing the flames.", "weather");
            }
          }
          // Campfires rekindle when rain clears
          if ((old === "rain" || old === "storm") && !(w === "rain" || w === "storm")) {
            const wetCamps = houses.filter((h) => h.kind === "campfire" && h.stage >= 2);
            if (wetCamps.length > 0) {
              logEvent("The campfires sputter back to life.", "good");
            }
          }
          // Seed extra clouds when going overcast — sparse for cloudy, heavy for rain/storm
          if ((w === "cloudy" || w === "rain" || w === "storm") && (old === "clear" || (old === "cloudy" && (w === "rain" || w === "storm")))) {
            const count = w === "storm" ? 28 : w === "rain" ? 16 : 3;
            for (let i = 0; i < count; i++) setTimeout(() => randomCloud(), i * 35);
          }
          // Rainbow when transitioning from wet to dry — but only when not night
          if ((old === "rain" || old === "storm") && (w === "clear" || w === "cloudy")) {
            const curPhase = world.dataset.time || "day";
            if (curPhase !== "night") {
              world.classList.add("has-rainbow");
              logEvent("A rainbow arcs across the sky.", "good");
              setTimeout(() => world.classList.remove("has-rainbow"), 22000);
            }
          }
        }
        function cycleWeather() {
          const choices = weatherTransitions[weather];
          const next = choices[Math.floor(Math.random() * choices.length)];
          setWeather(next, false);
          setTimeout(cycleWeather, 22000 + Math.random() * 22000);
        }
        function scheduleLightning() {
          if (weather !== "storm") return;
          setTimeout(() => {
            if (weather !== "storm") return;
            lightning.classList.add("flash");
            setTimeout(() => lightning.classList.remove("flash"), 500);
            logEvent("Lightning strikes!", "weather");
            scheduleLightning();
          }, 4000 + Math.random() * 6000);
        }
        if (!reduced) setTimeout(cycleWeather, 14000);

        // HUD clicks — FAST manual transitions
        hudWeather.addEventListener("click", () => {
          const order = ["clear","cloudy","rain","storm"];
          setWeather(order[(order.indexOf(weather) + 1) % order.length], true);
        });
        hudTime.addEventListener("click", () => {
          const curIdx = phases.indexOf(lastHudPhase || "day");
          const targetT = ((curIdx + 1) % phases.length) / phases.length;
          const curT = computeT();
          manualOverride = { startTime: performance.now(), fromT: curT, toT: targetT, duration: reduced ? 0 : 1500 };
          if (reduced) updateDay();
        });

        /* ============= RAIN CANVAS ============= */
        const canvas = world.querySelector(".rain-canvas");
        const ctx = canvas.getContext("2d");
        let CW, CH;
        let isSmallViewport = false;
        let lastCanvasWidth = 0, lastCanvasHeight = 0, lastCanvasDpr = 0;
        function resize() {
          isSmallViewport = innerWidth < 640;
          // Weather is deliberately pixel-sized; supersampling a 2000px-wide
          // canvas at 2x wasted memory and fill rate with no visible benefit.
          const dpr = Math.min(window.devicePixelRatio || 1, isSmallViewport ? 1 : 1.25);
          CW = W(); CH = innerHeight;
          const pixelWidth = Math.round(CW * dpr);
          const pixelHeight = Math.round(CH * dpr);
          if (pixelWidth === lastCanvasWidth && pixelHeight === lastCanvasHeight && dpr === lastCanvasDpr) return;
          lastCanvasWidth = pixelWidth; lastCanvasHeight = pixelHeight; lastCanvasDpr = dpr;
          canvas.width = pixelWidth; canvas.height = pixelHeight;
          canvas.style.width = CW + "px"; canvas.style.height = CH + "px";
          ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        }
        resize();
        addEventListener("resize", resize);

        /* ============= WORLD RESIZE / RESPONSIVE ============= */
        let lastViewportW = W();
        let resizeTimer = null;
        function repositionWorld() {
          const newW = W();
          if (lastViewportW === 0) lastViewportW = newW;
          const ratio = newW / lastViewportW;
          lastViewportW = newW;
          if (ratio === 1 || isNaN(ratio) || !isFinite(ratio)) return;

          // Stationary entities — keep proportional X
          trees.forEach((t) => {
            t.x = t.x * ratio;
            t.el.style.left = t.x + "px";
          });
          houses.forEach((h) => {
            h.x = h.x * ratio;
            h.el.style.left = h.x + "px";
          });
          crops.forEach((c) => {
            c.x = c.x * ratio;
            c.baseX = c.baseX * ratio;
            c.el.style.left = c.x + "px";
          });
          document.querySelectorAll(".grave, .sign-label").forEach((g) => {
            const oldLeft = parseFloat(g.style.left) || 0;
            g.style.left = (oldLeft * ratio) + "px";
          });

          // Re-target in-flight movers to the new viewport edge so they don't overshoot
          document.querySelectorAll(".person, .horseman, .dragon, .sheep, .dog, .cart").forEach((el) => {
            // For entities currently mid-transition with a left value, just stop them at current spot — they'll naturally despawn.
            // Cleaner: redirect their target to the closer viewport edge.
            const cs = getComputedStyle(el);
            const curLeft = parseFloat(cs.left);
            if (isNaN(curLeft)) return;
            const transDur = parseFloat(cs.transitionDuration) || 0;
            if (transDur > 0) {
              // Pick the closer edge as new target
              const targetX = curLeft < newW / 2 ? -50 : (newW + 50);
              const dist = Math.abs(targetX - curLeft);
              const newDur = Math.min(transDur, dist / 40);
              el.style.transition = `left ${newDur}s linear`;
              el.style.left = targetX + "px";
            }
          });
          scheduleAmbientRefresh(220);
        }
        addEventListener("resize", () => {
          // Debounce — wait until resize settles
          clearTimeout(resizeTimer);
          resizeTimer = setTimeout(repositionWorld, 180);
        });

        const drops = [];
        let wind = 0, windTarget = 0, gustTimer = 0;
        let intensity = 0, intensityTarget = 0;
        const flakes = [];
        let snowIntensity = 0;

        function ensureDrops(n) {
          while (drops.length < n) drops.push({
            x: Math.random() * CW, y: Math.random() * CH,
            speed: 9 + Math.random() * 6,
            len: 7 + Math.random() * 9,
            alpha: 0.35 + Math.random() * 0.35,
          });
        }
        function makeFlake(y = Math.random() * CH) {
          const depthRoll = Math.random();
          const depth = depthRoll < 0.56 ? 0 : depthRoll < 0.88 ? 1 : 2;
          const depthScale = [0.6, 1, 1.45][depth];
          return {
            x: Math.random() * CW,
            y,
            vy: (0.42 + Math.random() * 0.72) * depthScale,
            size: depth === 0 ? 1 : (depth === 1 ? 2 : (Math.random() < 0.55 ? 2 : 3)),
            drift: (0.18 + Math.random() * 0.42) * depthScale,
            wave: 0.016 + Math.random() * 0.018,
            phase: Math.random() * 1000,
            alpha: [0.38, 0.58, 0.78][depth] + Math.random() * 0.16,
          };
        }
        function ensureFlakes(n) {
          while (flakes.length < n) flakes.push(makeFlake());
        }
        let rainRafRunning = false;
        let lastRainFrame = 0;
        function tickRain(frameTime) {
          if (document.hidden) {
            rainRafRunning = false;
            lastRainFrame = 0;
            return;
          }
          rainRafRunning = true;
          // Draw weather at ~30fps and advance it by elapsed time. The rest of
          // the scene remains animated by CSS while this full-width canvas rests.
          if (lastRainFrame && frameTime - lastRainFrame < 32) {
            requestAnimationFrame(tickRain);
            return;
          }
          const frameStep = lastRainFrame ? Math.min(2.5, (frameTime - lastRainFrame) / 16.67) : 1;
          lastRainFrame = frameTime;
          wind += (windTarget - wind) * Math.min(1, 0.02 * frameStep);
          intensity += (intensityTarget - intensity) * Math.min(1, 0.012 * frameStep);
          gustTimer -= frameStep;
          if (gustTimer <= 0 && (intensityTarget > 0 || currentSeason === "winter")) {
            const base = weather === "storm" ? 9 : (currentSeason === "winter" ? 2.6 : 4);
            windTarget = (Math.random() * 2 - 1) * base;
            gustTimer = 120 + Math.random() * 180;
          }

          // Snow ramps independently from rain — driven by season, not weather
          const snowTarget = currentSeason === "winter" ? (weather === "storm" ? 1.12 : 1) : 0;
          snowIntensity += (snowTarget - snowIntensity) * Math.min(1, 0.008 * frameStep);

          ctx.clearRect(0, 0, CW, CH);

          // --- SNOW (winter, regardless of weather) ---
          if (snowIntensity > 0.01) {
            const snowAlpha = Math.min(1, snowIntensity);
            const wantFlakes = Math.floor(snowAlpha * (weather === "storm" ? 118 : 92) * (isSmallViewport ? 0.62 : 1));
            ensureFlakes(wantFlakes);
            for (let i = 0; i < wantFlakes; i++) {
              const f = flakes[i];
              f.y += f.vy * frameStep;
              f.x += (Math.sin((f.y + f.phase) * f.wave) * f.drift + wind * 0.045) * frameStep;
              if (f.y > CH + 8) Object.assign(f, makeFlake(-12 - Math.random() * 40));
              if (f.x > CW + 20) f.x = -10;
              if (f.x < -20) f.x = CW + 10;
              const x = Math.floor(f.x), y = Math.floor(f.y);
              ctx.fillStyle = `rgba(246, 251, 255, ${f.alpha * snowAlpha})`;
              ctx.fillRect(x, y, f.size, f.size);
              if (f.size >= 3) {
                ctx.fillRect(x + 1, y - 1, 1, 1);
                ctx.fillRect(x - 1, y + 1, 1, 1);
              }
            }
          }

          // --- RAIN ---
          if (currentSeason !== "winter" && intensity >= 0.01) {
            const want = Math.floor(intensity * 260 * (isSmallViewport ? 0.6 : 1));
            ensureDrops(want);
            ctx.lineWidth = 1.2; ctx.lineCap = "round";
            for (let i = 0; i < want; i++) {
              const d = drops[i];
              const vx = wind, vy = d.speed;
              d.x += vx * 0.6 * frameStep; d.y += vy * frameStep;
              if (d.y > CH + 10) { d.y = -20; d.x = Math.random() * (CW + 200) - 100; }
              if (d.x > CW + 60) d.x = -40;
              if (d.x < -60) d.x = CW + 40;
              const k = d.len / Math.hypot(vx, vy);
              ctx.strokeStyle = `rgba(190, 210, 240, ${d.alpha * intensity})`;
              ctx.beginPath();
              ctx.moveTo(d.x, d.y); ctx.lineTo(d.x - vx * k, d.y - vy * k);
              ctx.stroke();
            }
          }
          // Pause RAF when there's nothing left to draw — restart on weather/season change.
          const idle = intensity < 0.005 && snowIntensity < 0.005 &&
                       intensityTarget === 0 && snowTarget === 0 &&
                       Math.abs(wind) < 0.05;
          if (idle) {
            rainRafRunning = false;
            lastRainFrame = 0;
            ctx.clearRect(0, 0, CW, CH);
            return;
          }
          requestAnimationFrame(tickRain);
        }
        function ensureRainRaf() {
          if (rainRafRunning || reduced || document.hidden) return;
          rainRafRunning = true;
          requestAnimationFrame(tickRain);
        }
        if (!reduced) ensureRainRaf();
        document.addEventListener("visibilitychange", () => {
          if (!document.hidden) {
            updateDay();
            ensureRainRaf();
          }
        });
        new MutationObserver(() => {
          if (weather === "rain") intensityTarget = 0.55;
          else if (weather === "storm") intensityTarget = 1;
          else intensityTarget = 0;
          ensureRainRaf();
        }).observe(world, { attributes: true, attributeFilter: ["data-weather"] });

        /* ============= CLOUDS ============= */
        // Soft illustrated silhouettes sit in the same visual world as the
        // painted valley, while remaining lightweight animated SVG elements.
        function cloudSVG() {
          const crest = Math.random() > 0.48 ? 14 : 18;
          return `<svg viewBox="0 0 120 48" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <path class="cl-dark" d="M7 35c5-9 14-11 22-9 4-11 16-17 27-14 6-8 20-10 29-3 9-1 20 5 22 15 9 2 14 7 14 15-15 4-31 4-48 4H22C14 43 9 40 7 35Z"/>
            <path class="cl-light" d="M5 32c4-8 15-11 23-8 4-10 15-16 26-13 8-${crest} 23-12 31-3 10-1 18 4 21 14 9 0 15 5 15 12-13 4-28 4-43 4H21C13 38 8 36 5 32Z"/>
            <path d="M16 29c7-5 15-4 21-2 4-9 12-13 22-12m9-1c9-6 19-2 23 7" fill="none" stroke="#fff" stroke-opacity=".24" stroke-width="2" stroke-linecap="round"/>
          </svg>`;
        }

        function randomCloud(initialProgress = 0) {
          const mobileClouds = innerWidth < 640;
          const cloudLimit = weather === "storm" ? (mobileClouds ? 22 : 42)
            : weather === "rain" ? (mobileClouds ? 16 : 30)
            : (mobileClouds ? 9 : 14);
          if (document.hidden || cloudsLayer.childElementCount >= cloudLimit) return;
          const c = document.createElement("div");
          c.className = "cloud";
          c.innerHTML = cloudSVG();
          c.style.top = (4 + Math.random() * 22) + "%";
          const scale = 1.05 + Math.random() * 0.9;
          const fromLeft = Math.random() > 0.5;
          const startX = fromLeft ? -100 : (W() + 30);
          const endX = fromLeft ? (W() + 100) : -100;
          const travel = endX - startX;
          c.style.left = startX + "px";
          c.style.transform = `translateX(${travel * initialProgress}px) scale(${scale})`;
          cloudsLayer.appendChild(c);
          const speed = 8 + Math.random() * 18;
          const dist = Math.abs(endX - startX);
          const dur = dist * (1 - initialProgress) / speed;
          requestAnimationFrame(() => {
            c.style.transition = `transform ${dur}s linear, filter 6s ease, opacity 6s ease`;
            c.style.transform = `translateX(${travel}px) scale(${scale})`;
          });
          setTimeout(() => c.remove(), dur * 1000 + 500);
        }

        function seedClouds(n) {
          for (let i = 0; i < n; i++) {
            setTimeout(() => {
              randomCloud(Math.random() * 0.8);
            }, i * 30);
          }
        }
        if (!reduced) seedClouds(3);

        /* ============= PARTICLES ============= */
        function spawnParticle(x, y, kind = "chip") {
          const p = document.createElement("div");
          p.className = "particle " + kind;
          p.style.left = x + "px";
          p.style.bottom = y + "px";
          const vx = (kind === "dust" ? (Math.random() - 0.5) * 14 : (Math.random() - 0.5) * 36);
          const vy = (kind === "dust" ? -(8 + Math.random() * 10) : -(14 + Math.random() * 20));
          p.style.setProperty("--vx", vx + "px");
          p.style.setProperty("--vy", vy + "px");
          peopleLayer.appendChild(p);
          setTimeout(() => p.remove(), 1000);
        }

        function spawnCoin(x, y) {
          const c = document.createElement("div");
          c.className = "coin";
          c.style.left = x + "px";
          c.style.bottom = y + "px";
          c.style.setProperty("--vx", ((Math.random() - 0.5) * 12) + "px");
          peopleLayer.appendChild(c);
          setTimeout(() => c.remove(), 1500);
        }

        function spawnSparkle(x, y, color = "#c0a0ff") {
          const s = document.createElement("div");
          s.className = "sparkle";
          s.style.left = x + "px";
          s.style.bottom = y + "px";
          s.style.boxShadow = "0 0 4px " + color + ", 0 0 2px #ffffff";
          s.style.setProperty("--vx", ((Math.random() - 0.5) * 24) + "px");
          s.style.setProperty("--vy", -(6 + Math.random() * 14) + "px");
          peopleLayer.appendChild(s);
          setTimeout(() => s.remove(), 1100);
        }

        function spawnSmoke(x, y) {
          const s = document.createElement("div");
          s.className = "smoke";
          s.style.left = x + "px";
          s.style.bottom = y + "px";
          s.style.setProperty("--vx", ((Math.random() - 0.5) * 14) + "px");
          // Insert into dragons-layer so it sits behind cards but above clouds
          dragonsLayer.appendChild(s);
          setTimeout(() => s.remove(), 4600);
        }

        /* ============= ANIMALS ============= */
        function sheepSVG() {
          return `<svg viewBox="0 0 14 10" xmlns="http://www.w3.org/2000/svg">
            <path d="M2 4 1 3l1-2h2L5 0h3l1 1h2l2 2-1 2 1 2-2 2H4L2 8z" fill="#eee9d8"/>
            <path d="M3 2h2l1-1h2l1 1h2M4 5l2-1h3m-4 3h5" fill="none" stroke="#fffdf1" stroke-width="1.1" stroke-linecap="round"/>
            <path d="M4 8h2v2H4zm5 0h2v2H9z" fill="#473a31"/>
            <path d="M1 3 0 4v3l2 1 2-1V4L2 3z" fill="#59463b"/>
            <path d="M0 4 1 3h2" fill="none" stroke="#806758" stroke-width=".7"/>
            <path d="M1 5h1" stroke="#181717" stroke-width=".8"/>
            <path d="M12 5h2" stroke="#eee9d8" stroke-width="1"/>
          </svg>`;
        }
        function dogSVG() {
          return `<svg viewBox="0 0 12 8" xmlns="http://www.w3.org/2000/svg">
            <path d="M2 3 1 2 0 1v3l2 1 1 2h7l1-3-2-2H5z" fill="#9c633b"/>
            <path d="M2 3h5l2 1H3z" fill="#c58b55"/>
            <path d="M3 6h2v2H3zm5 0h2v2H8z" fill="#4c332a"/>
            <path d="M8 3V1l1-1 1 2 2 1v3l-2 1-2-1z" fill="#a66b42"/>
            <path d="M8 1 9 0v3H8z" fill="#594032"/>
            <path d="M11 4h1" stroke="#242020" stroke-width=".8"/>
            <path d="M9 6h2" stroke="#e5bf89" stroke-width=".7"/>
          </svg>`;
        }

        function shepherdSVG() {
          return `<svg viewBox="0 0 12 22" xmlns="http://www.w3.org/2000/svg">
            <rect x="4" y="3" width="4" height="4" fill="#d4a888"/>
            <rect x="4" y="6" width="1" height="1" fill="#1a0a0a"/>
            <rect x="7" y="6" width="1" height="1" fill="#1a0a0a"/>
            <rect x="4" y="2" width="4" height="2" fill="#5a3818"/>
            <rect x="3" y="2" width="1" height="3" fill="#5a3818"/>
            <rect x="8" y="2" width="1" height="3" fill="#5a3818"/>
            <!-- straw hat with wide brim -->
            <rect x="2" y="2" width="8" height="1" fill="#a08010"/>
            <rect x="4" y="0" width="4" height="2" fill="#d4a017"/>
            <rect x="4" y="0" width="4" height="1" fill="#f0c440"/>
            <!-- earthy tunic -->
            <rect x="3" y="8" width="6" height="5" fill="#7a5028"/>
            <rect x="3" y="8" width="6" height="1" fill="#9a6838"/>
            <rect x="2" y="9" width="1" height="4" fill="#7a5028"/>
            <rect x="9" y="9" width="1" height="4" fill="#7a5028"/>
            <rect x="2" y="12" width="1" height="1" fill="#d4a888"/>
            <rect x="9" y="12" width="1" height="1" fill="#d4a888"/>
            <rect x="3" y="13" width="6" height="1" fill="#2a1f15"/>
            <rect x="3" y="14" width="2" height="7" fill="#2a1f15"/>
            <rect x="7" y="14" width="2" height="7" fill="#2a1f15"/>
            <!-- shepherd's crook (long curved staff) -->
            <g class="p-tool">
              <rect x="10" y="-2" width="1" height="16" fill="#5a3818"/>
              <rect x="9" y="-2" width="1" height="1" fill="#5a3818"/>
              <rect x="8" y="-1" width="1" height="2" fill="#5a3818"/>
              <rect x="9" y="0" width="1" height="1" fill="#5a3818"/>
            </g>
          </svg>`;
        }

        function spawnShepherdFlock() {
          if (document.hidden || reduced) return;
          const dir = Math.random() > 0.5 ? "left" : "right";
          const isRainy = weather === "rain" || weather === "storm";
          const dur = isRainy ? (14 + Math.random() * 4) : (55 + Math.random() * 25);

          // Shepherd
          const sh = makePerson("shepherd", dir, { bottom: 6, silent: true });
          sh.innerHTML = shepherdSVG();
          const startX = dir === "left" ? (W() + 20) : -20;
          const endX = dir === "left" ? -20 : (W() + 20);
          sh.style.left = startX + "px";
          requestAnimationFrame(() => {
            sh.style.transition = `left ${dur}s linear`;
            sh.style.left = endX + "px";
          });
          setTimeout(() => sh.remove(), dur * 1000 + 500);

          logEvent("A shepherd guides their hopping flock through the meadow.", "good");

          // Sheep flock (3-6 sheep, mixed adults and lambs) — tight cluster ahead of shepherd
          const flockSize = 3 + Math.floor(Math.random() * 4);
          const sign = dir === "left" ? 1 : -1;
          for (let i = 0; i < flockSize; i++) {
            setTimeout(() => {
              const s = document.createElement("div");
              const isLamb = Math.random() < 0.35;
              s.className = "sheep hopping" + (isLamb ? " lamb" : "");
              s.innerHTML = sheepSVG();
              if (dir === "left") s.style.transform = "scaleX(-1)";
              // Tight cluster: sheep 7px apart in 2 staggered rows, just ahead of shepherd
              const row = i % 2;          // 0 = front row, 1 = back row
              const col = Math.floor(i / 2);
              const baseAhead = 12;       // first sheep is 12px ahead of shepherd
              const colSpacing = 7;       // sheep clustered tight horizontally
              const rowJitter = row === 0 ? 0 : 4;  // back row sits 4px offset
              const offset = sign * (baseAhead + col * colSpacing + rowJitter + (Math.random() - 0.5) * 2);
              s.style.left = (startX + offset) + "px";
              // Tight vertical jitter so sheep cluster reads as a flock
              s.style.bottom = (3 + row * 3 + Math.random() * 3) + "px";
              s.style.animationDelay = (Math.random() * 0.6) + "s";
              peopleLayer.appendChild(s);
              const sheepDur = dur + (Math.random() - 0.5) * 1.5;
              requestAnimationFrame(() => {
                s.style.transition = `left ${sheepDur}s linear`;
                s.style.left = (endX + offset) + "px";
              });
              setTimeout(() => s.remove(), sheepDur * 1000 + 500);
            }, i * 180);
          }
        }

        function spawnSheep() {
          return spawnCrosser({
            cls: "sheep",
            sprite: sheepSVG(),
            y: 3 + Math.random() * 10,
            dur: 60 + Math.random() * 40,
            speed: null, // let dur drive it
            log: Math.random() < 0.4 ? "A sheep grazes the meadow." : null,
          });
        }

        function spawnDog(buddyX, buddyDir) {
          if (document.hidden || reduced) return;
          const dir = buddyDir || pickDir();
          const startX = buddyX != null
            ? buddyX + (dir === "left" ? 24 : -24)
            : entranceX(dir);
          const dog = makeEntity({
            cls: "dog",
            sprite: dogSVG(),
            x: startX,
            y: 2 + Math.random() * 6,
            dir,
          });
          const dur = buddyX != null ? (32 + Math.random() * 18) : (24 + Math.random() * 14);
          const speed = Math.abs(exitX(dir) - startX) / dur;
          dog.walkTo(exitX(dir), { speed, onArrive: () => dog.despawn() });
          if (!buddyX && Math.random() < 0.5) logEvent("A scrappy dog trots through.");
        }

        /* ============= CROPS ============= */
        const crops = [];
        const cropsLayer = world.querySelector(".crops-layer");
        const CROP_SPACING = 14;

        function cropSVG(stage) {
          // stage 0: seedling, 1: sprout, 2: stalks, 3: wheat-head
          if (stage === 0) return `<svg viewBox="0 0 8 12"><rect x="3" y="9" width="2" height="3" fill="#3a5a28"/></svg>`;
          if (stage === 1) return `<svg viewBox="0 0 8 12"><rect x="3" y="5" width="2" height="7" fill="#3a5a28"/><rect x="1" y="5" width="2" height="2" fill="#5a8a36"/><rect x="5" y="5" width="2" height="2" fill="#5a8a36"/></svg>`;
          if (stage === 2) return `<svg viewBox="0 0 8 12"><rect x="3" y="2" width="2" height="10" fill="#7a8a36"/><rect x="1" y="3" width="2" height="3" fill="#9aaa46"/><rect x="5" y="3" width="2" height="3" fill="#9aaa46"/></svg>`;
          return `<svg viewBox="0 0 8 12">
            <rect x="3" y="3" width="2" height="9" fill="#a89838"/>
            <rect x="2" y="0" width="4" height="4" fill="#e8c860"/>
            <rect x="2" y="0" width="4" height="1" fill="#f8e090"/>
            <rect x="1" y="2" width="1" height="1" fill="#a89838"/>
            <rect x="6" y="2" width="1" height="1" fill="#a89838"/>
          </svg>`;
        }

        function plantCropPatch() {
          if (document.hidden || reduced) return;
          // Plant a 3-wide patch
          const baseX = 60 + Math.random() * (W() - 200);
          // Skip if too close to existing crop patch
          if (crops.some((c) => Math.abs(c.x - baseX) < 80)) return;
          logEvent("A farmer tills a patch of soil.");
          for (let i = 0; i < 4; i++) {
            const x = baseX + i * CROP_SPACING + (Math.random() - 0.5) * 2;
            const el = document.createElement("div");
            el.className = "crop";
            el.style.left = x + "px";
            el.innerHTML = cropSVG(0);
            el.style.setProperty("--g", "0.5");
            cropsLayer.appendChild(el);
            const rec = { el, x, stage: 0, baseX };
            crops.push(rec);
            // Grow stages
            let s = 0;
            const grow = () => {
              if (!el.isConnected) return;
              s++;
              rec.stage = s;
              el.innerHTML = cropSVG(s);
              el.style.setProperty("--g", s >= 3 ? "1.1" : "0.8");
              if (s < 3) setTimeout(grow, 9000 + Math.random() * 5000);
              else if (i === 0) {
                logEvent("Wheat ripens golden in the field.", "good");
                // Schedule harvest after some delay
                setTimeout(() => harvestCrops(baseX), 12000 + Math.random() * 10000);
              }
            };
            setTimeout(grow, 1500 + i * 800);
          }
        }

        function harvestCrops(baseX) {
          if (document.hidden || reduced) return;
          const patch = crops.filter((c) => c.baseX === baseX && c.stage >= 3);
          if (patch.length === 0) return;
          logEvent("A farmer comes to harvest the crop!", "good");
          // Spawn a peasant to harvest
          const fromLeft = baseX > W() / 2;
          const startX = fromLeft ? -20 : W() + 20;
          const stopX = baseX + 10;
          const farmer = makePerson("", fromLeft ? "right" : "left", { bottom: 38 });
          farmer.style.left = startX + "px";
          const walkDist = Math.abs(stopX - startX);
          const walkTime = walkDist / 50;
          requestAnimationFrame(() => {
            farmer.style.transition = `left ${walkTime}s linear`;
            farmer.style.left = stopX + "px";
          });
          setTimeout(() => {
            // Harvest each crop, with sparkle
            patch.forEach((c, idx) => {
              setTimeout(() => {
                spawnParticle(c.x, 52, "dust");
                c.el.remove();
                const i = crops.indexOf(c);
                if (i >= 0) crops.splice(i, 1);
              }, idx * 400);
            });
            setTimeout(() => {
              const exitX = fromLeft ? W() + 20 : -20;
              const exitDur = Math.abs(exitX - stopX) / 50;
              farmer.style.transition = `left ${exitDur}s linear`;
              farmer.style.left = exitX + "px";
              setTimeout(() => farmer.remove(), exitDur * 1000 + 500);
            }, patch.length * 400 + 200);
          }, walkTime * 1000 + 100);
        }

        /* ============= CHIMNEY SMOKE for completed houses & campfires ============= */
        function chimneySmokeLoop() {
          if (document.hidden) { setTimeout(chimneySmokeLoop, 1500); return; }
          const isWet = weather === "rain" || weather === "storm";
          houses.forEach((rec) => {
            if (!rec.el.isConnected) return;
            if (rec.kind === "house" && rec.stage >= 2) {
              const cx = rec.x + 32; // chimney roughly at right of house roof
              spawnSmoke(cx, 90);
            } else if (rec.kind === "campfire" && rec.stage >= 2 && !isWet) {
              // Smoke only when not raining (fire is out in the rain)
              spawnSmoke(rec.x + 15, 64);
            } else if (rec.kind === "tower" && rec.stage >= 2 && Math.random() < 0.3) {
              spawnSmoke(rec.x + 16, 110);
            }
          });
          setTimeout(chimneySmokeLoop, 1200 + Math.random() * 1500);
        }
        if (!reduced) setTimeout(chimneySmokeLoop, 8000);

        /* ============= MAGE SPELL ============= */
        function castMageSpell(magePerson) {
          if (!magePerson.isConnected) return;
          // Pause mage, emit sparkles
          const curX = parseFloat(getComputedStyle(magePerson).left);
          magePerson.style.transition = "none";
          magePerson.style.left = curX + "px";
          logEvent("A mage pauses to practice the arcane arts.");
          let bursts = 0;
          const sparkleTimer = setInterval(() => {
            for (let i = 0; i < 4; i++) {
              const sparkleX = curX + 4 + (Math.random() - 0.5) * 18;
              const sparkleY = parseFloat(magePerson.style.bottom || 0) + 14 + Math.random() * 10;
              spawnSparkle(sparkleX, sparkleY);
            }
            bursts++;
            if (bursts >= 6) {
              clearInterval(sparkleTimer);
              // Resume walking
              const dir = magePerson.dataset.dir;
              const exitX = dir === "left" ? -20 : (W() + 20);
              const exitDur = Math.abs(exitX - curX) / 14; // back to walking speed
              magePerson.style.transition = `left ${exitDur}s linear`;
              magePerson.style.left = exitX + "px";
            }
          }, 350);
        }

        /* ============= TAVERN VISIT ============= */
        function maybeVisitTavern(person) {
          if (!person.isConnected) return;
          // Find a built house within 80px of person
          const px = parseFloat(getComputedStyle(person).left);
          const target = houses.find((h) => h.stage >= 2 && h.kind === "house" && Math.abs(h.x - px) < 80);
          if (!target) return;
          // Pause and fade into door
          person.style.transition = "left 1.5s linear, opacity 1.5s ease-in";
          person.style.left = (target.x + 18) + "px"; // walk to door
          setTimeout(() => {
            person.style.opacity = "0";
            logEvent("A traveler steps into the tavern.");
          }, 1400);
          setTimeout(() => {
            // After a wait, emerge
            person.style.transition = "opacity 1.5s ease-out";
            person.style.opacity = "1";
            logEvent("A traveler emerges, refreshed.");
            setTimeout(() => {
              // Continue walking
              const dir = person.dataset.dir;
              const exitX = dir === "left" ? -20 : (W() + 20);
              const dist = Math.abs(exitX - (target.x + 18));
              const dur = dist / 14;
              person.style.transition = `left ${dur}s linear, opacity 1.5s ease-out`;
              person.style.left = exitX + "px";
            }, 1600);
          }, 5000 + Math.random() * 3000);
        }

        /* ============= WELL WATERING ============= */
        function maybeWaterAtWell(person) {
          if (!person.isConnected) return;
          const px = parseFloat(getComputedStyle(person).left);
          const target = houses.find((h) => h.kind === "well" && Math.abs(h.x - px) < 60);
          if (!target) return;
          person.style.transition = "left 1.2s linear";
          person.style.left = (target.x + 12) + "px";
          setTimeout(() => {
            logEvent("A villager draws water from the well.");
            // Splash sparkles
            for (let i = 0; i < 6; i++) {
              setTimeout(() => spawnSparkle(target.x + 13, 76, "#80c0e0"), i * 200);
            }
            setTimeout(() => {
              const dir = person.dataset.dir;
              const exitX = dir === "left" ? -20 : (W() + 20);
              const dist = Math.abs(exitX - (target.x + 12));
              const dur = dist / 14;
              person.style.transition = `left ${dur}s linear`;
              person.style.left = exitX + "px";
            }, 2200);
          }, 1300);
        }

        /* ============= BANDIT AMBUSH ============= */
        function banditSVG() {
          return `<svg viewBox="0 0 12 22" xmlns="http://www.w3.org/2000/svg">
            <rect x="4" y="2" width="4" height="4" fill="#a87858"/>
            <rect x="4" y="1" width="4" height="2" fill="#3a1f15"/>
            <rect x="3" y="1" width="1" height="3" fill="#3a1f15"/>
            <rect x="8" y="1" width="1" height="3" fill="#3a1f15"/>
            <rect x="4" y="3" width="4" height="1" fill="#2a1208"/>
            <rect x="3" y="7" width="6" height="5" fill="#5a1818"/>
            <rect x="3" y="7" width="6" height="1" fill="#7a2828"/>
            <rect x="2" y="8" width="1" height="4" fill="#5a1818"/>
            <rect x="9" y="8" width="1" height="4" fill="#5a1818"/>
            <rect x="3" y="12" width="6" height="1" fill="#2a1208"/>
            <rect x="3" y="13" width="2" height="8" fill="#2a1208"/>
            <rect x="7" y="13" width="2" height="8" fill="#2a1208"/>
            <g class="p-tool">
              <rect x="9" y="6" width="1" height="5" fill="#c0c4cc"/>
              <rect x="8" y="11" width="3" height="1" fill="#6a4828"/>
            </g>
          </svg>`;
        }

        function spawnBandit() {
          if (document.hidden || reduced) return;
          // Find a current peaceful person to ambush
          const victims = Array.from(peopleLayer.querySelectorAll(".person")).filter((p) =>
            !p.classList.contains("warrior") && !p.classList.contains("lumberjack") &&
            !p.classList.contains("builder") && !p.classList.contains("fighting") &&
            !p.classList.contains("bandit") && !p.classList.contains("cleric")
          );
          if (victims.length === 0) return;
          const victim = victims[Math.floor(Math.random() * victims.length)];
          const vx = parseFloat(getComputedStyle(victim).left);
          // Pause victim
          victim.style.transition = "none";
          victim.style.left = vx + "px";
          // Spawn bandit on opposite side
          const dir = vx > W() / 2 ? "left" : "right";
          const startX = dir === "left" ? W() + 20 : -20;
          const bandit = document.createElement("div");
          bandit.className = "person bandit";
          bandit.dataset.dir = dir;
          bandit.dataset.type = "bandit";
          bandit.innerHTML = banditSVG();
          if (dir === "left") bandit.style.transform = "scaleX(-1)";
          bandit.style.left = startX + "px";
          bandit.style.bottom = (parseFloat(victim.style.bottom) || 8) + "px";
          peopleLayer.appendChild(bandit);
          startTrackLoop(bandit);
          const stopX = vx + (dir === "left" ? 16 : -16);
          const walkDist = Math.abs(stopX - startX);
          const walkTime = walkDist / 80; // fast approach
          logEvent("A bandit lunges from the shadows!", "bad");
          requestAnimationFrame(() => {
            bandit.style.transition = `left ${walkTime}s linear`;
            bandit.style.left = stopX + "px";
          });
          setTimeout(() => {
            bandit.classList.add("fighting");
            victim.classList.add("fighting");
            setTimeout(() => {
              // Chance of rescue by a warrior already on screen
              const warriors = Array.from(peopleLayer.querySelectorAll(".person.warrior")).filter(
                (w) => !w.classList.contains("fighting")
              );
              if (warriors.length > 0 && Math.random() < 0.4) {
                logEvent("A warrior rushes to the rescue!", "good");
                bandit.classList.add("defeated");
                victim.classList.remove("fighting");
                setTimeout(() => bandit.remove(), 1000);
                // Resume victim
                const dirV = victim.dataset.dir;
                const exitV = dirV === "left" ? -20 : (W() + 20);
                const distV = Math.abs(exitV - vx);
                victim.style.transition = `left ${distV / 14}s linear`;
                victim.style.left = exitV + "px";
              } else {
                // Bandit wins, steals from victim
                logEvent("The bandit steals from the traveler and flees!", "bad");
                for (let i = 0; i < 5; i++) {
                  setTimeout(() => spawnCoin(vx + (Math.random() - 0.5) * 10, 16), i * 120);
                }
                victim.classList.add("defeated");
                setTimeout(() => victim.remove(), 1000);
                bandit.classList.remove("fighting");
                // Bandit flees fast
                const exitX = dir === "left" ? W() + 20 : -20;
                bandit.style.transition = `left 5s linear`;
                bandit.style.left = exitX + "px";
                setTimeout(() => bandit.remove(), 5500);
              }
            }, 3000);
          }, walkTime * 1000 + 100);
        }

        /* ============= CLERIC + GRAVE ============= */
        function clericSVG() {
          return `<svg viewBox="0 0 12 22" xmlns="http://www.w3.org/2000/svg">
            <rect x="4" y="2" width="4" height="4" fill="#d4a888"/>
            <rect x="4" y="5" width="1" height="1" fill="#1a0a0a"/>
            <rect x="7" y="5" width="1" height="1" fill="#1a0a0a"/>
            <!-- hood -->
            <rect x="3" y="0" width="6" height="3" fill="#e8e4d8"/>
            <rect x="3" y="0" width="6" height="1" fill="#fff8ec"/>
            <!-- robe -->
            <rect x="2" y="7" width="8" height="14" fill="#e8e4d8"/>
            <rect x="2" y="7" width="8" height="1" fill="#fff8ec"/>
            <rect x="5" y="14" width="2" height="2" fill="#d4a017"/>
            <rect x="6" y="13" width="0.5" height="4" fill="#d4a017"/>
            <rect x="4.5" y="14" width="3" height="0.5" fill="#d4a017"/>
            <!-- arms -->
            <rect x="1" y="8" width="1" height="6" fill="#e8e4d8"/>
            <rect x="10" y="8" width="1" height="6" fill="#e8e4d8"/>
          </svg>`;
        }
        function graveSVG() {
          return `<svg viewBox="0 0 10 14" xmlns="http://www.w3.org/2000/svg">
            <rect x="0" y="12" width="10" height="2" fill="#3a2a1a"/>
            <rect x="2" y="4" width="6" height="9" fill="#7a7068"/>
            <rect x="2" y="4" width="6" height="1" fill="#9a9088"/>
            <rect x="3" y="0" width="4" height="5" fill="#7a7068"/>
            <rect x="3" y="0" width="4" height="1" fill="#9a9088"/>
            <rect x="4" y="2" width="2" height="3" fill="#3a2a1a"/>
            <rect x="3.5" y="3" width="3" height="1" fill="#3a2a1a"/>
          </svg>`;
        }

        function spawnCleric(graveX) {
          if (reduced) return;
          const fromLeft = graveX > W() / 2;
          const startX = fromLeft ? -20 : W() + 20;
          const stopX = graveX + (fromLeft ? -10 : 12);
          const cleric = document.createElement("div");
          cleric.className = "person cleric";
          cleric.dataset.dir = fromLeft ? "right" : "left";
          cleric.dataset.type = "cleric";
          cleric.innerHTML = clericSVG();
          if (!fromLeft) cleric.style.transform = "scaleX(-1)";
          cleric.style.left = startX + "px";
          cleric.style.bottom = "8px";
          peopleLayer.appendChild(cleric);
          startTrackLoop(cleric);
          const dist = Math.abs(stopX - startX);
          const walkTime = dist / 40;
          logEvent("A cleric arrives to tend the fallen.");
          requestAnimationFrame(() => {
            cleric.style.transition = `left ${walkTime}s linear`;
            cleric.style.left = stopX + "px";
          });
          setTimeout(() => {
            // Place grave
            const grave = document.createElement("div");
            grave.className = "grave";
            grave.innerHTML = graveSVG();
            grave.style.left = graveX + "px";
            grave.style.zIndex = "6";
            treesLayer.appendChild(grave);
            for (let i = 0; i < 4; i++) {
              setTimeout(() => spawnSparkle(graveX + 5, 60, "#fff8e0"), i * 300);
            }
            logEvent("A grave is consecrated. The realm mourns.", "bad");
            setTimeout(() => { if (grave.isConnected) grave.remove(); }, 60000);
            // Cleric walks away
            const exitX = fromLeft ? W() + 20 : -20;
            const exitDur = Math.abs(exitX - stopX) / 40;
            cleric.style.transition = `left ${exitDur}s linear`;
            cleric.style.left = exitX + "px";
            setTimeout(() => cleric.remove(), exitDur * 1000 + 500);
          }, walkTime * 1000 + 1500);
        }

        /* ============= HEART PARTICLE ============= */
        function spawnHeart(x, y) {
          const h = document.createElement("div");
          h.className = "heart";
          h.style.left = x + "px";
          h.style.bottom = y + "px";
          h.style.setProperty("--vx", ((Math.random() - 0.5) * 22) + "px");
          h.innerHTML = `<svg viewBox="0 0 10 10" xmlns="http://www.w3.org/2000/svg">
            <rect x="1" y="2" width="2" height="2" fill="#e04060"/>
            <rect x="7" y="2" width="2" height="2" fill="#e04060"/>
            <rect x="0" y="3" width="3" height="3" fill="#e04060"/>
            <rect x="7" y="3" width="3" height="3" fill="#e04060"/>
            <rect x="2" y="4" width="6" height="2" fill="#e04060"/>
            <rect x="3" y="6" width="4" height="1" fill="#c83050"/>
            <rect x="4" y="7" width="2" height="1" fill="#a82040"/>
            <rect x="1" y="3" width="1" height="1" fill="#ff6080"/>
          </svg>`;
          peopleLayer.appendChild(h);
          setTimeout(() => h.remove(), 2400);
        }

        /* ============= WEDDING ============= */
        function brideSVG() {
          return `<svg viewBox="0 0 12 22" xmlns="http://www.w3.org/2000/svg">
            <rect x="4" y="2" width="4" height="4" fill="#d4a888"/>
            <rect x="4" y="5" width="1" height="1" fill="#1a0a0a"/>
            <rect x="7" y="5" width="1" height="1" fill="#1a0a0a"/>
            <rect x="3" y="1" width="6" height="2" fill="#a8682a"/>
            <rect x="3" y="3" width="1" height="6" fill="#a8682a"/>
            <rect x="8" y="3" width="1" height="6" fill="#a8682a"/>
            <rect x="2" y="0" width="8" height="3" fill="#ffffff" opacity="0.7"/>
            <rect x="4" y="0" width="4" height="1" fill="#d4a017"/>
            <rect x="3" y="7" width="6" height="6" fill="#fff8ec"/>
            <rect x="3" y="7" width="6" height="1" fill="#ffffff"/>
            <rect x="2" y="11" width="8" height="10" fill="#fff8ec"/>
            <rect x="2" y="11" width="8" height="1" fill="#f8f0e0"/>
            <rect x="3" y="11" width="6" height="1" fill="#d4a017"/>
            <rect x="1" y="8" width="1" height="5" fill="#fff8ec"/>
            <rect x="10" y="8" width="1" height="5" fill="#fff8ec"/>
          </svg>`;
        }
        function groomSVG() {
          return `<svg viewBox="0 0 12 22" xmlns="http://www.w3.org/2000/svg">
            <rect x="4" y="2" width="4" height="4" fill="#d4a888"/>
            <rect x="4" y="5" width="1" height="1" fill="#1a0a0a"/>
            <rect x="7" y="5" width="1" height="1" fill="#1a0a0a"/>
            <rect x="4" y="1" width="4" height="2" fill="#3a2410"/>
            <rect x="3" y="1" width="1" height="3" fill="#3a2410"/>
            <rect x="8" y="1" width="1" height="3" fill="#3a2410"/>
            <rect x="3" y="7" width="6" height="5" fill="#1a1228"/>
            <rect x="3" y="7" width="6" height="1" fill="#2a2238"/>
            <rect x="5" y="7" width="2" height="3" fill="#ffffff"/>
            <rect x="5" y="8" width="2" height="1" fill="#c84a35"/>
            <rect x="2" y="8" width="1" height="4" fill="#1a1228"/>
            <rect x="9" y="8" width="1" height="4" fill="#1a1228"/>
            <rect x="2" y="11" width="1" height="1" fill="#d4a888"/>
            <rect x="9" y="11" width="1" height="1" fill="#d4a888"/>
            <rect x="3" y="12" width="6" height="1" fill="#0a0a18"/>
            <rect x="3" y="13" width="2" height="8" fill="#0a0a18"/>
            <rect x="7" y="13" width="2" height="8" fill="#0a0a18"/>
          </svg>`;
        }

        function spawnWedding() {
          if (document.hidden || reduced) return;
          const meetX = W() * (0.4 + Math.random() * 0.2);
          logEvent("A wedding gathers in the meadow!", "good");

          // Groom from left
          const groom = document.createElement("div");
          groom.className = "person groom";
          groom.dataset.dir = "right";
          groom.dataset.type = "groom";
          groom.innerHTML = groomSVG();
          groom.style.left = "-20px";
          groom.style.bottom = "8px";
          peopleLayer.appendChild(groom);
          startTrackLoop(groom);

          // Bride from right
          const bride = document.createElement("div");
          bride.className = "person bride";
          bride.dataset.dir = "left";
          bride.dataset.type = "bride";
          bride.innerHTML = brideSVG();
          bride.style.transform = "scaleX(-1)";
          bride.style.left = (W() + 20) + "px";
          bride.style.bottom = "8px";
          peopleLayer.appendChild(bride);
          startTrackLoop(bride);

          // Walk to meet point (8s)
          const walkTime = 8;
          requestAnimationFrame(() => {
            groom.style.transition = `left ${walkTime}s linear`;
            groom.style.left = (meetX - 14) + "px";
            bride.style.transition = `left ${walkTime}s linear`;
            bride.style.left = (meetX + 2) + "px";
          });

          // After they meet — spawn cleric, hearts, guests
          setTimeout(() => {
            logEvent("Vows are exchanged before the cleric.", "good");
            // Cleric appears between them
            const officiant = document.createElement("div");
            officiant.className = "person cleric officiant";
            officiant.dataset.type = "cleric";
            officiant.innerHTML = clericSVG();
            officiant.style.left = (meetX - 6) + "px";
            officiant.style.bottom = "8px";
            officiant.style.zIndex = "1";
            peopleLayer.appendChild(officiant);

            // Heart burst for ~5s
            let bursts = 0;
            const heartTimer = setInterval(() => {
              for (let i = 0; i < 3; i++) {
                spawnHeart(meetX + (Math.random() - 0.5) * 26, 22 + Math.random() * 14);
              }
              bursts++;
              if (bursts >= 10) clearInterval(heartTimer);
            }, 400);

            // 2-3 guests gather on either side
            const guestCount = 2 + Math.floor(Math.random() * 2);
            for (let i = 0; i < guestCount; i++) {
              const side = i % 2 === 0 ? -1 : 1;
              const guest = makePerson("", side > 0 ? "left" : "right", { bottom: 6 });
              const targetX = meetX + side * (28 + (Math.floor(i / 2)) * 14);
              const startX = side > 0 ? (W() + 20) : -20;
              guest.style.left = startX + "px";
              guest.style.transition = `left 4s linear`;
              requestAnimationFrame(() => { guest.style.left = targetX + "px"; });
              // Guests leave after ceremony
              setTimeout(() => {
                guest.style.transition = "left 8s linear";
                guest.style.left = (side > 0 ? -20 : W() + 20) + "px";
                setTimeout(() => guest.remove(), 8500);
              }, 7000);
            }

            // After 5s, officiant pronounces them
            setTimeout(() => {
              logEvent("They are pronounced wed! Cheers ring out.", "good");
              // Officiant leaves
              officiant.style.transition = "left 6s linear";
              officiant.style.left = "-20px";
              setTimeout(() => officiant.remove(), 6500);

              // Couple walks off together (left or right)
              const exitDir = Math.random() > 0.5 ? "right" : "left";
              const exitX = exitDir === "right" ? (W() + 30) : -30;
              const exitTime = 16;
              groom.style.transition = `left ${exitTime}s linear`;
              groom.style.left = exitX + "px";
              if (exitDir === "left") groom.style.transform = "scaleX(-1)";
              else groom.style.transform = "";
              bride.style.transition = `left ${exitTime}s linear`;
              bride.style.left = (exitX + (exitDir === "right" ? -10 : 10)) + "px";
              if (exitDir === "right") bride.style.transform = "";
              else bride.style.transform = "scaleX(-1)";
              setTimeout(() => groom.remove(), exitTime * 1000 + 500);
              setTimeout(() => bride.remove(), exitTime * 1000 + 500);
            }, 5500);
          }, walkTime * 1000 + 200);
        }

        /* ============= SKY WIZARD (broom-flying) ============= */
        function skyWizardSVG() {
          return `<svg viewBox="0 0 36 22" xmlns="http://www.w3.org/2000/svg">
            <!-- broom handle -->
            <rect x="4" y="14" width="22" height="1" fill="#6a4828"/>
            <rect x="4" y="15" width="22" height="1" fill="#3a2410"/>
            <!-- broom bristles -->
            <rect x="26" y="11" width="8" height="6" fill="#a87838"/>
            <rect x="26" y="11" width="8" height="1" fill="#c89858"/>
            <rect x="28" y="17" width="6" height="1" fill="#5a3818"/>
            <rect x="30" y="18" width="4" height="1" fill="#5a3818"/>
            <!-- wizard body -->
            <rect x="10" y="6" width="6" height="8" fill="#6a3a8a"/>
            <rect x="10" y="6" width="6" height="1" fill="#8a4aa0"/>
            <rect x="9" y="14" width="8" height="1" fill="#d4a017"/>
            <!-- arms -->
            <rect x="9" y="8" width="1" height="5" fill="#6a3a8a"/>
            <rect x="16" y="8" width="1" height="5" fill="#6a3a8a"/>
            <!-- head -->
            <rect x="11" y="2" width="4" height="4" fill="#d4a888"/>
            <!-- pointy hat -->
            <polygon points="9,2 17,2 13,-4" fill="#3a2848"/>
            <rect x="9" y="2" width="8" height="1" fill="#1a0c20"/>
            <rect x="12" y="-1" width="1" height="1" fill="#d4a017"/>
            <!-- beard -->
            <rect x="11" y="5" width="4" height="2" fill="#d8d4c0"/>
            <!-- staff -->
            <rect x="6" y="0" width="1" height="12" fill="#5a3818"/>
            <rect x="5" y="-2" width="3" height="3" fill="#d4a017"/>
            <rect x="6" y="-1" width="1" height="1" fill="#ffe080"/>
            <!-- subtle trail glow -->
            <rect x="0" y="14" width="4" height="1" fill="#a060c0" opacity="0.4"/>
            <rect x="2" y="13" width="4" height="1" fill="#a060c0" opacity="0.6"/>
          </svg>`;
        }

        function spawnSkyWizard() {
          if (document.hidden || reduced) return;
          const dir = pickDir();
          const startX = dir === "left" ? (W() + 60) : -60;
          const wiz = makeEntity({
            cls: "sky-wizard",
            sprite: skyWizardSVG(),
            layer: cloudsLayer,
            x: startX,
            dir,
            // top-anchored entity — set via style after creation
            y: 0,
          });
          wiz.el.style.bottom = "";
          wiz.el.style.top = (4 + Math.random() * 14) + "%";

          const dur = 30 + Math.random() * 20;
          const ex = dir === "left" ? -60 : (W() + 60);
          const speed = Math.abs(ex - startX) / dur;
          wiz.walkTo(ex, { speed, onArrive: () => wiz.despawn() });

          // Sparkle trail behind the broom
          const trailTimer = setInterval(() => {
            if (!wiz.el.isConnected) { clearInterval(trailTimer); return; }
            const x = wiz.getX() + (dir === "left" ? 24 : 0);
            const yPercent = parseFloat(wiz.el.style.top) / 100 * H();
            spawnSparkle(x, H() - yPercent - 6, "#c080e0");
          }, 320);
          wiz.wait(dur * 1000 + 200, () => clearInterval(trailTimer));

          logEvent("A wizard streaks across the sky on a broomstick!", "good");
        }

        /* ============= FLYING CASTLE ============= */
        function flyingCastleSVG() {
          return `<svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg" overflow="visible">
            <!-- big puffy cloud base -->
            <ellipse cx="22" cy="68" rx="14" ry="8" fill="#f0e4c0"/>
            <ellipse cx="40" cy="64" rx="18" ry="9" fill="#f0e4c0"/>
            <ellipse cx="60" cy="62" rx="20" ry="10" fill="#f0e4c0"/>
            <ellipse cx="80" cy="64" rx="18" ry="9" fill="#f0e4c0"/>
            <ellipse cx="100" cy="68" rx="14" ry="8" fill="#f0e4c0"/>
            <rect x="20" y="58" width="80" height="14" fill="#f0e4c0"/>
            <rect x="20" y="70" width="80" height="3" fill="#c8b890"/>
            <rect x="28" y="73" width="64" height="2" fill="#a89878"/>

            <!-- main castle base -->
            <rect x="36" y="38" width="48" height="22" fill="#a8a098"/>
            <rect x="36" y="38" width="48" height="2" fill="#c8c0b0"/>
            <rect x="36" y="58" width="48" height="2" fill="#80786a"/>
            <!-- gate -->
            <rect x="56" y="48" width="8" height="12" fill="#3a2410"/>
            <rect x="56" y="48" width="8" height="2" fill="#5a3818"/>
            <rect x="59" y="50" width="2" height="10" fill="#7a5828"/>
            <!-- base wall windows -->
            <rect x="42" y="44" width="3" height="5" fill="#1a1208"/>
            <rect x="75" y="44" width="3" height="5" fill="#1a1208"/>

            <!-- LEFT narrow tall tower -->
            <rect x="30" y="14" width="8" height="44" fill="#a8a098"/>
            <rect x="30" y="14" width="8" height="2" fill="#c8c0b0"/>
            <rect x="32" y="22" width="4" height="6" fill="#1a1208"/>
            <rect x="32" y="36" width="4" height="6" fill="#1a1208"/>
            <polygon points="28,14 40,14 34,2" fill="#6a3a8a"/>
            <polygon points="30,13 38,13 34,5" fill="#8a4aa0"/>
            <rect x="34" y="-2" width="0.5" height="6" fill="#5a3818"/>
            <rect x="34" y="0" width="3" height="2" fill="#c84a35"/>

            <!-- RIGHT narrow tall tower -->
            <rect x="82" y="14" width="8" height="44" fill="#a8a098"/>
            <rect x="82" y="14" width="8" height="2" fill="#c8c0b0"/>
            <rect x="84" y="22" width="4" height="6" fill="#1a1208"/>
            <rect x="84" y="36" width="4" height="6" fill="#1a1208"/>
            <polygon points="80,14 92,14 86,2" fill="#6a3a8a"/>
            <polygon points="82,13 90,13 86,5" fill="#8a4aa0"/>
            <rect x="86" y="-2" width="0.5" height="6" fill="#5a3818"/>
            <rect x="86" y="0" width="3" height="2" fill="#c84a35"/>

            <!-- CENTRAL tall keep -->
            <rect x="52" y="6" width="16" height="34" fill="#a8a098"/>
            <rect x="52" y="6" width="16" height="2" fill="#c8c0b0"/>
            <rect x="55" y="14" width="4" height="6" fill="#1a1208"/>
            <rect x="61" y="14" width="4" height="6" fill="#1a1208"/>
            <rect x="55" y="26" width="4" height="6" fill="#1a1208"/>
            <rect x="61" y="26" width="4" height="6" fill="#1a1208"/>
            <!-- crown -->
            <rect x="50" y="4" width="20" height="3" fill="#80786a"/>
            <rect x="50" y="0" width="3" height="4" fill="#80786a"/>
            <rect x="55" y="0" width="3" height="4" fill="#80786a"/>
            <rect x="60" y="0" width="4" height="4" fill="#80786a"/>
            <rect x="65" y="0" width="3" height="4" fill="#80786a"/>
            <!-- royal flag on central -->
            <rect x="59" y="-10" width="1" height="14" fill="#5a3818"/>
            <rect x="60" y="-8" width="8" height="5" fill="#6a2848"/>
            <rect x="60" y="-8" width="8" height="1" fill="#8a3868"/>
            <rect x="63" y="-6" width="2" height="2" fill="#d4a017"/>

            <!-- chains hanging from base -->
            <rect x="44" y="60" width="1" height="6" fill="#5a504a"/>
            <rect x="76" y="60" width="1" height="6" fill="#5a504a"/>
            <rect x="60" y="60" width="1" height="8" fill="#5a504a"/>

            <!-- subtle magical sparkles around -->
            <rect x="14" y="56" width="1" height="1" fill="#fff8d0" opacity="0.8"/>
            <rect x="108" y="58" width="1" height="1" fill="#fff8d0" opacity="0.8"/>
            <rect x="22" y="50" width="1" height="1" fill="#c080e0" opacity="0.8"/>
            <rect x="100" y="48" width="1" height="1" fill="#c080e0" opacity="0.8"/>
          </svg>`;
        }

        function spawnFlyingCastle() {
          if (document.hidden || reduced) return;
          const dir = pickDir();
          const startX = dir === "left" ? (W() + 250) : -250;
          const fc = makeEntity({
            cls: "flying-castle",
            sprite: flyingCastleSVG(),
            layer: cloudsLayer,
            x: startX,
            dir,
            y: 0,
          });
          fc.el.style.bottom = "";
          fc.el.style.top = (3 + Math.random() * 10) + "%";
          const dur = 90 + Math.random() * 50;
          const ex = dir === "left" ? -250 : (W() + 250);
          fc.walkTo(ex, { speed: Math.abs(ex - startX) / dur, onArrive: () => fc.despawn() });
          logEvent("A flying castle drifts majestically through the clouds!", "good");
        }

        /* ============= ADVENTURER CAMP ============= */
        function tentSVG() {
          // Pick a random tent canvas color
          const palette = pick([
            { dark: "#7a3030", light: "#a84040", trim: "#3a1010" },
            { dark: "#3a5a48", light: "#5a8060", trim: "#1a2a18" },
            { dark: "#5a4030", light: "#7a5840", trim: "#2a1a0a" },
            { dark: "#3a3858", light: "#5a5878", trim: "#1a182a" },
          ]);
          return `<svg viewBox="0 0 22 20" xmlns="http://www.w3.org/2000/svg" overflow="visible">
            <polygon points="2,20 20,20 11,4" fill="${palette.dark}"/>
            <polygon points="4,20 18,20 11,6" fill="${palette.light}"/>
            <polygon points="9,20 13,20 11,12" fill="${palette.trim}"/>
            <rect x="10" y="20" width="2" height="0.5" fill="${palette.trim}"/>
            <!-- tent pole tip -->
            <rect x="10.5" y="1" width="1" height="4" fill="#5a3818"/>
            <!-- flag/pennant -->
            <rect x="11" y="1" width="4" height="2" fill="#d4a017"/>
            <rect x="11" y="1" width="4" height="0.5" fill="#f0c440"/>
            <!-- guy ropes (hint) -->
            <rect x="0" y="18" width="2" height="0.5" fill="#3a2410"/>
            <rect x="20" y="18" width="2" height="0.5" fill="#3a2410"/>
          </svg>`;
        }

        const activeCamps = [];

        function spawnAdventurerCamp() {
          if (document.hidden || reduced) return;
          // Camps only happen at dusk or night
          const phase = world.dataset.time || "day";
          if (phase !== "dusk" && phase !== "night") return;
          const x = findOpenSpot("campfire");
          if (x == null) return;

          const dir = x > W() / 2 ? "right" : "left";
          const fromLeft = dir === "right";
          const sign = fromLeft ? 1 : -1;
          const startBase = fromLeft ? -30 : (W() + 30);

          logEvent("An adventuring party arrives, looking for a place to rest.", "good");

          // Composition: 5 mixed types
          const composition = ["warrior", "mage", "", "warrior", ""];
          const partyMembers = [];

          for (let i = 0; i < composition.length; i++) {
            const type = composition[i];
            const m = makePerson(type, dir, { bottom: 40 });
            const startX = startBase - sign * i * 18;
            m.style.left = startX + "px";
            partyMembers.push({ el: m, type });
          }

          const distToCamp = Math.abs(startBase - x);
          const walkTime = distToCamp / 45;
          partyMembers.forEach((p, i) => {
            const seatOffset = (i - 2) * 18;
            const targetX = x + seatOffset;
            requestAnimationFrame(() => {
              p.el.style.transition = `left ${walkTime}s linear`;
              p.el.style.left = targetX + "px";
            });
          });

          // After arrival, light a campfire, raise tents, wait the night
          setTimeout(() => {
            const camp = document.createElement("div");
            camp.className = "house";
            camp.dataset.kind = "campfire";
            camp.style.left = x + "px";
            camp.innerHTML = structureSVG("campfire");
            camp.querySelectorAll(".hs-roof").forEach((el) => el.setAttribute("opacity", 1));
            treesLayer.appendChild(camp);
            const rec = { el: camp, x, kind: "campfire", stage: 2 };
            setStructureStage(rec, 2);
            applyLane(rec, pickLane(x, "campfire", null, 0));
            houses.push(rec);
            scheduleAmbientRefresh(120);
            logEvent("The party kindles a campfire and unpacks for the night.", "good");

            // Raise 2-3 tents around the fire
            const tentCount = 2 + Math.floor(Math.random() * 2);
            const tents = [];
            const tentOffsets = [];
            for (let i = 0; i < tentCount; i++) {
              const side = i % 2 === 0 ? -1 : 1;
              const offset = side * (40 + Math.floor(i / 2) * 26);
              tentOffsets.push(offset);
            }
            tentOffsets.forEach((offset, i) => {
              setTimeout(() => {
                const t = document.createElement("div");
                t.className = "tent";
                t.style.left = (x + offset - 11) + "px";
                t.style.setProperty("--g", "0");
                t.innerHTML = tentSVG();
                treesLayer.appendChild(t);
                tents.push(t);
                requestAnimationFrame(() => t.style.setProperty("--g", "1"));
                if (i === 0) logEvent("Tents are pitched around the fire.");
              }, 1200 + i * 900);
            });

            // Once tents are up, party members visibly walk into them to sleep
            setTimeout(() => {
              partyMembers.forEach((p, i) => {
                if (i >= tentOffsets.length) return; // a couple stay outside to watch
                const tentOffset = tentOffsets[i % tentOffsets.length];
                const targetX = x + tentOffset - 4;
                setTimeout(() => {
                  p.el.style.transition = "left 2.2s linear";
                  p.el.style.left = targetX + "px";
                  setTimeout(() => {
                    p.el.style.transition = "opacity 1s ease-out";
                    p.el.style.opacity = "0";
                    p.el.dataset.sleeping = "1";
                    logEvent("An adventurer slips into a tent for the night.");
                  }, 2300);
                }, i * 700);
              });
            }, 1200 + tentCount * 900 + 1500);

            // Restful chatter while waiting the night
            const restLogs = [
              "The warriors swap battle tales by the fire.",
              "The mage practices a small enchantment, sparks dancing.",
              "Someone passes around rations.",
              "A hush settles over the camp.",
              "The party laughs at an old joke.",
              "A snore drifts from one of the tents.",
              "Stars wheel slowly overhead.",
            ];
            const chatTimer = setInterval(() => {
              if (Math.random() < 0.6) logEvent(restLogs[Math.floor(Math.random() * restLogs.length)]);
            }, 9000 + Math.random() * 6000);

            // Register so endCamp can be called at dawn
            const campRec = { x, dir, partyMembers, camp, rec, tents, chatTimer, finished: false };
            activeCamps.push(campRec);
            campRec.endCamp = () => {
              if (campRec.finished) return;
              campRec.finished = true;
              clearInterval(chatTimer);
              const idx = activeCamps.indexOf(campRec);
              if (idx >= 0) activeCamps.splice(idx, 1);

              logEvent("Dawn breaks. The adventurers stir from their tents.", "good");
              // Wake sleepers — they emerge from their tents first
              partyMembers.forEach((p, i) => {
                if (p.el.dataset.sleeping === "1") {
                  setTimeout(() => {
                    p.el.style.transition = "opacity 0.8s ease-in";
                    p.el.style.opacity = "1";
                    p.el.dataset.sleeping = "0";
                  }, i * 350);
                }
              });

              // Then tear down tents
              const tentCollapseStart = partyMembers.length * 350 + 800;
              setTimeout(() => {
                logEvent("The adventurers strike the tents.");
                tents.forEach((t, i) => {
                  setTimeout(() => {
                    t.classList.add("collapsing");
                    spawnParticle(parseFloat(t.style.left) + 11, 50, "dust");
                    spawnParticle(parseFloat(t.style.left) + 11, 56, "dust");
                    setTimeout(() => t.remove(), 1700);
                  }, i * 600);
                });
              }, tentCollapseStart);

              setTimeout(() => {
                logEvent("The party packs up and journeys onward.", "good");
                const exitDir = Math.random() > 0.4 ? dir : (dir === "right" ? "left" : "right");
                const exitX = exitDir === "right" ? (W() + 30) : -30;
                partyMembers.forEach((p, i) => {
                  if (!p.el.isConnected) return;
                  p.el.style.opacity = "1"; // make sure anyone still hidden becomes visible
                  const memberX = parseFloat(getComputedStyle(p.el).left);
                  const dist = Math.abs(exitX - memberX);
                  const exitTime = dist / 45;
                  if (exitDir !== dir) {
                    p.el.style.transform = p.el.style.transform.indexOf("scaleX(-1)") >= 0 ? "" : "scaleX(-1)";
                    p.el.dataset.dir = exitDir === "right" ? "right" : "left";
                  }
                  p.el.style.transition = `left ${exitTime}s linear, opacity 0.5s ease-in`;
                  p.el.style.left = (exitX + (exitDir === "right" ? i * 18 : -i * 18)) + "px";
                  setTimeout(() => p.el.remove(), exitTime * 1000 + 500);
                });

                // Campfire dies once the party is gone
                setTimeout(() => {
                  if (!camp.isConnected) return;
                  logEvent("The campfire dies down to ashes.");
                  camp.style.transition = "opacity 5s ease";
                  camp.style.opacity = "0";
                  setTimeout(() => {
                    camp.remove();
                    const hi = houses.indexOf(rec);
                    if (hi >= 0) houses.splice(hi, 1);
                    scheduleAmbientRefresh(120);
                  }, 5200);
                }, 12000);
              }, partyMembers.length * 350 + 800 + tents.length * 600 + 1200);
            };

            // Fallback: if dawn never comes (e.g., extremely long manual freeze), end after 5 min
            setTimeout(() => campRec.endCamp(), 300000);
          }, walkTime * 1000 + 100);
        }

        /* ============= ROYAL CASTLE CONSTRUCTION ============= */
        function spawnRoyalCastle() {
          if (document.hidden || reduced) return;
          // Only one castle can exist or be in progress, always dead-center.
          if (!reserveCastleBuild()) return;
          const x = W() / 2;
          const dir = "right";
          const fromLeft = dir === "right";
          const dur = 90;

          logEvent("The King's retinue rides forth to raise a castle!", "good");

          // Procession units: 2 soldiers, builder, king, builder, 2 soldiers
          const units = [
            { kind: "soldier", offset: 0 },
            { kind: "soldier", offset: 22 },
            { kind: "builder", offset: 44 },
            { kind: "king",    offset: 70 },
            { kind: "builder", offset: 96 },
            { kind: "soldier", offset: 122 },
            { kind: "soldier", offset: 144 },
          ];

          const sign = fromLeft ? 1 : -1;
          const startBase = fromLeft ? -30 : (W() + 30);
          const stopBase = x + (fromLeft ? -90 : 90);
          const elements = [];

          for (const u of units) {
            let el;
            if (u.kind === "king") {
              el = document.createElement("div");
              el.className = "king";
              el.innerHTML = kingSVG();
            } else if (u.kind === "builder") {
              el = makePerson("builder", dir, { bottom: 4 });
            } else {
              el = document.createElement("div");
              el.className = "soldier";
              el.innerHTML = soldierSVG();
            }
            if (!fromLeft) el.style.transform = "scaleX(-1)";
            el.style.bottom = "4px";
            const startX = startBase - sign * u.offset;
            const stopX = stopBase - sign * u.offset;
            el.style.left = startX + "px";
            peopleLayer.appendChild(el);
            elements.push({ el, u, startX, stopX });
            requestAnimationFrame(() => {
              el.style.transition = `left 8s linear`;
              el.style.left = stopX + "px";
            });
          }

          // After procession halts (8s), builders move to castle site & build
          setTimeout(() => {
            makeRoomForMainCastle(0);
            // Raise castle at x
            const h = document.createElement("div");
            h.className = "house";
            h.dataset.kind = "castle";
            h.innerHTML = structureSVG("castle");
            h.style.left = x + "px";
            treesLayer.appendChild(h);
            const rec = { el: h, x, kind: "castle", stage: 0 };
            setStructureStage(rec, 0);
            applyLane(rec, "back");
            houses.push(rec);
            clearCastleBuildReservation();
            logEvent("Foundations are laid for the royal castle.", "good");

            // Move builders to the castle (in front of it)
            const builders = elements.filter((e) => e.u.kind === "builder");
            builders.forEach((b, i) => {
              const bx = x + 12 + i * 60;
              b.el.style.bottom = "40px";
              b.el.style.transition = "left 2s linear, bottom 1s ease";
              b.el.style.left = bx + "px";
              setTimeout(() => b.el.classList.add("working"), 2200);
            });

            // Continuous dust
            const dust = setInterval(() => {
              for (let i = 0; i < 2; i++) {
                spawnParticle(x + 20 + Math.random() * 56, 50 + Math.random() * 14, "dust");
              }
            }, 240);

            // Stage 1 — walls
            setTimeout(() => {
              if (!h.isConnected) return;
              setStructureStage(rec, 1);
              h.querySelectorAll(".hs-walls").forEach((el) => el.setAttribute("opacity", 1));
              logEvent("The castle walls rise, stone by stone.", "good");
            }, 12000);

            // Stage 2 — battlements, keep, flags
            setTimeout(() => {
              if (!h.isConnected) return;
              setStructureStage(rec, 2);
              h.querySelectorAll(".hs-walls").forEach((el) => el.setAttribute("opacity", 1));
              h.querySelectorAll(".hs-roof").forEach((el) => el.setAttribute("opacity", 1));
              clearInterval(dust);
              logEvent("The castle stands — long live the realm!", "good");
              scheduleAmbientRefresh(160);
              // Builders step back, working class off
              builders.forEach((b) => {
                b.el.classList.remove("working");
                b.el.style.transition = "left 2s linear, bottom 1s ease";
                b.el.style.bottom = "4px";
                b.el.style.left = b.stopX + "px";
              });
              // Procession resumes after a short pause
              setTimeout(() => {
                elements.forEach((e) => {
                  const exitX = fromLeft ? (W() + 60) : -60;
                  const finalX = exitX - sign * e.u.offset;
                  e.el.style.transition = `left 14s linear`;
                  e.el.style.left = finalX + "px";
                  setTimeout(() => e.el.remove(), 14500);
                });
                logEvent("The King's host departs, mission accomplished.");
              }, 3000);
            }, 24000);
          }, 8200);
        }
        function caravanTrade(horse, cart, atX) {
          // Pause horse and cart at current position
          const hx = parseFloat(getComputedStyle(horse).left);
          const cx = parseFloat(getComputedStyle(cart).left);
          horse.style.transition = "none";
          horse.style.left = hx + "px";
          cart.style.transition = "none";
          cart.style.left = cx + "px";
          const horseEnd = parseFloat(horse.dataset.endX);
          const cartEnd  = parseFloat(cart.dataset.endX);

          // Spawn farmer next to the cart
          const farmer = makePerson("", "right", { bottom: 6 });
          const fx = cx - 14;
          farmer.style.left = fx + "px";
          logEvent("A farmer pauses by the caravan to barter.");
          for (let i = 0; i < 5; i++) {
            setTimeout(() => spawnCoin(cx + 4, 16), i * 280);
          }
          setTimeout(() => {
            // Resume caravan — horse and cart both finish at their endpoints, same duration
            const speed = 14;
            const horseRemaining = Math.abs(horseEnd - hx);
            const dur = horseRemaining / speed;
            horse.style.transition = `left ${dur}s linear`;
            horse.style.left = horseEnd + "px";
            cart.style.transition = `left ${dur}s linear`;
            cart.style.left = cartEnd + "px";
            // Farmer leaves
            farmer.style.transition = "left 12s linear";
            farmer.style.left = "-20px";
            setTimeout(() => farmer.remove(), 12500);
            logEvent("The caravan rolls on its way.");
          }, 4000);
        }

        /* ============= PEOPLE ============= */
        const personTypes = ["", "", "", "warrior", "mage", "child", "elder", "merchant", "knight", "blacksmith", "monk"];
        const personLogs = {
          "": ["A peasant wanders the path.", "A traveler crosses the road."],
          warrior: ["A warrior strides past.", "A warrior surveys the fields."],
          mage: ["A mage drifts by, robes trailing.", "A mage murmurs an incantation."],
          child: ["A child scampers by, chasing nothing.", "A small child hurries after someone."],
          elder: ["An elder shuffles past, leaning on a cane.", "An elder pauses, then continues on."],
          merchant: ["A merchant hurries by with a satchel of goods.", "A merchant haggles softly to herself."],
          knight: ["A knight rides — no, walks — by in full plate.", "A knight in heavy armor patrols the road."],
          blacksmith: ["A blacksmith trudges past, hammer on shoulder.", "A blacksmith heads home, soot-streaked."],
          monk: ["A monk passes by, scroll in hand.", "A robed monk murmurs a quiet prayer."],
        };

        // Skin tones — randomized per sprite so the realm isn't all the same person
        const SKIN = ["#e3b797", "#d2a07e", "#b77e5b", "#8b563e", "#f0cfaa", "#6f4434"];
        const HAIR = ["#392519", "#24171a", "#8f4e2b", "#c9934e", "#b2aaa0", "#d4a451"];
        const TUNIC = ["#9a6846", "#4d876b", "#b55b42", "#587d9b", "#956783", "#8b854c"];

        function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

        function footstepClass() {
          if (currentSeason === "winter") return "track-snow";
          if (weather === "rain" || weather === "storm" || world.classList.contains("wet-ground")) return "track-mud";
          const tier = parseInt(world.dataset.road || "0", 10);
          return tier >= 3 ? "track-stone" : "track-dust";
        }

        function dropTrackFor(el) {
          if (!tracksLayer || !el.isConnected || document.hidden) return;
          const cs = getComputedStyle(el);
          const x = parseFloat(cs.left);
          if (!isFinite(x) || x < -24 || x > W() + 24) return;
          let bottom = parseFloat(cs.bottom);
          if (!isFinite(bottom)) bottom = 8;
          bottom = Math.max(7, Math.min(48, bottom + Math.random() * 2));
          const mark = document.createElement("div");
          mark.className = "track-mark " + footstepClass();
          mark.style.setProperty("--x", (x + 5 + (Math.random() - 0.5) * 6) + "px");
          mark.style.setProperty("--b", bottom + "px");
          mark.style.setProperty("--r", ((el.dataset.dir === "left" ? -8 : 8) + (Math.random() - 0.5) * 16) + "deg");
          tracksLayer.appendChild(mark);
          setTimeout(() => { if (mark.isConnected) mark.remove(); }, 6500);
        }

        function startTrackLoop(el) {
          if (reduced || !tracksLayer) return;
          const leavesTracks = el.classList.contains("person")
                            || el.classList.contains("horseman")
                            || el.classList.contains("sheep")
                            || el.classList.contains("dog")
                            || el.classList.contains("cart");
          if (!leavesTracks) return;
          let tick = 0;
          function step() {
            if (!el.isConnected) return;
            tick++;
            const wetOrSnow = currentSeason === "winter" || weather === "rain" || weather === "storm" || world.classList.contains("wet-ground");
            if (wetOrSnow || tick % 2 === 0) dropTrackFor(el);
            setTimeout(step, 520 + Math.random() * 520);
          }
          setTimeout(step, 260 + Math.random() * 520);
        }

        function personSVG(type) {
          const skin = pick(SKIN);
          const hair = pick(HAIR);
          const tunic = type === "warrior" ? "#7a8090"
                      : type === "mage"    ? "#6a3a8a"
                      : type === "lumberjack" ? "#a83828"
                      : type === "builder" ? "#3878a8"
                      : pick(TUNIC);
          const tunicLight = type === "warrior" ? "#a8b0c0"
                      : type === "mage"    ? "#8a4aa0"
                      : type === "lumberjack" ? "#c84a35"
                      : type === "builder" ? "#58a0c8"
                      : tunic;
          // Common body parts
          const head = `
            <path d="M4 1h4l1 2v3L7 8H5L3 6V3z" fill="#2a2021"/>
            <rect x="4" y="2" width="4" height="4" fill="${skin}"/>
            <path d="M4 2h1v3H4zm3 1h1v2H7z" fill="#fff2d6" opacity=".24"/>
            <path d="M4 5h1m2 0h1" stroke="#312226" stroke-width=".8"/>
            <path d="M5 6h2" stroke="#8c574a" stroke-width=".6"/>
            <path d="M3 3V1h2V0h3l1 2v2H8V3H5v1H3z" fill="${hair}"/>
            <path d="M4 1h4" stroke="#fff0cc" stroke-opacity=".18" stroke-width=".7"/>
          `;
          const torso = `
            <path d="M3 7h6l1 2v4H2V9z" fill="#292632"/>
            <path d="M3 7h6v5H3zM2 9h1v3H2zm7 0h1v3H9z" fill="${tunic}"/>
            <path d="M3 7h6v1H3z" fill="${tunicLight}"/>
            <path d="M4 8h1v4H4z" fill="#fff0d4" opacity=".13"/>
            <path d="M2 12h1m6 0h1" stroke="${skin}" stroke-width="1"/>
          `;
          const belt = `<path d="M3 12h6v1H3z" fill="#3d3029"/><path d="M6 12h1v1H6z" fill="#c6a269"/>`;
          const legs = `
            <path d="M3 13h2v7H3zm4 0h2v7H7z" fill="#3b3534"/>
            <path d="M3 14h1v5H3zm4 0h1v5H7z" fill="#82796d" opacity=".3"/>
            <path d="M2 20h3v2H2zm5 0h3v2H7z" fill="#251e20"/>
            <path d="M2 20h3m2 0h3" stroke="#66534b" stroke-width=".5"/>
          `;

          let extras = "";

          // Child — smaller silhouette (head + tiny body lower in the viewBox)
          if (type === "child") {
            const skinC = skin;
            const hairC = pick(["#f0c440", "#3a2410", "#a8682a", "#7a3818"]);
            const tunicC = pick(["#c84a35", "#3a78b8", "#5aa050", "#a040a0"]);
            return `<svg viewBox="0 0 12 22" xmlns="http://www.w3.org/2000/svg">
              <!-- head -->
              <rect x="4" y="8" width="4" height="4" fill="${skinC}"/>
              <rect x="4" y="11" width="1" height="1" fill="#1a0a0a"/>
              <rect x="7" y="11" width="1" height="1" fill="#1a0a0a"/>
              <!-- hair (cowlick) -->
              <rect x="4" y="7" width="4" height="2" fill="${hairC}"/>
              <rect x="5" y="6" width="2" height="1" fill="${hairC}"/>
              <!-- short tunic -->
              <rect x="3" y="13" width="6" height="4" fill="${tunicC}"/>
              <rect x="3" y="13" width="6" height="1" fill="#ffffff" opacity="0.3"/>
              <!-- arms -->
              <rect x="2" y="13" width="1" height="3" fill="${tunicC}"/>
              <rect x="9" y="13" width="1" height="3" fill="${tunicC}"/>
              <rect x="2" y="16" width="1" height="1" fill="${skinC}"/>
              <rect x="9" y="16" width="1" height="1" fill="${skinC}"/>
              <!-- legs -->
              <rect x="3" y="17" width="2" height="5" fill="#3a2a1a"/>
              <rect x="7" y="17" width="2" height="5" fill="#3a2a1a"/>
            </svg>`;
          }

          // Elder — gray hair, long beard, robe-ish tunic, walking with a cane
          if (type === "elder") {
            const robeC = pick(["#6a4828", "#4a4438", "#5a3848", "#3a3858"]);
            return `<svg viewBox="0 0 12 22" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="4" y="2" width="4" height="4" fill="${skin}"/>
              <rect x="4" y="5" width="1" height="1" fill="#1a0a0a"/>
              <rect x="7" y="5" width="1" height="1" fill="#1a0a0a"/>
              <!-- silver hair + bald top -->
              <rect x="3" y="2" width="1" height="3" fill="#b8b0a8"/>
              <rect x="8" y="2" width="1" height="3" fill="#b8b0a8"/>
              <!-- long beard -->
              <rect x="3" y="6" width="6" height="3" fill="#d8d4c0"/>
              <rect x="4" y="9" width="4" height="2" fill="#d8d4c0"/>
              <!-- long robe -->
              <rect x="3" y="9" width="6" height="13" fill="${robeC}"/>
              <rect x="3" y="9" width="6" height="1" fill="#ffffff" opacity="0.15"/>
              <rect x="2" y="10" width="1" height="6" fill="${robeC}"/>
              <rect x="9" y="10" width="1" height="6" fill="${robeC}"/>
              <rect x="2" y="15" width="1" height="1" fill="${skin}"/>
              <rect x="9" y="15" width="1" height="1" fill="${skin}"/>
              <!-- robe trim -->
              <rect x="3" y="20" width="6" height="1" fill="#d4a017"/>
              <!-- cane -->
              <g class="p-tool">
                <rect x="10" y="6" width="1" height="15" fill="#5a3818"/>
                <rect x="9" y="5" width="2" height="2" fill="#7a4828"/>
              </g>
            </svg>`;
          }

          // Merchant — apron, satchel of goods slung at the side
          if (type === "merchant") {
            const apronC = "#4a3a28";
            return `<svg viewBox="0 0 12 22" xmlns="http://www.w3.org/2000/svg">
              <rect x="4" y="2" width="4" height="4" fill="${skin}"/>
              <rect x="4" y="5" width="1" height="1" fill="#1a0a0a"/>
              <rect x="7" y="5" width="1" height="1" fill="#1a0a0a"/>
              <rect x="4" y="1" width="4" height="2" fill="${hair}"/>
              <rect x="3" y="1" width="1" height="3" fill="${hair}"/>
              <rect x="8" y="1" width="1" height="3" fill="${hair}"/>
              <!-- shirt -->
              <rect x="3" y="7" width="6" height="5" fill="${tunic}"/>
              <rect x="3" y="7" width="6" height="1" fill="${tunicLight}"/>
              <!-- apron over shirt -->
              <rect x="3" y="9" width="6" height="3" fill="${apronC}"/>
              <rect x="3" y="11" width="6" height="1" fill="#6a5840"/>
              <!-- arms -->
              <rect x="2" y="8" width="1" height="4" fill="${tunic}"/>
              <rect x="9" y="8" width="1" height="4" fill="${tunic}"/>
              <rect x="2" y="11" width="1" height="1" fill="${skin}"/>
              <rect x="9" y="11" width="1" height="1" fill="${skin}"/>
              <rect x="3" y="12" width="6" height="1" fill="#2a1f15"/>
              <rect x="3" y="13" width="2" height="8" fill="#2a1f15"/>
              <rect x="7" y="13" width="2" height="8" fill="#2a1f15"/>
              <!-- satchel of goods -->
              <g class="p-tool">
                <rect x="9" y="9" width="3" height="4" fill="#8a6840"/>
                <rect x="9" y="9" width="3" height="1" fill="#a87838"/>
                <rect x="8" y="8" width="5" height="1" fill="#5a3818"/>
                <rect x="10" y="7" width="1" height="2" fill="#5a3818"/>
                <!-- goods peeking out -->
                <rect x="10" y="9" width="1" height="1" fill="#e04060"/>
                <rect x="10" y="10" width="1" height="1" fill="#f0c440"/>
              </g>
            </svg>`;
          }

          if (type === "warrior") {
            extras = `
              <!-- helmet -->
              <rect x="3" y="0" width="6" height="3" fill="#8890a0"/>
              <rect x="3" y="0" width="6" height="1" fill="#b8c0d0"/>
              <rect x="3" y="3" width="6" height="1" fill="#222"/>
              <!-- sword -->
              <g class="p-tool">
                <rect x="9" y="2" width="1" height="9" fill="#d4d8e0"/>
                <rect x="8" y="11" width="3" height="1" fill="#6a4828"/>
              </g>
              <!-- plume -->
              <rect x="5" y="-1" width="2" height="1" fill="#c84a35"/>
            `;
          } else if (type === "mage") {
            extras = `
              <!-- pointy hat -->
              <polygon points="3,2 9,2 6,-2" fill="#3a2848"/>
              <rect x="2" y="2" width="8" height="1" fill="#1a0c20"/>
              <rect x="5" y="0" width="1" height="1" fill="#d4a017"/>
              <!-- beard -->
              <rect x="3" y="6" width="6" height="2" fill="#d8d4c0"/>
              <!-- staff -->
              <g class="p-tool">
                <rect x="9" y="2" width="1" height="12" fill="#5a3818"/>
                <rect x="8" y="0" width="3" height="3" fill="#d4a017"/>
                <rect x="9" y="1" width="1" height="1" fill="#ffe080"/>
              </g>
            `;
          } else if (type === "lumberjack") {
            extras = `
              <!-- beard -->
              <rect x="4" y="6" width="4" height="1" fill="${hair}"/>
              <!-- shirt plaid stripe -->
              <rect x="5" y="7" width="1" height="5" fill="#7a1818"/>
              <!-- axe -->
              <g class="p-tool">
                <rect x="9" y="4" width="1" height="8" fill="#6a4828"/>
                <rect x="8" y="3" width="3" height="3" fill="#c0c4cc"/>
                <rect x="8" y="3" width="3" height="1" fill="#e0e4ec"/>
              </g>
            `;
          } else if (type === "builder") {
            extras = `
              <!-- straw hat brim -->
              <rect x="2" y="2" width="8" height="1" fill="#a08010"/>
              <rect x="4" y="0" width="4" height="2" fill="#d4a017"/>
              <!-- overall straps -->
              <rect x="4" y="7" width="1" height="4" fill="#2858a0"/>
              <rect x="7" y="7" width="1" height="4" fill="#2858a0"/>
              <!-- hammer -->
              <g class="p-tool">
                <rect x="9" y="5" width="1" height="7" fill="#6a4828"/>
                <rect x="8" y="4" width="3" height="2" fill="#6a6a72"/>
                <rect x="8" y="4" width="3" height="1" fill="#9a9aa2"/>
              </g>
            `;
          } else if (type === "knight") {
            extras = `
              <!-- closed-face helm -->
              <rect x="3" y="0" width="6" height="4" fill="#6a6a72"/>
              <rect x="3" y="0" width="6" height="1" fill="#a0a0a8"/>
              <rect x="3" y="4" width="6" height="1" fill="#222"/>
              <rect x="4" y="2" width="4" height="1" fill="#1a1a1a"/>
              <!-- plume -->
              <rect x="4" y="-2" width="4" height="2" fill="#a83828"/>
              <rect x="4" y="-3" width="2" height="1" fill="#c84a35"/>
              <!-- shoulder pauldron + chest plate accents -->
              <rect x="2" y="7" width="2" height="2" fill="#9aa0aa"/>
              <rect x="8" y="7" width="2" height="2" fill="#9aa0aa"/>
              <rect x="4" y="9" width="4" height="1" fill="#5a606a"/>
              <!-- long sword -->
              <g class="p-tool">
                <rect x="10" y="0" width="1" height="11" fill="#e0e4ec"/>
                <rect x="9" y="11" width="3" height="1" fill="#5a544e"/>
                <rect x="10" y="12" width="1" height="2" fill="#6a4828"/>
              </g>
              <!-- shield on left arm -->
              <rect x="0" y="8" width="2" height="6" fill="#c84a35"/>
              <rect x="0" y="8" width="2" height="1" fill="#e06a45"/>
              <rect x="0" y="10" width="2" height="1" fill="#d4a017"/>
            `;
          } else if (type === "blacksmith") {
            extras = `
              <!-- bald top, dark hair sides -->
              <rect x="4" y="0" width="4" height="1" fill="${skin}"/>
              <!-- thick beard -->
              <rect x="3" y="6" width="6" height="2" fill="${hair}"/>
              <!-- leather apron -->
              <rect x="3" y="9" width="6" height="6" fill="#5a3818"/>
              <rect x="3" y="9" width="6" height="1" fill="#7a4828"/>
              <rect x="4" y="11" width="4" height="3" fill="#3a1f0a"/>
              <rect x="3" y="14" width="6" height="1" fill="#3a1f0a"/>
              <!-- forge soot smudges on cheek -->
              <rect x="6" y="5" width="1" height="1" fill="#222" opacity="0.7"/>
              <!-- hefty hammer -->
              <g class="p-tool">
                <rect x="9" y="4" width="1" height="9" fill="#3a2410"/>
                <rect x="8" y="2" width="4" height="3" fill="#5a544e"/>
                <rect x="8" y="2" width="4" height="1" fill="#8a8580"/>
              </g>
            `;
          } else if (type === "monk") {
            extras = `
              <!-- hood -->
              <rect x="3" y="0" width="6" height="4" fill="#5a3818"/>
              <rect x="3" y="0" width="6" height="1" fill="#7a4828"/>
              <rect x="4" y="3" width="4" height="1" fill="#3a2410"/>
              <!-- monk tonsure hair ring just visible -->
              <rect x="4" y="4" width="4" height="1" fill="${hair}" opacity="0.4"/>
              <!-- brown robe replacing tunic -->
              <rect x="3" y="7" width="6" height="14" fill="#5a3818"/>
              <rect x="3" y="7" width="6" height="1" fill="#7a4828"/>
              <rect x="2" y="8" width="1" height="6" fill="#5a3818"/>
              <rect x="9" y="8" width="1" height="6" fill="#5a3818"/>
              <!-- rope belt -->
              <rect x="3" y="12" width="6" height="1" fill="#d4a017"/>
              <!-- holy book / scroll -->
              <g class="p-tool">
                <rect x="9" y="9" width="3" height="3" fill="#a87838"/>
                <rect x="9" y="9" width="3" height="1" fill="#c89858"/>
                <rect x="10" y="10" width="1" height="1" fill="#d4a017"/>
              </g>
            `;
          }
          return `<svg viewBox="0 0 12 22" xmlns="http://www.w3.org/2000/svg" overflow="visible">${head}${torso}${belt}${legs}${extras}</svg>`;
        }

        // === Entity primitives =======================================
        // Direction helpers
        const entranceX = (dir) => dir === "left" ? (W() + 20) : -20;
        const exitX     = (dir) => dir === "left" ? -20 : (W() + 20);
        const flipDir   = (dir) => dir === "left" ? "right" : "left";
        const dirSign   = (dir) => dir === "left" ? -1 : 1;
        function pickDir(towardsX) {
          if (towardsX != null) return towardsX > W() / 2 ? "right" : "left";
          return Math.random() > 0.5 ? "left" : "right";
        }

        /**
         * Make a moving entity. Returns a small chainable API:
         *   .el, .getX(), .setDir(d), .walkTo(x, {speed, onArrive}),
         *   .walkOff({speed}), .state(cls, on?), .wait(ms, fn),
         *   .fade(ms), .despawn()
         */
        function makeEntity({
          cls = "person",
          kind = "",
          extra = "",
          sprite = "",
          layer = peopleLayer,
          x = 0,
          y = 4,
          dir = "right",
        }) {
          const el = document.createElement("div");
          el.className = cls + (kind ? " " + kind : "") + (extra ? " " + extra : "");
          el.dataset.dir = dir;
          if (kind) el.dataset.type = kind;
          el.style.left = x + "px";
          el.style.bottom = y + "px";
          if (dir === "left") el.style.transform = "scaleX(-1)";
          if (sprite) el.innerHTML = sprite;
          layer.appendChild(el);
          startTrackLoop(el);

          const api = {
            el,
            getX() { return parseFloat(getComputedStyle(el).left) || 0; },
            setDir(d) {
              el.dataset.dir = d;
              el.style.transform = d === "left" ? "scaleX(-1)" : "";
              return api;
            },
            walkTo(targetX, opts = {}) {
              const speed = opts.speed != null ? opts.speed : 50;
              const cur = api.getX();
              const dist = Math.abs(targetX - cur);
              const dur = Math.max(0.05, dist / speed);
              el.style.transition = `left ${dur}s linear`;
              requestAnimationFrame(() => { el.style.left = targetX + "px"; });
              if (opts.onArrive) setTimeout(() => opts.onArrive(api), dur * 1000 + 50);
              return api;
            },
            walkOff(opts = {}) {
              return api.walkTo(exitX(el.dataset.dir), {
                speed: opts.speed != null ? opts.speed : 50,
                onArrive: () => api.despawn(),
              });
            },
            state(c, on) {
              if (on == null) el.classList.toggle(c);
              else el.classList.toggle(c, on);
              return api;
            },
            wait(ms, fn) {
              setTimeout(() => fn && fn(api), ms);
              return api;
            },
            fade(ms = 1000) {
              el.style.transition = `opacity ${ms / 1000}s ease`;
              el.style.opacity = "0";
              setTimeout(() => api.despawn(), ms + 100);
              return api;
            },
            despawn() {
              if (el.isConnected) el.remove();
              return api;
            },
          };
          return api;
        }

        /**
         * Spawn a sprite that crosses the screen end-to-end, then despawns.
         * The simple "walks across" pattern most entities follow.
         */
        function spawnCrosser({
          cls = "person", kind = "", extra = "",
          sprite = "",
          layer = peopleLayer,
          dir,                              // optional override
          y,                                // bottom px (random if omitted)
          speed = 50,
          dur,                              // override duration (s); ignored if speed given as undefined
          onMid,                            // (api, fraction) => void — optional mid-walk callback
          log,                              // optional log message
          logKind,                          // optional log kind
        }) {
          if (document.hidden || reduced) return null;
          const d = dir || pickDir();
          const sx = entranceX(d);
          const ex = exitX(d);
          const yPos = y != null ? y : (2 + Math.random() * 14);
          const entity = makeEntity({ cls, kind, extra, sprite, layer, x: sx, y: yPos, dir: d });
          const actualSpeed = speed != null ? speed : (dur ? Math.abs(ex - sx) / dur : 50);
          entity.walkTo(ex, { speed: actualSpeed, onArrive: () => entity.despawn() });
          if (log) logEvent(log, logKind);
          return entity;
        }

        // Backward-compat shim: a few legacy spawners still call makePerson.
        // It now wraps makeEntity and returns the raw element for compatibility.
        function makePerson(type, dir, opts = {}) {
          const e = makeEntity({
            cls: "person",
            kind: type,
            extra: opts.extra || "",
            sprite: personSVG(type),
            x: opts.startX != null ? opts.startX : entranceX(dir),
            y: opts.bottom != null ? opts.bottom : (2 + Math.random() * 14),
            dir,
          });
          return e.el;
        }

        function walkPerson(p, dur, endX) {
          requestAnimationFrame(() => {
            p.style.transition = `left ${dur}s linear`;
            p.style.left = endX + "px";
          });
          setTimeout(() => { if (p.isConnected) p.remove(); }, dur * 1000 + 500);
        }

        function spawnPerson(opts = {}) {
          if (document.hidden || reduced) return;
          const dir = opts.dir || pickDir();
          const type = opts.type || personTypes[Math.floor(Math.random() * personTypes.length)];
          const isRainy = weather === "rain" || weather === "storm";
          const baseDur = isRainy ? (12 + Math.random() * 8) : (48 + Math.random() * 32);
          const dur = opts.duration || baseDur;
          const offset = opts.offset || 0;
          const startX = entranceX(dir) + offset;
          const ex = exitX(dir);

          const entity = makeEntity({
            cls: "person",
            kind: type,
            sprite: personSVG(type),
            x: startX,
            y: opts.bottom != null ? opts.bottom : (2 + Math.random() * 14),
            dir,
          });
          entity.walkTo(ex, { speed: Math.abs(ex - startX) / dur, onArrive: () => entity.despawn() });
          const p = entity.el;

          if (!opts.silent && Math.random() < 0.3) {
            const ops = personLogs[type];
            logEvent(ops[Math.floor(Math.random() * ops.length)]);
          }

          // Mid-walk side interactions for peasants (not warriors/mages/special roles)
          if (type === "" && !opts.silent) {
            if (Math.random() < 0.12) entity.wait((dur * 0.3 + Math.random() * dur * 0.3) * 1000, () => maybeVisitTavern(p));
            if (Math.random() < 0.14) entity.wait((dur * 0.3 + Math.random() * dur * 0.3) * 1000, () => maybeWaterAtWell(p));
            if (Math.random() < 0.08) entity.wait(200, () => spawnDog(startX, dir));
            // Stalls: try a couple of times mid-walk in case they pass by one
            entity.wait((dur * 0.30) * 1000, () => maybeStopAtStall(p));
            entity.wait((dur * 0.60) * 1000, () => maybeStopAtStall(p));
          }
          if (type === "mage" && !opts.silent && Math.random() < 0.25) {
            entity.wait((dur * 0.3 + Math.random() * dur * 0.3) * 1000, () => castMageSpell(p));
          }
          return p;
        }

        // Groups: 2-4 friends walking together
        function spawnGroup() {
          if (document.hidden || reduced) return;
          const dir = Math.random() > 0.5 ? "left" : "right";
          const size = 2 + Math.floor(Math.random() * 3); // 2-4
          const baseDur = 55 + Math.random() * 28;
          for (let i = 0; i < size; i++) {
            const type = personTypes[Math.floor(Math.random() * personTypes.length)];
            const offset = (dir === "left" ? 1 : -1) * i * (14 + Math.random() * 10);
            spawnPerson({ dir, type, duration: baseDur + (Math.random() - 0.5) * 4, offset, silent: true, bottom: 2 + Math.random() * 12 });
          }
          const labels = [
            "A merry band rambles down the road.",
            "A group of friends pass through together.",
            "Travelers move as one — strength in numbers.",
            size >= 3 ? "A small party crosses the realm." : "Two companions walk side by side."
          ];
          logEvent(labels[Math.floor(Math.random() * labels.length)]);
        }

        /* ============= HORSES ============= */
        function horseSVG(withRider) {
          const rider = withRider ? `
            <!-- rider torso -->
            <rect x="8" y="6" width="6" height="8" fill="#6a4828"/>
            <rect x="8" y="6" width="6" height="2" fill="#8a6840"/>
            <!-- head -->
            <rect x="9" y="2" width="4" height="4" fill="#d4a888"/>
            <!-- hat / hood -->
            <rect x="9" y="1" width="4" height="2" fill="#3a2410"/>
          ` : "";
          return `<svg viewBox="0 0 28 26" xmlns="http://www.w3.org/2000/svg">
            <rect x="2" y="14" width="20" height="6" fill="#5a3a20"/>
            <rect x="2" y="14" width="20" height="2" fill="#7a5028"/>
            <rect x="20" y="11" width="6" height="5" fill="#5a3a20"/>
            <rect x="20" y="11" width="6" height="1" fill="#7a5028"/>
            <rect x="25" y="13" width="1" height="2" fill="#1a1208"/>
            <rect x="17" y="10" width="4" height="3" fill="#1a1208"/>
            <rect x="4" y="20" width="2" height="6" fill="#1a1208"/>
            <rect x="9" y="20" width="2" height="6" fill="#1a1208"/>
            <rect x="14" y="20" width="2" height="6" fill="#1a1208"/>
            <rect x="19" y="20" width="2" height="6" fill="#1a1208"/>
            <rect x="0" y="13" width="2" height="6" fill="#1a1208"/>
            ${rider}
          </svg>`;
        }

        function spawnHorse() {
          if (document.hidden || reduced) return;
          const dir = Math.random() > 0.5 ? "left" : "right";
          const withRider = Math.random() > 0.4;
          // Pick a pace: fast / steady / slow
          const paceRoll = Math.random();
          let pace, dur, paceLabel;
          if (paceRoll < 0.25) { pace = "fast";   dur = 14 + Math.random() * 6;  paceLabel = "gallops"; }
          else if (paceRoll < 0.7) { pace = "steady"; dur = 26 + Math.random() * 10; paceLabel = "canters"; }
          else { pace = "slow"; dur = 44 + Math.random() * 18; paceLabel = "ambles"; }

          const h = document.createElement("div");
          h.className = "horseman peaceful pace-" + pace;
          h.innerHTML = horseSVG(withRider);
          if (dir === "left") h.style.transform = "scaleX(-1)";
          const startX = dir === "left" ? W() + 30 : -30;
          const endX = dir === "left" ? -30 : W() + 30;
          h.style.left = startX + "px";
          h.style.bottom = "4px";
          peopleLayer.appendChild(h);

          const isRainy = weather === "rain" || weather === "storm";
          const finalDur = isRainy ? Math.min(dur, 14) : dur;
          requestAnimationFrame(() => {
            h.style.transition = `left ${finalDur}s linear`;
            h.style.left = endX + "px";
          });
          setTimeout(() => h.remove(), finalDur * 1000 + 500);

          if (withRider) {
            logEvent(`A rider ${paceLabel} through on horseback.`);
          } else {
            logEvent(`A loose horse ${paceLabel} across the meadow.`);
          }
        }

        /* ============= CARAVAN ============= */
        function cartSVG() {
          return `<svg viewBox="0 0 32 22" xmlns="http://www.w3.org/2000/svg">
            <rect x="2" y="6" width="28" height="12" fill="#6a4828"/>
            <rect x="2" y="6" width="28" height="2" fill="#8a6840"/>
            <rect x="4" y="8" width="2" height="10" fill="#3a2410"/>
            <rect x="14" y="8" width="2" height="10" fill="#3a2410"/>
            <rect x="26" y="8" width="2" height="10" fill="#3a2410"/>
            <rect x="6" y="3" width="6" height="4" fill="#a87858"/>
            <rect x="14" y="2" width="8" height="5" fill="#a87858"/>
            <rect x="14" y="2" width="8" height="1" fill="#c89878"/>
            <circle cx="8" cy="20" r="3" fill="#1a1208"/>
            <circle cx="24" cy="20" r="3" fill="#1a1208"/>
            <circle cx="8" cy="20" r="1" fill="#5a3818"/>
            <circle cx="24" cy="20" r="1" fill="#5a3818"/>
          </svg>`;
        }

        function spawnCaravan() {
          if (document.hidden || reduced) return;
          const dir = Math.random() > 0.5 ? "left" : "right";
          const dur = 42 + Math.random() * 18;
          // Horse pulling cart + 2 guards. Spawn them with offsets.
          // We'll spawn the cart first, then horse just ahead, then guards behind.
          const lead = dir === "right" ? 1 : -1;

          // Cart trails horse by constant offset so they stay synced
          const sign = dir === "right" ? 1 : -1;
          const cartOffset = 32; // px the cart trails behind the horse in walking direction

          // Horse (front of caravan)
          const hp = document.createElement("div");
          hp.className = "horseman peaceful caravan-horse";
          hp.innerHTML = horseSVG(false);
          if (dir === "left") hp.style.transform = "scaleX(-1)";
          hp.style.bottom = "4px";
          const horseStart = dir === "left" ? (W() + 30) : -30;
          const horseEnd   = dir === "left" ? -30 : (W() + 30);
          hp.style.left = horseStart + "px";
          hp.dataset.endX = horseEnd;
          peopleLayer.appendChild(hp);
          requestAnimationFrame(() => {
            hp.style.transition = `left ${dur}s linear`;
            hp.style.left = horseEnd + "px";
          });
          setTimeout(() => hp.remove(), dur * 1000 + 500);

          // Cart trails horse with constant offset, same speed
          const cart = document.createElement("div");
          cart.className = "cart";
          cart.innerHTML = cartSVG();
          if (dir === "left") cart.style.transform = "scaleX(-1)";
          cart.style.bottom = "2px";
          const cartStart = horseStart - sign * cartOffset;
          const cartEnd   = horseEnd   - sign * cartOffset;
          cart.style.left = cartStart + "px";
          cart.dataset.endX = cartEnd;
          peopleLayer.appendChild(cart);
          requestAnimationFrame(() => {
            cart.style.transition = `left ${dur}s linear`;
            cart.style.left = cartEnd + "px";
          });
          setTimeout(() => cart.remove(), dur * 1000 + 500);

          // 2 guards walking alongside
          for (let i = 0; i < 2; i++) {
            const offset = (dir === "left" ? 1 : -1) * (60 + i * 20);
            spawnPerson({
              dir, type: "warrior",
              duration: dur,
              offset,
              silent: true,
              bottom: 4 + i * 8,
            });
          }
          logEvent("A trade caravan rolls through. Guards keep watch.");

          // ~70% chance: pause mid-journey for a farmer to trade
          if (Math.random() < 0.7) {
            const tradeAt = dur * (0.3 + Math.random() * 0.3) * 1000;
            setTimeout(() => {
              if (!hp.isConnected) return;
              caravanTrade(hp, cart, 0);
            }, tradeAt);
          }
        }

        /* ============= ROYAL ARMY ============= */
        function kingSVG() {
          return `<svg viewBox="0 0 14 22" xmlns="http://www.w3.org/2000/svg">
            <rect x="4" y="14" width="2" height="6" fill="#3a2848"/>
            <rect x="8" y="14" width="2" height="6" fill="#3a2848"/>
            <rect x="2" y="8" width="10" height="10" fill="#6a2848"/>
            <rect x="2" y="8" width="10" height="2" fill="#8a3868"/>
            <rect x="2" y="16" width="10" height="1" fill="#d4a017"/>
            <rect x="5" y="4" width="4" height="4" fill="#d4a888"/>
            <rect x="4" y="7" width="6" height="2" fill="#c8c0b0"/>
            <rect x="4" y="2" width="6" height="2" fill="#d4a017"/>
            <rect x="4" y="0" width="1" height="2" fill="#d4a017"/>
            <rect x="6" y="0" width="2" height="2" fill="#d4a017"/>
            <rect x="9" y="0" width="1" height="2" fill="#d4a017"/>
            <rect x="7" y="0" width="1" height="1" fill="#c84a35"/>
          </svg>`;
        }

        function soldierSVG() {
          return `<svg viewBox="0 0 10 18" xmlns="http://www.w3.org/2000/svg">
            <rect x="2" y="12" width="2" height="6" fill="#3a2a1a"/>
            <rect x="6" y="12" width="2" height="6" fill="#3a2a1a"/>
            <rect x="2" y="6" width="6" height="6" fill="#8890a0"/>
            <rect x="2" y="6" width="6" height="1" fill="#b8c0d0"/>
            <rect x="2" y="11" width="6" height="1" fill="#555a68"/>
            <rect x="3" y="2" width="4" height="4" fill="#8890a0"/>
            <rect x="3" y="2" width="4" height="1" fill="#b8c0d0"/>
            <rect x="3" y="4" width="4" height="1" fill="#222"/>
            <rect x="4" y="0" width="2" height="2" fill="#c84a35"/>
            <rect x="8" y="0" width="1" height="14" fill="#6a4828"/>
            <rect x="7" y="0" width="3" height="2" fill="#c0c4cc"/>
            <rect x="0" y="7" width="2" height="5" fill="#c84a35"/>
            <rect x="0" y="7" width="2" height="1" fill="#e06a45"/>
          </svg>`;
        }

        function bannerSVG() {
          return `<svg viewBox="0 0 10 22" xmlns="http://www.w3.org/2000/svg">
            <rect x="2" y="12" width="2" height="6" fill="#3a2a1a"/>
            <rect x="6" y="12" width="2" height="6" fill="#3a2a1a"/>
            <rect x="2" y="6" width="6" height="6" fill="#8890a0"/>
            <rect x="3" y="2" width="4" height="4" fill="#8890a0"/>
            <rect x="3" y="4" width="4" height="1" fill="#222"/>
            <!-- pole -->
            <rect x="8" y="-6" width="1" height="20" fill="#6a4828"/>
            <!-- banner cloth -->
            <rect x="9" y="-5" width="6" height="6" fill="#6a2848"/>
            <rect x="9" y="-5" width="6" height="1" fill="#8a3868"/>
            <rect x="11" y="-3" width="2" height="2" fill="#d4a017"/>
          </svg>`;
        }

        function legionarySVG(role = "legionary") {
          const isCenturion = role === "centurion";
          const isStandard = role === "standard";
          const shield = isCenturion ? "#7a2848" : "#a83828";
          const crest = isCenturion ? "#f0c440" : "#c84a35";
          const armor = isCenturion ? "#a8a098" : "#8a9098";
          const armorLight = isCenturion ? "#d8c878" : "#c0c4cc";
          const plume = isCenturion
            ? `<rect x="2" y="-2" width="10" height="2" fill="${crest}"/>
               <rect x="3" y="-3" width="8" height="1" fill="#ffe080"/>`
            : `<rect x="5" y="-2" width="4" height="2" fill="${crest}"/>`;
          const standard = isStandard ? `
            <g class="legion-standard-cloth">
              <rect x="11" y="-4" width="5" height="5" fill="#6a2848"/>
              <rect x="11" y="-4" width="5" height="1" fill="#d4a017"/>
              <rect x="12" y="-2" width="3" height="1" fill="#d4a017"/>
              <rect x="13" y="0" width="1" height="1" fill="#d4a017"/>
            </g>
            <rect x="12" y="-7" width="3" height="2" fill="#d4a017"/>
            <rect x="13" y="-9" width="1" height="2" fill="#f8e090"/>
          ` : "";
          const pilum = isStandard ? `
            <g class="legion-pilum">
              <rect x="10" y="-5" width="1" height="18" fill="#6a4828"/>
              ${standard}
            </g>
          ` : `
            <g class="legion-pilum">
              <rect x="11" y="1" width="1" height="13" fill="#5a3818"/>
              <polygon points="10,1 12,1 11,-2" fill="#d8dce4"/>
            </g>
          `;
          const cape = isCenturion ? `
            <rect x="2" y="7" width="10" height="12" fill="#6a1020" opacity="0.72"/>
            <rect x="2" y="7" width="10" height="1" fill="#c84a35" opacity="0.8"/>
          ` : "";
          return `<svg viewBox="0 -9 16 31" xmlns="http://www.w3.org/2000/svg" overflow="visible">
            ${cape}
            <rect x="4" y="14" width="2" height="7" fill="#3a2a1a"/>
            <rect x="8" y="14" width="2" height="7" fill="#3a2a1a"/>
            <rect x="4" y="20" width="2" height="1" fill="#1a0a0a"/>
            <rect x="8" y="20" width="2" height="1" fill="#1a0a0a"/>
            <rect x="3" y="11" width="8" height="4" fill="#a83828"/>
            <rect x="3" y="15" width="2" height="1" fill="#d4a017"/>
            <rect x="6" y="15" width="2" height="1" fill="#d4a017"/>
            <rect x="9" y="15" width="2" height="1" fill="#d4a017"/>
            <rect x="3" y="7" width="8" height="6" fill="${armor}"/>
            <rect x="3" y="7" width="8" height="1" fill="${armorLight}"/>
            <rect x="4" y="9" width="6" height="1" fill="#5a6068"/>
            <rect x="5" y="2" width="4" height="4" fill="#d4a888"/>
            <rect x="4" y="0" width="6" height="4" fill="#767c84"/>
            <rect x="4" y="0" width="6" height="1" fill="#c0c4cc"/>
            <rect x="4" y="4" width="6" height="1" fill="#1a1a1a"/>
            ${plume}
            <rect x="1" y="8" width="4" height="8" fill="${shield}"/>
            <rect x="1" y="8" width="4" height="1" fill="#e06a45"/>
            <rect x="2" y="10" width="2" height="1" fill="#d4a017"/>
            <rect x="2" y="13" width="2" height="1" fill="#d4a017"/>
            <rect x="0" y="10" width="1" height="4" fill="#5a1020"/>
            ${pilum}
          </svg>`;
        }

        function spawnArmy() {
          if (document.hidden || reduced) return;
          const dir = Math.random() > 0.5 ? "left" : "right";
          const dur = 55 + Math.random() * 25;
          // Order in walking direction: 2 vanguard soldiers, banner-bearer, king, 2 rear soldiers
          const units = [
            { kind: "soldier", offset: 0 },
            { kind: "soldier", offset: 22 },
            { kind: "banner",  offset: 48 },
            { kind: "king",    offset: 74 },
            { kind: "soldier", offset: 100 },
            { kind: "soldier", offset: 122 },
          ];
          for (const u of units) {
            const el = document.createElement("div");
            if (u.kind === "king") {
              el.className = "king";
              el.innerHTML = kingSVG();
            } else if (u.kind === "banner") {
              el.className = "soldier banner";
              el.innerHTML = bannerSVG();
            } else {
              el.className = "soldier";
              el.innerHTML = soldierSVG();
            }
            if (dir === "left") el.style.transform = "scaleX(-1)";
            el.style.bottom = "4px";
            const sign = dir === "right" ? 1 : -1;
            const startX = (dir === "left" ? W() + 30 : -30) - sign * u.offset;
            const endX = (dir === "left" ? -30 : W() + 30) - sign * u.offset;
            el.style.left = startX + "px";
            peopleLayer.appendChild(el);
            requestAnimationFrame(() => {
              el.style.transition = `left ${dur}s linear`;
              el.style.left = endX + "px";
            });
            setTimeout(() => el.remove(), dur * 1000 + 500);
          }
          logEvent("The King's host marches through with banners high!", "good");
        }

        function spawnLegionnairesCentury() {
          if (document.hidden || reduced) return;
          const dir = Math.random() > 0.5 ? "left" : "right";
          const dur = 62 + Math.random() * 20;
          const sign = dir === "right" ? 1 : -1;
          const startBase = dir === "left" ? (W() + 38) : -38;
          const endBase = dir === "left" ? -38 : (W() + 38);
          const units = [
            { role: "legionary", offset: 0,   row: 0 },
            { role: "legionary", offset: 18,  row: 1 },
            { role: "legionary", offset: 36,  row: 0 },
            { role: "legionary", offset: 54,  row: 1 },
            { role: "standard",  offset: 76,  row: 0 },
            { role: "centurion", offset: 98,  row: 1 },
            { role: "legionary", offset: 120, row: 0 },
            { role: "legionary", offset: 138, row: 1 },
            { role: "legionary", offset: 156, row: 0 },
            { role: "legionary", offset: 174, row: 1 },
            { role: "legionary", offset: 192, row: 0 },
            { role: "legionary", offset: 210, row: 1 },
          ];

          units.forEach((u, i) => {
            const roleClass = u.role === "standard" ? "legion-standard" : u.role;
            const startX = startBase - sign * u.offset;
            const endX = endBase - sign * u.offset;
            const entity = makeEntity({
              cls: "person legionary",
              kind: roleClass,
              sprite: legionarySVG(u.role),
              x: startX,
              y: 3 + u.row * 5,
              dir,
            });
            entity.el.style.animationDelay = (i % 4) * 0.08 + "s";
            entity.walkTo(endX, {
              speed: Math.abs(endBase - startBase) / dur,
              onArrive: () => entity.despawn(),
            });
          });

          const logs = [
            "A legionnaires' century marches through, shields locked in rhythm.",
            "A centurion barks the count as the legionnaires keep perfect pace.",
            "A red-shielded century crosses the realm in polished formation.",
          ];
          logEvent(pick(logs), "good");
        }

        /* ============= DUELS ============= */
        function spawnDuel() {
          if (document.hidden || reduced) return;
          // Pick a meeting point roughly center-screen
          const meetX = W() * (0.35 + Math.random() * 0.3);
          const lhs = Math.random() > 0.5 ? "warrior" : "";
          const rhs = Math.random() > 0.5 ? "warrior" : "mage";
          const dur = 18 + Math.random() * 6;

          // Walker A (from left, moving right)
          const a = makePerson(lhs, "right", { startX: -20, bottom: 6 });
          // Walker B (from right, moving left)
          const b = makePerson(rhs, "left", { startX: W() + 20, bottom: 6 });

          // Walk toward meetX over T seconds
          const T = dur / 2;
          requestAnimationFrame(() => {
            a.style.transition = `left ${T}s linear`;
            a.style.left = (meetX - 10) + "px";
            b.style.transition = `left ${T}s linear`;
            b.style.left = (meetX + 2) + "px";
          });
          logEvent("Two strangers approach on the path…");

          setTimeout(() => {
            a.classList.add("fighting");
            b.classList.add("fighting");
            logEvent("A quarrel breaks out — steel rings out!", "bad");

            setTimeout(() => {
              // Decide winner
              const aWins = Math.random() > 0.5;
              const loser = aWins ? b : a;
              const winner = aWins ? a : b;
              const loserX = parseFloat(getComputedStyle(loser).left);
              loser.classList.add("defeated");
              logEvent(aWins ? "The traveler from the east is bested." : "The traveler from the west flees the field.", "bad");
              setTimeout(() => loser.remove(), 1000);
              // Send a cleric to consecrate after a delay
              setTimeout(() => spawnCleric(loserX), 6000 + Math.random() * 4000);

              // Winner continues
              winner.classList.remove("fighting");
              const winnerDir = winner.dataset.dir;
              const exitX = winnerDir === "left" ? -20 : (W() + 20);
              const continueDur = 8 + Math.random() * 6;
              winner.style.transition = `left ${continueDur}s linear`;
              winner.style.left = exitX + "px";
              setTimeout(() => winner.remove(), continueDur * 1000 + 500);
            }, 3200);
          }, T * 1000 + 100);
        }

        function fleeFromWeather() {
          peopleLayer.querySelectorAll(".person").forEach((p) => {
            if (p.classList.contains("lumberjack") || p.classList.contains("horseman") || p.classList.contains("builder")) return;
            if (p.dataset.fled === "1") return;
            p.dataset.fled = "1";
            const cur = parseFloat(getComputedStyle(p).left);
            const dir = p.dataset.dir;
            const target = dir === "left" ? -30 : (W() + 30);
            const dist = Math.abs(target - cur);
            const newDur = dist / 220; // sprint speed
            p.style.transition = `left ${newDur}s linear`;
            requestAnimationFrame(() => { p.style.left = target + "px"; });
            setTimeout(() => p.remove(), newDur * 1000 + 200);
          });
        }

        /* ============= TREES ============= */
        const treeStages = [0, 0.25, 0.55, 0.85, 1.1];
        const trees = [];
        const backTrees = [];
        const hillTrees = [];
        const TREE_MIN_SPACING = 52;
        const TREE_STRUCTURE_SPACING = 62;
        const TREE_SPOT_ATTEMPTS = 120;
        const BACK_TREE_MIN_SPACING = 30;
        const BACK_TREE_SPOT_ATTEMPTS = 90;
        const HILL_TREE_MIN_SPACING = 38;
        const HILL_TREE_SPOT_ATTEMPTS = 90;
        const STARTER_STRUCTURE_SEEDS = [
          { kind: "castle",    pos: 0.50, up: 0 },
          { kind: "house",     pos: 0.44, up: 1 },
          { kind: "tavern",    pos: 0.52, up: 0 },
          { kind: "marketstall", pos: 0.60, up: 0 },
          { kind: "well",      pos: 0.35, up: 0 },
          { kind: "garden",    pos: 0.38, up: 0 },
          { kind: "house",     pos: 0.74, up: 0 },
          { kind: "signpost",  pos: 0.66, up: 0 },
          { kind: "lamppost",  pos: 0.28, up: 0 },
          { kind: "blacksmith", pos: 0.80, up: 0 },
          { kind: "statue",    pos: 0.88, up: 0 },
        ];

        function makeTreeSVG(species) {
          if (species === "oak") {
            // Broad, asymmetric crown with a visible branching structure.
            return `<svg viewBox="0 0 24 48" xmlns="http://www.w3.org/2000/svg">
              <g class="bark">
                <path d="M9 48l1-16 2-10 2 10 1 16z" fill="var(--bark)"/>
                <path d="M11 47l1-18 1 19z" fill="var(--bark-light)"/>
                <path d="M10 43l-3 5h2l3-4m2-2 3 6h-2l-3-4" fill="var(--bark)"/>
              </g>
              <g class="bare-branches" opacity="var(--bare-show)">
                <path d="M12 34V13m0 12L5 18m7 2 6-8M9 23l-2-9m8 3 2-9M12 15 9 8m3 6 2-8M5 18l-2-5m2 5-3 1m16-7 3-4m-3 4 3 2" fill="none" stroke="var(--bark)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M12 31V16m0 7-5-5m5 3 5-8" fill="none" stroke="var(--bark-light)" stroke-width=".6"/>
              </g>
              <g class="canopy" style="opacity: calc(1 - var(--bare-show));">
                <path d="M3 28 1 25l1-5 3-2-1-4 4-4 3 1 2-5 5 2 1 5 3 2-1 5 2 3-2 5-4 3-6 1-5-2z" fill="var(--leaf-canopy-3)"/>
                <path d="M3 19 5 13l5-3 4 2 2-5 4 4-1 5 3 3-2 4-5 1-4-3-5 2z" fill="var(--leaf-canopy-2)"/>
                <path d="M4 17 6 12l4-1 2-6 5 1 2 4-2 4-5 1-2 4z" fill="var(--leaf-canopy-1)"/>
                <path d="M7 12 9 9l3 1 2-5 2 2-1 4-4 2-2 3z" fill="var(--leaf-light)" opacity=".8"/>
                <path d="M5 25h5m4 3h4M3 20h2m12-8h2" fill="none" stroke="var(--leaf-shadow)" stroke-width="1.3" opacity=".7"/>
              </g>
              <g class="snow-cap" style="opacity: var(--snow-opacity);">
                <path d="M3 18l2-3 2 1 2-3m7-3 2-2 2 3M4 23l-2 2 2 2m12-3 2 1 3-2M9 7l3-2 3 1" fill="none" stroke="var(--snow-top)" stroke-width="1.7" stroke-linecap="round"/>
                <path d="M9 45h6v2H9z" fill="var(--snow-mid)"/>
              </g>
            </svg>`;
          } else if (species === "pine") {
            // Drooping boughs break the repeated triangle silhouette.
            return `<svg viewBox="0 0 24 48" xmlns="http://www.w3.org/2000/svg">
              <g class="bark">
                <path d="M10 34h4v14h-4z" fill="var(--bark)"/>
                <path d="M11 36h1v12h-1z" fill="var(--bark-light)"/>
              </g>
              <g class="canopy">
                <path d="M12 1 9 12l-4 9 2 1-5 12 5-1-4 8 9-2 8 2-3-8 5 1-5-12 2-1-4-9z" fill="var(--leaf-pine-dark)"/>
                <path d="m12 3-2 10-3 8 4-2-5 12 5-3-5 10 6-2 4 2-3-11 5 3-5-12 3 2-3-8z" fill="var(--leaf-pine-mid)"/>
                <path d="m12 4-1 9-2 5 3-2-3 10 3-3-2 9 3-5V8z" fill="var(--leaf-pine-light)" opacity=".9"/>
                <path d="M4 34h5m7 0h4M6 25h4m5 0h4M9 16h6" fill="none" stroke="var(--leaf-pine-dark)" stroke-width="1.2" opacity=".75"/>
              </g>
              <g class="snow-cap" style="opacity: var(--snow-opacity);">
                <path d="m12 2-2 9 2-2 2 2zm-3 14-2 5 4-2m4-3 2 5-4-2M6 26l-3 8 6-3m9-5 3 8-6-3M5 35l-2 6 9-2 8 2-2-6" fill="var(--snow-top)"/>
                <path d="M5 41h14" stroke="var(--snow-low)" stroke-width="1"/>
              </g>
            </svg>`;
          } else {
            // Orchard tree, lower and more open than the oak.
            return `<svg viewBox="0 0 24 48" xmlns="http://www.w3.org/2000/svg">
              <g class="bark">
                <path d="M10 48V31l2-6 2 6v17z" fill="var(--bark)"/>
                <path d="M11 47V32l1-5v20z" fill="var(--bark-light)"/>
              </g>
              <g class="bare-branches" opacity="var(--bare-show)">
                <path d="M12 33V15m0 14L5 21m7 5 7-8M8 24l1-12m7 10-1-13M5 21l-2-5m2 5-3 2m17-5 2-5m-2 5 3 2" fill="none" stroke="var(--bark)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
              </g>
              <g class="canopy" style="opacity: calc(1 - var(--bare-show));">
                <path d="M2 26 1 21l3-4-1-5 4-3 5 1 2-4 5 2 1 5 3 3-1 6 1 4-4 4-7-1-5 2z" fill="var(--leaf-canopy-3)"/>
                <path d="M3 19 5 12l5-2 3 2 3-4 4 3-1 5 3 3-3 5-5-2-5 3-5-2z" fill="var(--leaf-canopy-2)"/>
                <path d="M4 17 7 11l5 1 3-5 4 3-1 5-4 3-5-2-3 4z" fill="var(--leaf-canopy-1)"/>
                <path d="M6 14 9 11l3 2 3-5 3 2-2 4-4 1-3 4z" fill="var(--leaf-light)" opacity=".7"/>
                <path d="M4 24h4m7 2h4M18 17h3" fill="none" stroke="var(--leaf-shadow)" stroke-width="1.2"/>
              </g>
              <g class="fruits" style="opacity: var(--fruit-show);">
                <circle cx="7" cy="18" r="1.4" fill="#d85b3f"/>
                <circle cx="16" cy="16" r="1.5" fill="#e66b43"/>
                <circle cx="10" cy="23" r="1.3" fill="#c94339"/>
                <circle cx="19" cy="22" r="1.2" fill="#c94339"/>
                <circle cx="5" cy="26" r="1.2" fill="#e66b43"/>
              </g>
              <g class="snow-cap" style="opacity: var(--snow-opacity);">
                <path d="M4 17l3-4 3 1m4-5 2-2 3 2M2 24l3 1 2-2m9-5 4-2 2 2M10 45h4" fill="none" stroke="var(--snow-top)" stroke-width="1.7" stroke-linecap="round"/>
              </g>
            </svg>`;
          }
        }
        function pickTreeSpecies() {
          const v = Math.random();
          if (v < 0.45) return "oak";
          if (v < 0.78) return "pine";
          return "fruit";
        }
        function treeSpacing() {
          return Math.max(24, Math.min(TREE_MIN_SPACING, W() * 0.07));
        }
        function treeStructureSpacing() {
          return Math.max(16, Math.min(TREE_STRUCTURE_SPACING, W() * 0.05));
        }
        function findTreeSpot() {
          const minTreeGap = treeSpacing();
          const minStructureGap = treeStructureSpacing();
          for (let i = 0; i < TREE_SPOT_ATTEMPTS; i++) {
            const x = 32 + Math.random() * (W() - 64);
            const free = !trees.some((t) => Math.abs(t.x - x) < minTreeGap)
                      && !houses.some((h) => Math.abs(h.x - x) < minStructureGap)
                      && !STARTER_STRUCTURE_SEEDS.some((s) => Math.abs((s.pos * W()) - x) < minStructureGap);
            if (free) return x;
          }
          return null;
        }
        function plantTree(immediate = false, silent = false) {
          if (trees.length >= (innerWidth < 640 ? 28 : 38)) return null;
          const x = findTreeSpot();
          if (x == null) return null;
          const species = pickTreeSpecies();
          const t = document.createElement("div");
          t.className = "tree";
          t.dataset.species = species;
          t.innerHTML = makeTreeSVG(species);
          t.style.left = x + "px";
          t.style.setProperty("--g", "0");
          treesLayer.appendChild(t);
          const rec = { el: t, x, stage: 0, species };
          trees.push(rec);
          if (immediate) {
            rec.stage = treeStages.length - 1;
            t.style.setProperty("--g", treeStages[rec.stage]);
            return rec;
          }
          if (!silent) logEvent("A sapling takes root.");
          function step() {
            if (!t.isConnected) return;
            rec.stage++;
            if (rec.stage >= treeStages.length) {
              if (!silent) logEvent("A tree stands tall.", "good");
              if (Math.random() < 0.7) {
                setTimeout(() => {
                  if (t.isConnected) plantTree(false, true);
                }, 6000 + Math.random() * 10000);
              }
              return;
            }
            t.style.setProperty("--g", treeStages[rec.stage]);
            setTimeout(step, 5000 + Math.random() * 4000);
          }
          setTimeout(step, 1500);
          return rec;
        }
        function plantTreeBurst(immediate = false, count = 2, stagger = 80) {
          for (let i = 0; i < count; i++) {
            setTimeout(() => plantTree(immediate, i > 0), i * stagger);
          }
        }
        function backTreeLimit() {
          return innerWidth < 640 ? 28 : Math.max(9, Math.min(46, Math.floor(W() / 32)));
        }
        function findBackTreeSpot() {
          const minGap = Math.max(18, Math.min(BACK_TREE_MIN_SPACING, W() * 0.045));
          for (let i = 0; i < BACK_TREE_SPOT_ATTEMPTS; i++) {
            const x = 14 + Math.random() * (W() - 28);
            if (!backTrees.some((t) => Math.abs(t.x - x) < minGap)) return x;
          }
          return null;
        }
        function plantBackTree(immediate = false) {
          if (backTrees.length >= backTreeLimit()) return null;
          const x = findBackTreeSpot();
          if (x == null) return null;
          const species = pickTreeSpecies();
          const t = document.createElement("div");
          t.className = "tree back-tree";
          t.dataset.species = species;
          t.innerHTML = makeTreeSVG(species);
          t.style.left = x + "px";
          t.style.setProperty("--g", "0");
          t.style.opacity = (0.58 + Math.random() * 0.2).toFixed(2);
          backTreesLayer.appendChild(t);
          const rec = { el: t, x, stage: 0, species };
          backTrees.push(rec);
          if (immediate) {
            rec.stage = treeStages.length - 1;
            t.style.setProperty("--g", treeStages[rec.stage]);
            return rec;
          }
          function step() {
            if (!t.isConnected) return;
            rec.stage++;
            if (rec.stage >= treeStages.length) {
              if (Math.random() < 0.45) setTimeout(() => plantBackTree(false), 7000 + Math.random() * 11000);
              return;
            }
            t.style.setProperty("--g", treeStages[rec.stage]);
            setTimeout(step, 5500 + Math.random() * 4500);
          }
          setTimeout(step, 1200);
          return rec;
        }
        function plantBackTreeBurst(immediate = false, count = 3, stagger = 70) {
          for (let i = 0; i < count; i++) {
            setTimeout(() => plantBackTree(immediate), i * stagger);
          }
        }
        function hillTreeLayerLimit(layer) {
          if (innerWidth < 640) return layer === "far" ? 20 : 16;
          if (layer === "far") return Math.max(8, Math.min(34, Math.floor(W() / 44)));
          return Math.max(6, Math.min(28, Math.floor(W() / 54)));
        }
        function hillTreeCount(layer) {
          return hillTrees.filter((t) => t.layer === layer).length;
        }
        function quadraticY(x, segments) {
          const segment = segments.find((s) => x <= s.end[0]) || segments[segments.length - 1];
          const startX = segment.start[0];
          const endX = segment.end[0];
          const t = Math.max(0, Math.min(1, (x - startX) / (endX - startX)));
          const inv = 1 - t;
          return inv * inv * segment.start[1] + 2 * inv * t * segment.control[1] + t * t * segment.end[1];
        }
        const HILL_CURVES = {
          far: {
            height: 100,
            offset: 30,
            segments: [
              { start: [0, 60], control: [70, 30], end: [140, 55] },
              { start: [140, 55], control: [210, 80], end: [280, 50] },
              { start: [280, 50], control: [350, 25], end: [420, 55] },
              { start: [420, 55], control: [490, 80], end: [560, 55] },
              { start: [560, 55], control: [630, 30], end: [700, 55] },
              { start: [700, 55], control: [770, 80], end: [840, 55] },
              { start: [840, 55], control: [910, 30], end: [980, 55] },
              { start: [980, 55], control: [1050, 80], end: [1120, 55] },
              { start: [1120, 55], control: [1170, 40], end: [1200, 60] },
            ],
          },
          near: {
            height: 80,
            offset: 0,
            segments: [
              { start: [0, 40], control: [100, 5], end: [200, 35] },
              { start: [200, 35], control: [310, 60], end: [410, 30] },
              { start: [410, 30], control: [510, 5], end: [600, 30] },
              { start: [600, 30], control: [700, 60], end: [810, 30] },
              { start: [810, 30], control: [920, 5], end: [1020, 35] },
              { start: [1020, 35], control: [1110, 60], end: [1200, 40] },
            ],
          },
        };
        function hillBottomAt(layer, x) {
          const curve = HILL_CURVES[layer];
          const svgX = (x / W()) * 1200;
          return curve.offset + curve.height - quadraticY(svgX, curve.segments);
        }
        function findHillTreeSpot(layer) {
          const minGap = Math.max(20, Math.min(HILL_TREE_MIN_SPACING, W() * 0.055));
          for (let i = 0; i < HILL_TREE_SPOT_ATTEMPTS; i++) {
            const x = 12 + Math.random() * (W() - 24);
            if (!hillTrees.some((t) => t.layer === layer && Math.abs(t.x - x) < minGap)) return x;
          }
          return null;
        }
        function plantHillTree(immediate = false, layer = Math.random() < 0.58 ? "far" : "near") {
          if (hillTreeCount(layer) >= hillTreeLayerLimit(layer)) layer = layer === "far" ? "near" : "far";
          if (hillTreeCount(layer) >= hillTreeLayerLimit(layer)) return null;
          const x = findHillTreeSpot(layer);
          if (x == null) return null;
          const species = pickTreeSpecies();
          const t = document.createElement("div");
          t.className = `tree hill-tree hill-tree-${layer}`;
          t.dataset.species = species;
          t.innerHTML = makeTreeSVG(species);
          t.style.left = x + "px";
          t.style.setProperty("--g", "0");
          t.style.setProperty("--hill-bottom", `${hillBottomAt(layer, x) - (layer === "far" ? 1 : 0)}px`);
          const w = layer === "far" ? 9 + Math.random() * 5 : 12 + Math.random() * 6;
          t.style.setProperty("--hill-tree-w", `${w}px`);
          t.style.setProperty("--hill-tree-h", `${w * 2}px`);
          t.style.opacity = (layer === "far" ? 0.48 + Math.random() * 0.16 : 0.58 + Math.random() * 0.18).toFixed(2);
          (layer === "far" ? hillTreesFarLayer : hillTreesNearLayer).appendChild(t);
          const rec = { el: t, x, stage: 0, species, layer };
          hillTrees.push(rec);
          if (immediate) {
            rec.stage = treeStages.length - 1;
            t.style.setProperty("--g", treeStages[rec.stage]);
            return rec;
          }
          function step() {
            if (!t.isConnected) return;
            rec.stage++;
            if (rec.stage >= treeStages.length) {
              if (Math.random() < 0.4) setTimeout(() => plantHillTree(false, layer), 8000 + Math.random() * 12000);
              return;
            }
            t.style.setProperty("--g", treeStages[rec.stage]);
            setTimeout(step, 6000 + Math.random() * 5000);
          }
          setTimeout(step, 1400);
          return rec;
        }
        function plantHillTreeBurst(immediate = false, count = 3, stagger = 70) {
          for (let i = 0; i < count; i++) {
            setTimeout(() => plantHillTree(immediate), i * stagger);
          }
        }
        function removeTree(rec) {
          const i = trees.indexOf(rec);
          if (i >= 0) trees.splice(i, 1);
        }
        function removeBackTree(rec) {
          const i = backTrees.indexOf(rec);
          if (i >= 0) backTrees.splice(i, 1);
        }
        function removeHillTree(rec) {
          const i = hillTrees.indexOf(rec);
          if (i >= 0) hillTrees.splice(i, 1);
        }

        /* ============= STRUCTURES (houses, towers, wells, signposts, campfires) ============= */
        const houses = [];
        let castleBuildReserved = false;
        const pendingStructureKindCounts = new Map();
        function hasCastleOrPendingBuild() {
          return castleBuildReserved || houses.some((h) => h.kind === "castle" && h.el.isConnected);
        }
        function reserveCastleBuild() {
          if (hasCastleOrPendingBuild()) return false;
          castleBuildReserved = true;
          return true;
        }
        function clearCastleBuildReservation() {
          castleBuildReserved = false;
        }
        function pendingStructureKindCount(kind) {
          return pendingStructureKindCounts.get(kind) || 0;
        }
        function reservePendingStructureKind(kind) {
          if (!kind || kind === "castle") return false;
          pendingStructureKindCounts.set(kind, pendingStructureKindCount(kind) + 1);
          return true;
        }
        function clearPendingStructureKind(kind) {
          if (!kind || kind === "castle") return;
          const next = pendingStructureKindCount(kind) - 1;
          if (next > 0) pendingStructureKindCounts.set(kind, next);
          else pendingStructureKindCounts.delete(kind);
        }
        const STRUCTURE_KINDS = ["house", "tower", "well", "signpost", "campfire", "castle", "tavern", "guildhall", "mill", "lamppost", "garden", "statue", "marketstall", "guardpost", "blacksmith"];
        const CASTLE_UPGRADE_WIDTHS = [200, 240, 290, 360, 430, 430, 430, 430, 430, 430, 430];
        const CASTLE_UPGRADE_HEIGHTS = [150, 156, 168, 184, 204, 214, 226, 238, 250, 262, 274];
        const CASTLE_MAX_UPGRADE = CASTLE_UPGRADE_WIDTHS.length - 1;
        const CASTLE_NORMAL_ATTACK_IMMUNE_LEVEL = 4;
        const CASTLE_HUGE_DRAGON_TARGET_LEVEL = CASTLE_NORMAL_ATTACK_IMMUNE_LEVEL;

        /* Footprint widths used for depth-lane collision checks. Mirrors the CSS widths above. */
        const KIND_WIDTHS = {
          house: 48, tower: 32, well: 28, signpost: 22, campfire: 34, castle: 200,
          tavern: 72, guildhall: 66, mill: 44, lamppost: 18, garden: 32, statue: 22,
          marketstall: 32, guardpost: 24, blacksmith: 46,
        };
        const HOUSE_VARIANT_WIDTHS = {
          cottage: [48, 56, 80, 104, 128],
          "two-story": [44, 60, 78, 100, 122],
          "a-frame": [48, 64, 82, 104, 126],
          longhouse: [64, 84, 104, 124, 144],
        };
        const STRUCTURE_UPGRADE_WIDTHS = {
          tower: [32, 38, 42, 46, 50],
          castle: CASTLE_UPGRADE_WIDTHS,
          mill: [44, 60, 78, 100, 124],
          marketstall: [32, 52, 80, 120, 120],
          tavern: [72, 84, 108, 132, 158],
          guildhall: [66, 78, 100, 124, 150],
          lamppost: [18, 18, 18, 18, 18],
        };
        const BACK_LANE_MIN_WIDTH = 64;
        function widthForUpgrade(widths, upgrade, fallback) {
          const i = Math.max(0, Math.min(widths.length - 1, upgrade ?? 0));
          return widths[i] ?? fallback;
        }
        function houseFootprintWidth(kind, palette, upgrade) {
          if (kind === "house") {
            const variant = palette?.variant || "cottage";
            return widthForUpgrade(HOUSE_VARIANT_WIDTHS[variant] || HOUSE_VARIANT_WIDTHS.cottage, upgrade, 48);
          }
          if (STRUCTURE_UPGRADE_WIDTHS[kind]) {
            return widthForUpgrade(STRUCTURE_UPGRADE_WIDTHS[kind], upgrade, KIND_WIDTHS[kind] ?? 48);
          }
          return KIND_WIDTHS[kind] ?? 48;
        }
        function usesCenteredStructureX(kind, upgrade = 0) {
          return kind === "castle"
              || kind === "tower"
              || ((upgrade ?? 0) > 0 && (
                kind === "house" || kind === "tavern" || kind === "guildhall" || kind === "mill"
              ));
        }
        function structureFootprintBounds(x, kind, palette, upgrade) {
          const w = houseFootprintWidth(kind, palette, upgrade);
          if (usesCenteredStructureX(kind, upgrade)) {
            return { left: x - w / 2, right: x + w / 2 };
          }
          return { left: x, right: x + w };
        }
        function structureVisualCenter(x, kind, palette, upgrade) {
          const w = houseFootprintWidth(kind, palette, upgrade);
          return usesCenteredStructureX(kind, upgrade) ? x : x + w / 2;
        }
        function anchorXForStructureCenter(center, kind, palette, upgrade) {
          const w = houseFootprintWidth(kind, palette, upgrade);
          return usesCenteredStructureX(kind, upgrade) ? center : center - w / 2;
        }
        function projectedStructureXForUpgrade(rec, upgrade) {
          const center = structureVisualCenter(rec.x, rec.kind, rec.palette, rec.upgrade || 0);
          return anchorXForStructureCenter(center, rec.kind, rec.palette, upgrade || 0);
        }
        function setStructureAnchorX(rec, x) {
          rec.x = x;
          rec.el.style.left = x + "px";
        }
        function rangesOverlap(a, b) {
          return a.right > b.left && a.left < b.right;
        }
        const MAIN_CASTLE_APPROACH_PADDING = 80;
        function castleApproachWidth(upgradeOverride = null) {
          const castle = houses.find((h) => h.kind === "castle" && h.el.isConnected);
          const upgrade = upgradeOverride ?? (castle ? (castle.upgrade || 0) : 0);
          return widthForUpgrade(STRUCTURE_UPGRADE_WIDTHS.castle, upgrade, KIND_WIDTHS.castle);
        }
        function mainCastleApproachBounds(upgradeOverride = null) {
          const castleWidth = castleApproachWidth(upgradeOverride);
          const halfWidth = Math.min(W() / 2 - 28, castleWidth / 2 + MAIN_CASTLE_APPROACH_PADDING);
          const center = W() / 2;
          return { left: center - halfWidth, right: center + halfWidth };
        }
        function blocksMainCastleApproach(x, kind, palette, upgrade, castleUpgradeOverride = null) {
          if (!kind || kind === "castle" || !STRUCTURE_KINDS.includes(kind)) return false;
          if (kind === "lamppost") return false;
          return rangesOverlap(
            structureFootprintBounds(x, kind, palette, upgrade),
            mainCastleApproachBounds(castleUpgradeOverride)
          );
        }
        function expandedBounds(bounds, pad) {
          return { left: bounds.left - pad, right: bounds.right + pad };
        }
        function structureClearance(kind) {
          if (kind === "castle") return 28;
          if (kind === "marketstall") return 22;
          if (kind === "well" || kind === "signpost" || kind === "campfire" || kind === "garden" || kind === "statue" || kind === "lamppost") return 10;
          return 20;
        }
        function structureTreeClearance(kind, palette, upgrade) {
          return canUseRoadsideLane(kind, palette, upgrade) ? 42 : 70;
        }
        function hasStructureClearance(x, kind, palette, upgrade, currentRec = null) {
          const a = expandedBounds(
            structureFootprintBounds(x, kind, palette, upgrade),
            structureClearance(kind)
          );
          return !houses.some((h) => {
            if (h === currentRec || !h.el.isConnected) return false;
            const hb = expandedBounds(
              structureFootprintBounds(h.x, h.kind, h.palette, h.upgrade || 0),
              structureClearance(h.kind)
            );
            return rangesOverlap(a, hb);
          });
        }
        function structureFitsViewport(x, kind, palette, upgrade, margin) {
          const b = structureFootprintBounds(x, kind, palette, upgrade);
          return b.left >= margin && b.right <= W() - margin;
        }
        function structureSpotIsFree(x, kind, palette, upgrade, opts = {}) {
          const margin = opts.margin ?? Math.max(32, Math.min(92, W() * 0.08));
          if (!structureFitsViewport(x, kind, palette, upgrade, margin)) return false;
          if (opts.avoidCastleApproach !== false && blocksMainCastleApproach(x, kind, palette, upgrade, opts.castleUpgradeOverride ?? null)) return false;
          const treeGap = opts.treeGap ?? structureTreeClearance(kind, palette, upgrade);
          if (trees.some((t) => Math.abs(t.x - x) < treeGap)) return false;
          return hasStructureClearance(x, kind, palette, upgrade, opts.currentRec || null);
        }
        function structureRangeGap(a, b) {
          if (rangesOverlap(a, b)) return 0;
          return a.right <= b.left ? b.left - a.right : a.left - b.right;
        }
        function nearestStructureGap(x, kind, palette, upgrade, currentRec = null) {
          const a = structureFootprintBounds(x, kind, palette, upgrade);
          let nearest = W();
          houses.forEach((h) => {
            if (h === currentRec || !h.el.isConnected) return;
            const hb = structureFootprintBounds(h.x, h.kind, h.palette, h.upgrade || 0);
            nearest = Math.min(nearest, structureRangeGap(a, hb));
          });
          return nearest;
        }
        function substantialStructureCount(side) {
          return houses.filter((h) => {
            if (!h.el.isConnected) return false;
            if (h.kind === "castle" || h.kind === "marketstall" || h.kind === "lamppost" || h.kind === "signpost" || h.kind === "campfire" || h.kind === "garden" || h.kind === "statue") return false;
            return side === "left" ? h.x < W() / 2 : h.x >= W() / 2;
          }).length;
        }
        function preferredOpenSide(kind) {
          if (kind === "marketstall" || kind === "castle") return null;
          const left = substantialStructureCount("left");
          const right = substantialStructureCount("right");
          if (Math.abs(left - right) < 2) return null;
          return left < right ? "left" : "right";
        }
        function makeRoomForMainCastle(upgradeOverride = null) {
          const approach = mainCastleApproachBounds(upgradeOverride);
          houses
            .filter((rec) => {
              if (rec.kind === "castle" || rec.kind === "lamppost" || !rec.el.isConnected) return false;
              const b = expandedBounds(
                structureFootprintBounds(rec.x, rec.kind, rec.palette, rec.upgrade || 0),
                structureClearance(rec.kind)
              );
              return rangesOverlap(b, approach);
            })
            .forEach((rec) => {
              const preferredSide = rec.x < W() / 2 ? "left" : "right";
              const x = findOpenSpot(rec.kind, rec.palette, rec.upgrade || 0, {
                currentRec: rec,
                preferredSide,
                castleUpgradeOverride: upgradeOverride,
              });
              if (x == null) return;
              setStructureAnchorX(rec, x);
              applyLane(rec, pickLane(rec.x, rec.kind, rec.palette, rec.upgrade || 0, rec));
            });
        }
        /* The road-adjacent band is only for light decorations and small market stalls.
           Houses and larger buildings stay in the back lane so the roadside stays open. */
        const ROADSIDE_DECORATION_KINDS = new Set([
          "well", "signpost", "campfire", "lamppost", "garden", "statue",
        ]);
        function isSmallMarketStall(kind, palette, upgrade) {
          return kind === "marketstall" && houseFootprintWidth(kind, palette, upgrade) < BACK_LANE_MIN_WIDTH;
        }
        function canUseRoadsideLane(kind, palette, upgrade) {
          return ROADSIDE_DECORATION_KINDS.has(kind) || isSmallMarketStall(kind, palette, upgrade);
        }
        function preferredLaneOrder(kind, palette, upgrade) {
          if (canUseRoadsideLane(kind, palette, upgrade)) return ["road", "front", "back"];
          return ["back"];
        }
        /* Pick a depth lane by size preference, then collision with existing buildings in the same lane. */
        function pickLane(x, kind, palette, upgrade, currentRec = null) {
          if (kind === "castle") return "back";
          const pad = Math.max(8, Math.floor(structureClearance(kind) * 0.5));
          const a = structureFootprintBounds(x, kind, palette, upgrade);
          const aL = a.left - pad, aR = a.right + pad;
          const overlaps = (lane) => houses.some((h) => {
            if (h === currentRec) return false;
            if (h.lane !== lane) return false;
            const hb = structureFootprintBounds(h.x, h.kind, h.palette, h.upgrade);
            const hPad = Math.max(8, Math.floor(structureClearance(h.kind) * 0.5));
            return aR > hb.left - hPad && aL < hb.right + hPad;
          });
          const lanes = preferredLaneOrder(kind, palette, upgrade);
          for (const lane of lanes) {
            if (!overlaps(lane)) return lane;
          }
          return lanes[0]; // all crowded — accept the squeeze in the size-preferred lane
        }
        function applyLane(rec, lane) {
          rec.lane = lane;
          rec.el.dataset.lane = lane;
          rec.el.classList.remove("lane-back", "lane-road", "lane-front");
          rec.el.classList.add("lane-" + lane);
        }

        /* ============= AMBIENT DECORATION ============= */
        let ambientRefreshTimer = null;
        let wetGroundTimer = null;
        let ambientLayoutKey = "";
        let ambientHouseSeedCounter = 0;

        function clamp(n, min, max) {
          return Math.max(min, Math.min(max, n));
        }

        function hashSeed(seed) {
          let h = 2166136261;
          const str = String(seed);
          for (let i = 0; i < str.length; i++) {
            h ^= str.charCodeAt(i);
            h = Math.imul(h, 16777619);
          }
          return h >>> 0;
        }

        function seededRand(seed) {
          let h = hashSeed(seed);
          return function () {
            h += 0x6D2B79F5;
            let t = h;
            t = Math.imul(t ^ (t >>> 15), t | 1);
            t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
          };
        }

        function seededPick(arr, seed) {
          if (!arr || arr.length === 0) return null;
          const r = seededRand(seed)();
          return arr[Math.min(arr.length - 1, Math.floor(r * arr.length))];
        }

        function stableScale(opts, rand) {
          if (opts.scale != null) return opts.scale;
          if (opts.scaleRange) return opts.scaleRange[0] + rand() * (opts.scaleRange[1] - opts.scaleRange[0]);
          return 1;
        }

        function ensureAmbientSeed(rec) {
          if (!rec.ambientSeed) {
            const seed = rec.el.dataset.ambientSeed || ("house-" + (++ambientHouseSeedCounter));
            rec.ambientSeed = seed;
            rec.el.dataset.ambientSeed = seed;
          }
          return rec.ambientSeed;
        }

        function ambientDecorKey(width, roadTier, built) {
          const widthBucket = Math.round(width / 16);
          const houseBits = built
            .slice()
            .sort((a, b) => a.x - b.x)
            .map((h) => [
              ensureAmbientSeed(h),
              h.kind,
              Math.round(h.x),
              h.lane || "",
              h.upgrade || 0,
            ].join(":"))
            .join("|");
          return [widthBucket, roadTier, currentSeason, houseBits].join("#");
        }

        function laneBottom(lane) {
          if (lane === "back") return 50;
          if (lane === "front") return 34;
          return 38;
        }

        function decorSVG(kind) {
          switch (kind) {
            case "fence": return `<svg viewBox="0 0 48 16" xmlns="http://www.w3.org/2000/svg">
              <rect x="1" y="6" width="46" height="3" fill="#6a4828"/>
              <rect x="1" y="11" width="46" height="2" fill="#4a2a14"/>
              <rect x="5" y="2" width="4" height="14" fill="#8a5a2e"/>
              <rect x="24" y="1" width="4" height="15" fill="#7a4828"/>
              <rect x="39" y="3" width="4" height="13" fill="#8a5a2e"/>
              <rect x="5" y="2" width="4" height="1" fill="#b08048"/>
              <rect x="24" y="1" width="4" height="1" fill="#b08048"/>
            </svg>`;
            case "milestone": return `<svg viewBox="0 0 14 18" xmlns="http://www.w3.org/2000/svg">
              <path d="M2 18V7Q2 2 7 2T12 7V18Z" fill="#81786a"/>
              <path d="M4 17V7Q4 4 7 4T10 7V17Z" fill="#a8a098"/>
              <rect x="5" y="8" width="4" height="1" fill="#403830"/>
              <rect x="5" y="11" width="3" height="1" fill="#403830"/>
            </svg>`;
            case "shrine": return `<svg viewBox="0 0 20 28" xmlns="http://www.w3.org/2000/svg">
              <rect x="3" y="24" width="14" height="4" fill="#5a5048"/>
              <rect x="5" y="12" width="10" height="12" fill="#887c70"/>
              <rect x="7" y="15" width="6" height="7" fill="#2a2020"/>
              <rect class="glow" x="8" y="16" width="4" height="5" fill="#f0d060"/>
              <polygon points="2,12 10,4 18,12" fill="#5a3038"/>
              <rect x="9" y="1" width="2" height="5" fill="#d4a017"/>
            </svg>`;
            case "barrel": return `<svg viewBox="0 0 16 18" xmlns="http://www.w3.org/2000/svg">
              <rect x="3" y="2" width="10" height="14" rx="2" fill="#7a4828"/>
              <rect x="4" y="3" width="8" height="12" fill="#9a6030"/>
              <rect x="2" y="5" width="12" height="2" fill="#3a2410"/>
              <rect x="2" y="12" width="12" height="2" fill="#3a2410"/>
              <rect x="7" y="3" width="2" height="12" fill="#b07838" opacity="0.55"/>
            </svg>`;
            case "crate": return `<svg viewBox="0 0 18 16" xmlns="http://www.w3.org/2000/svg">
              <rect x="2" y="3" width="14" height="11" fill="#8a5a2e"/>
              <rect x="2" y="3" width="14" height="2" fill="#b07838"/>
              <rect x="4" y="5" width="2" height="9" fill="#5a3418"/>
              <rect x="12" y="5" width="2" height="9" fill="#5a3418"/>
              <path d="M3 13L15 5M3 5L15 13" stroke="#5a3418" stroke-width="1.4"/>
            </svg>`;
            case "hay": return `<svg viewBox="0 0 22 14" xmlns="http://www.w3.org/2000/svg">
              <rect x="2" y="5" width="18" height="7" fill="#c89840"/>
              <rect x="3" y="3" width="16" height="3" fill="#e0b858"/>
              <rect x="5" y="6" width="2" height="6" fill="#8a6420"/>
              <rect x="14" y="5" width="2" height="7" fill="#8a6420"/>
              <rect x="2" y="9" width="18" height="1" fill="#8a6420"/>
            </svg>`;
            case "lantern": return `<svg viewBox="0 0 14 24" xmlns="http://www.w3.org/2000/svg">
              <rect x="6" y="1" width="2" height="7" fill="#3a2410"/>
              <rect x="3" y="7" width="8" height="2" fill="#2a1a10"/>
              <rect x="4" y="9" width="6" height="8" fill="#15110d"/>
              <rect class="glow" x="5" y="10" width="4" height="6" fill="#f0c440"/>
              <rect x="3" y="17" width="8" height="2" fill="#2a1a10"/>
              <rect x="6" y="19" width="2" height="5" fill="#5a3818"/>
            </svg>`;
            case "banner": return `<svg viewBox="0 0 18 30" xmlns="http://www.w3.org/2000/svg">
              <rect x="4" y="2" width="2" height="26" fill="#5a3818"/>
              <path class="cloth" d="M6 4H17V18L12 15L6 18Z" fill="#7a2848"/>
              <rect class="cloth" x="7" y="5" width="9" height="2" fill="#a83860"/>
              <rect x="8" y="9" width="3" height="3" fill="#d4a017"/>
            </svg>`;
            case "flowerpot": return `<svg viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
              <rect x="4" y="9" width="10" height="7" fill="#7a3828"/>
              <rect x="3" y="8" width="12" height="2" fill="#a85038"/>
              <rect x="8" y="4" width="2" height="5" fill="#2f6a38"/>
              <rect x="5" y="5" width="3" height="3" fill="#e088c0"/>
              <rect x="10" y="3" width="3" height="3" fill="#f0d060"/>
              <rect x="11" y="7" width="3" height="3" fill="#c84a35"/>
            </svg>`;
            case "leafpile": return `<svg viewBox="0 0 24 12" xmlns="http://www.w3.org/2000/svg">
              <ellipse cx="7" cy="8" rx="6" ry="3" fill="#9a4a20"/>
              <ellipse cx="14" cy="7" rx="7" ry="4" fill="#c87828"/>
              <ellipse cx="18" cy="9" rx="5" ry="3" fill="#d4a017"/>
              <rect x="8" y="4" width="6" height="2" fill="#7a3818" transform="rotate(-20 11 5)"/>
            </svg>`;
            case "petals": return `<svg viewBox="0 0 22 12" xmlns="http://www.w3.org/2000/svg">
              <rect x="3" y="7" width="3" height="2" fill="#f0a8c8"/>
              <rect x="9" y="4" width="3" height="2" fill="#ffd0dc"/>
              <rect x="15" y="8" width="3" height="2" fill="#e088b0"/>
              <rect x="18" y="5" width="2" height="2" fill="#ffd0dc"/>
            </svg>`;
            case "flowers": return `<svg viewBox="0 0 24 16" xmlns="http://www.w3.org/2000/svg">
              <rect x="5" y="9" width="1" height="5" fill="#2f6a38"/>
              <rect x="12" y="7" width="1" height="7" fill="#2f6a38"/>
              <rect x="18" y="10" width="1" height="4" fill="#2f6a38"/>
              <rect x="4" y="7" width="3" height="3" fill="#f0d060"/>
              <rect x="11" y="5" width="3" height="3" fill="#e088c0"/>
              <rect x="17" y="8" width="3" height="3" fill="#c878ff"/>
              <rect x="2" y="14" width="20" height="1" fill="#2f6a38"/>
            </svg>`;
            case "snowdrift": return `<svg viewBox="0 0 28 10" xmlns="http://www.w3.org/2000/svg">
              <ellipse cx="8" cy="7" rx="8" ry="3" fill="#f2f7ff"/>
              <ellipse cx="19" cy="6" rx="9" ry="4" fill="#dce8f4"/>
              <rect x="4" y="7" width="20" height="2" fill="#f7fbff"/>
            </svg>`;
            case "puddle": return `<svg viewBox="0 0 34 12" xmlns="http://www.w3.org/2000/svg">
              <ellipse cx="17" cy="7" rx="14" ry="4" fill="#1e3340" opacity="0.62"/>
              <ellipse class="ripple" cx="13" cy="7" rx="5" ry="1.8" fill="none" stroke="#8ab0c0" stroke-width="0.7"/>
              <ellipse class="ripple" cx="22" cy="6" rx="4" ry="1.4" fill="none" stroke="#8ab0c0" stroke-width="0.7"/>
            </svg>`;
            case "rune": return `<svg viewBox="0 0 16 18" xmlns="http://www.w3.org/2000/svg">
              <rect x="7" y="3" width="2" height="12" fill="#403060"/>
              <path class="rune glow" d="M8 3L4 8H8L5 15L12 7H8Z" fill="#b080ff"/>
            </svg>`;
            case "glowmushroom": return `<svg viewBox="0 0 18 16" xmlns="http://www.w3.org/2000/svg">
              <rect x="7" y="8" width="4" height="7" fill="#e0d8c8"/>
              <path class="cap glow" d="M2 9Q9 1 16 9Z" fill="#b080ff"/>
              <rect x="5" y="7" width="2" height="1" fill="#f2e8ff"/>
              <rect x="10" y="5" width="2" height="1" fill="#f2e8ff"/>
            </svg>`;
            case "charm": return `<svg viewBox="0 0 14 22" xmlns="http://www.w3.org/2000/svg">
              <rect x="6" y="1" width="1" height="9" fill="#d8c080"/>
              <path class="charm" d="M3 9H11L9 18H5Z" fill="#6a3a8a"/>
              <rect class="glow" x="6" y="12" width="2" height="2" fill="#f0d060"/>
            </svg>`;
            case "broom": return `<svg viewBox="0 0 24 18" xmlns="http://www.w3.org/2000/svg">
              <rect x="2" y="12" width="16" height="2" fill="#6a4828" transform="rotate(-17 10 13)"/>
              <path d="M15 9L23 5L22 14L15 15Z" fill="#b08040"/>
              <rect x="16" y="8" width="7" height="1" fill="#e0b858"/>
              <rect x="16" y="12" width="7" height="1" fill="#704418"/>
            </svg>`;
            case "herbs": return `<svg viewBox="0 0 18 20" xmlns="http://www.w3.org/2000/svg">
              <rect x="8" y="8" width="1" height="10" fill="#3f7a38"/>
              <rect x="5" y="10" width="1" height="8" fill="#3f7a38" transform="rotate(-16 5 14)"/>
              <rect x="12" y="9" width="1" height="9" fill="#3f7a38" transform="rotate(14 12 14)"/>
              <rect x="4" y="8" width="4" height="2" fill="#6fa048"/>
              <rect x="10" y="6" width="4" height="2" fill="#6fa048"/>
              <rect x="7" y="4" width="4" height="2" fill="#8ab858"/>
            </svg>`;
            case "woodpile": return `<svg viewBox="0 0 28 14" xmlns="http://www.w3.org/2000/svg">
              <rect x="3" y="8" width="20" height="3" rx="1" fill="#6a3a18"/>
              <rect x="6" y="5" width="19" height="3" rx="1" fill="#8a4a20"/>
              <rect x="1" y="10" width="23" height="3" rx="1" fill="#5a2e14"/>
              <circle cx="23" cy="9.5" r="1.4" fill="#c89858"/>
              <circle cx="25" cy="6.5" r="1.2" fill="#d8a868"/>
            </svg>`;
            case "laundry": return `<svg viewBox="0 0 34 24" xmlns="http://www.w3.org/2000/svg">
              <rect x="2" y="5" width="1" height="18" fill="#5a3818"/>
              <rect x="31" y="5" width="1" height="18" fill="#5a3818"/>
              <path d="M3 8Q17 11 31 8" stroke="#d8c080" stroke-width="1" fill="none"/>
              <rect class="cloth" x="8" y="8" width="7" height="8" fill="#e8d8c8"/>
              <rect class="cloth" x="18" y="9" width="6" height="7" fill="#8aa0c8"/>
            </svg>`;
            case "basket": return `<svg viewBox="0 0 18 16" xmlns="http://www.w3.org/2000/svg">
              <path d="M3 7Q9 1 15 7" stroke="#5a3818" stroke-width="1.5" fill="none"/>
              <rect x="3" y="6" width="12" height="8" fill="#a87838"/>
              <rect x="4" y="7" width="10" height="2" fill="#c89858"/>
              <rect x="5" y="4" width="3" height="3" fill="#c84a35"/>
              <rect x="10" y="4" width="3" height="3" fill="#d4a017"/>
            </svg>`;
            case "bottles": return `<svg viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
              <rect x="4" y="5" width="4" height="10" fill="#3a6a58"/>
              <rect x="5" y="2" width="2" height="3" fill="#2a4a40"/>
              <rect x="10" y="7" width="4" height="8" fill="#6a3a8a"/>
              <rect x="11" y="4" width="2" height="3" fill="#4a2858"/>
              <rect x="4" y="8" width="4" height="2" fill="#80a878"/>
            </svg>`;
            case "coinstand": return `<svg viewBox="0 0 22 18" xmlns="http://www.w3.org/2000/svg">
              <rect x="3" y="9" width="16" height="5" fill="#8a5a2e"/>
              <rect x="4" y="7" width="14" height="2" fill="#c89858"/>
              <rect x="6" y="5" width="3" height="3" fill="#d4a017"/>
              <rect x="11" y="4" width="3" height="3" fill="#f0c440"/>
              <rect x="15" y="6" width="2" height="2" fill="#d4a017"/>
            </svg>`;
            case "sign": return `<svg viewBox="0 0 22 24" xmlns="http://www.w3.org/2000/svg">
              <rect x="10" y="9" width="2" height="14" fill="#5a3818"/>
              <path class="board" d="M2 4H20L18 13H4Z" fill="#8a5a2e"/>
              <rect x="5" y="7" width="10" height="1" fill="#3a2410"/>
              <rect x="5" y="10" width="7" height="1" fill="#3a2410"/>
            </svg>`;
            default: return decorSVG("crate");
          }
        }

        function addDecor(kind, x, bottom, opts = {}) {
          if (!groundDecorLayer) return null;
          const el = document.createElement("div");
          el.className = "amb-decor amb-static amb-" + kind + (opts.classes ? " " + opts.classes : "");
          el.style.setProperty("--x", clamp(x, 8, W() - 8) + "px");
          el.style.setProperty("--b", bottom + "px");
          el.style.setProperty("--w", (opts.w || 20) + "px");
          el.style.setProperty("--h", (opts.h || 18) + "px");
          el.style.setProperty("--s", (opts.scale || 1).toFixed(2));
          el.style.setProperty("--z", opts.z != null ? opts.z : 1);
          if (opts.opacity != null) el.style.setProperty("--o", opts.opacity);
          el.innerHTML = decorSVG(kind);
          groundDecorLayer.appendChild(el);
          return el;
        }

        function scatterDecor(kinds, count, minBottom, maxBottom, opts = {}) {
          const groupSeed = opts.seed || kinds.join("-");
          const kindSeed = opts.kindSeed || groupSeed;
          const margin = opts.margin || 24;
          for (let i = 0; i < count; i++) {
            const rand = seededRand(groupSeed + ":" + i);
            const kind = seededPick(kinds, kindSeed + ":kind:" + i);
            const x = margin + rand() * Math.max(1, W() - margin * 2);
            const bottom = minBottom + rand() * (maxBottom - minBottom);
            addDecor(kind, x, bottom, {
              ...opts,
              scale: stableScale(opts, rand),
            });
          }
        }

        function addHouseDecor(rec) {
          const seed = ensureAmbientSeed(rec);
          const rand = seededRand("house-decor:" + seed + ":" + rec.kind);
          const bounds = structureFootprintBounds(rec.x, rec.kind, rec.palette, rec.upgrade);
          const side = rand() < 0.5 ? -1 : 1;
          const x = side < 0 ? bounds.left - 8 - rand() * 12 : bounds.right + 8 + rand() * 12;
          const b = laneBottom(rec.lane) + (rec.lane === "back" ? 0 : -4) + rand() * 6;
          const props = {
            house: ["broom", "flowerpot", "herbs", "woodpile", "laundry"],
            tavern: ["barrel", "lantern", "basket", "banner", "bottles"],
            guildhall: ["banner", "sign", "lantern", "crate", "rune"],
            mill: ["hay", "crate", "basket", "woodpile"],
            blacksmith: ["woodpile", "barrel", "crate", "lantern"],
            tower: ["banner", "lantern", "milestone", "charm"],
            castle: ["banner", "shrine", "lantern", "rune"],
            marketstall: ["basket", "crate", "bottles", "coinstand"],
            well: ["bucket", "flowers"],
            campfire: ["woodpile", "basket"],
            guardpost: ["banner", "crate", "lantern"],
          };
          const fallback = ["crate", "barrel", "flowers", "milestone"];
          const kind = seededPick(props[rec.kind] || fallback, "house-kind:" + seed + ":" + rec.kind);
          addDecor(kind === "bucket" ? "barrel" : kind, x, b, {
            w: kind === "laundry" ? 34 : kind === "fence" ? 48 : 20,
            h: kind === "laundry" ? 24 : 20,
            classes: rec.lane === "back" ? "back" : "front",
            scale: 0.85 + rand() * 0.35,
          });
          const extraRand = seededRand("house-extra:" + seed + ":" + rec.kind);
          if ((rec.upgrade || 0) >= 2 && extraRand() < 0.45) {
            addDecor(seededPick(["banner", "lantern", "flowerpot", "charm"], "house-extra-kind:" + seed), x + side * (12 + extraRand() * 18), b + 2, {
              w: 18, h: 26, classes: rec.lane === "back" ? "back" : "front", scale: 0.82 + extraRand() * 0.22,
            });
          }
        }

        function refreshAmbientDecor() {
          if (!groundDecorLayer) return;
          const width = W();
          const roadTier = parseInt(world.dataset.road || "0", 10);
          const built = houses.filter((h) => h.stage >= 2 && h.el.isConnected);
          const nextKey = ambientDecorKey(width, roadTier, built);
          if (nextKey === ambientLayoutKey && groundDecorLayer.querySelector(".amb-static")) return;
          ambientLayoutKey = nextKey;
          groundDecorLayer.querySelectorAll(".amb-static").forEach((el) => el.remove());

          const puddleCount = 10;
          for (let i = 0; i < puddleCount; i++) {
            const rand = seededRand("puddle:" + i);
            addDecor("puddle", 24 + rand() * Math.max(1, width - 48), 9 + rand() * 30, {
              w: 26 + rand() * 22, h: 10, classes: "soft front", opacity: 0.85,
            });
          }

          const roadside = roadTier >= 4
            ? ["milestone", "shrine", "lantern", "barrel", "crate", "flowers", "sign"]
            : roadTier >= 2
              ? ["fence", "milestone", "barrel", "crate", "hay", "lantern", "flowers"]
              : ["fence", "barrel", "crate", "hay", "flowers", "sign"];
          scatterDecor(roadside, Math.min(22, Math.floor(width / 120) + 7 + roadTier * 2), 42, 62, {
            seed: "roadside-layout", kindSeed: "roadside-kind:" + roadTier, w: 22, h: 20, classes: "back", scaleRange: [0.75, 0.93],
          });

          const seasonal = {
            spring: ["flowers", "petals", "flowerpot", "herbs"],
            summer: ["flowers", "herbs", "basket", "hay"],
            autumn: ["leafpile", "hay", "woodpile", "barrel"],
            winter: ["snowdrift", "lantern", "woodpile", "milestone"],
          }[currentSeason] || ["flowers"];
          scatterDecor(seasonal, Math.min(28, Math.floor(width / 85) + 8), 48, 76, {
            seed: "seasonal:" + currentSeason, w: 24, h: 16, classes: "soft back", scaleRange: [0.72, 1],
          });

          const mysticCount = Math.min(10, Math.floor(width / 220) + Math.max(0, roadTier - 1));
          scatterDecor(["rune", "glowmushroom", "charm"], mysticCount, 50, 82, {
            seed: "mystic-layout", kindSeed: "mystic-kind:" + roadTier, w: 16, h: 20, classes: "soft back", scaleRange: [0.75, 1.1],
          });

          built
            .slice()
            .sort((a, b) => a.x - b.x)
            .slice(0, 24)
            .forEach(addHouseDecor);

          if (roadTier >= 3) {
            let x = 72 + seededRand("road-lantern-start")() * 90;
            for (let i = 0; x < width; i++) {
              const rand = seededRand("road-lantern:" + i);
              addDecor("lantern", x, 42 + rand() * 8, { w: 14, h: 24, classes: "front", scale: 0.85 });
              x += 160 + rand() * 65;
            }
          }
          if (roadTier >= 4) {
            let x = 110 + seededRand("road-banner-start")() * 120;
            for (let i = 0; x < width; i++) {
              const rand = seededRand("road-banner:" + i);
              addDecor("banner", x, 50 + rand() * 8, { w: 18, h: 30, classes: "back", scale: 0.9 });
              x += 260 + rand() * 80;
            }
          }
          if (roadTier >= 5) {
            scatterDecor(["shrine", "rune", "milestone"], Math.min(8, Math.floor(width / 260) + 2), 43, 58, {
              seed: "road-masterwork", w: 20, h: 28, classes: "front", scaleRange: [0.82, 1],
            });
          }
        }

        function scheduleAmbientRefresh(delay = 120) {
          clearTimeout(ambientRefreshTimer);
          ambientRefreshTimer = setTimeout(refreshAmbientDecor, delay);
        }

        function syncWeatherAftermath(oldWeather, nextWeather) {
          const wet = nextWeather === "rain" || nextWeather === "storm";
          clearTimeout(wetGroundTimer);
          if (wet) {
            world.classList.add("wet-ground");
          } else if (oldWeather === "rain" || oldWeather === "storm") {
            wetGroundTimer = setTimeout(() => world.classList.remove("wet-ground"), 28000);
          } else {
            world.classList.remove("wet-ground");
          }
          if (wet || oldWeather === "rain" || oldWeather === "storm") scheduleAmbientRefresh(80);
        }

        function spawnFirefly() {
          if (reduced || !ambientParticleLayer || document.hidden || currentSeason === "winter") return;
          const phase = world.dataset.time || "day";
          if (phase !== "night" && phase !== "dusk" && phase !== "dawn") return;
          if (weather === "storm") return;
          const el = document.createElement("div");
          el.className = "firefly";
          el.style.left = (24 + Math.random() * Math.max(1, W() - 48)) + "px";
          el.style.bottom = (50 + Math.random() * 90) + "px";
          el.style.setProperty("--vx", ((Math.random() - 0.5) * 70) + "px");
          el.style.setProperty("--vy", (-16 - Math.random() * 44) + "px");
          el.style.setProperty("--dur", (3.8 + Math.random() * 2.8) + "s");
          ambientParticleLayer.appendChild(el);
          setTimeout(() => { if (el.isConnected) el.remove(); }, 7000);
        }

        function spawnSeasonMote() {
          if (reduced || !ambientParticleLayer || document.hidden || weather === "storm") return;
          const cfg = {
            spring: { cls: "leaf", color: "#ffd0dc", w: 5, h: 3, opacity: 0.68 },
            summer: { cls: "round", color: "#f0d890", w: 3, h: 3, opacity: 0.45 },
            autumn: { cls: "leaf", color: pick(["#c87828", "#d4a017", "#9a4a20"]), w: 6, h: 4, opacity: 0.78 },
            winter: { cls: "round", color: "#f8fbff", w: 3, h: 3, opacity: 0.72 },
          }[currentSeason] || { cls: "round", color: "#f0d890", w: 3, h: 3, opacity: 0.5 };
          const el = document.createElement("div");
          el.className = "season-mote " + cfg.cls;
          el.style.left = (Math.random() * W()) + "px";
          el.style.top = (18 + Math.random() * 46) + "%";
          el.style.setProperty("--mw", cfg.w + "px");
          el.style.setProperty("--mh", cfg.h + "px");
          el.style.setProperty("--mc", cfg.color);
          el.style.setProperty("--mo", cfg.opacity);
          el.style.setProperty("--vx", ((Math.random() - 0.5) * 80) + "px");
          el.style.setProperty("--vy", (40 + Math.random() * 120) + "px");
          el.style.setProperty("--rot", ((Math.random() < 0.5 ? -1 : 1) * (120 + Math.random() * 260)) + "deg");
          el.style.setProperty("--dur", (5.5 + Math.random() * 5) + "s");
          ambientParticleLayer.appendChild(el);
          setTimeout(() => { if (el.isConnected) el.remove(); }, 11000);
        }

        function skyCritterSVG(kind) {
          if (kind === "bat") {
            return `<svg viewBox="0 0 32 14" xmlns="http://www.w3.org/2000/svg">
              <path class="wing" d="M15 7L2 2L7 8L2 12Z" fill="#181018"/>
              <path class="wing" d="M17 7L30 2L25 8L30 12Z" fill="#181018"/>
              <rect x="14" y="5" width="4" height="5" fill="#0e0a12"/>
              <rect x="14" y="4" width="1" height="1" fill="#d04050"/>
              <rect x="17" y="4" width="1" height="1" fill="#d04050"/>
            </svg>`;
          }
          return `<svg viewBox="0 0 32 14" xmlns="http://www.w3.org/2000/svg">
            <path class="wing" d="M15 7L2 1L8 8L2 10Z" fill="#201810"/>
            <path class="wing" d="M17 7L30 1L24 8L30 10Z" fill="#201810"/>
            <rect x="14" y="6" width="5" height="3" fill="#2a1e12"/>
            <rect x="19" y="5" width="3" height="2" fill="#2a1e12"/>
          </svg>`;
        }

        function spawnSkyLife() {
          if (reduced || !skyLifeLayer || document.hidden || weather === "storm") return;
          const phase = world.dataset.time || "day";
          const kind = phase === "night" || phase === "dusk" ? "bat" : "bird";
          const dir = Math.random() < 0.5 ? "right" : "left";
          const startX = dir === "right" ? -50 : W() + 50;
          const endX = dir === "right" ? W() + 50 : -50;
          const el = document.createElement("div");
          el.className = "sky-critter";
          el.innerHTML = skyCritterSVG(kind);
          el.style.left = startX + "px";
          el.style.setProperty("--top", (8 + Math.random() * 22) + "%");
          el.style.setProperty("--w", (kind === "bat" ? 24 : 28) + "px");
          el.style.setProperty("--h", (kind === "bat" ? 12 : 14) + "px");
          if (dir === "left") el.style.transform = "scaleX(-1)";
          const dur = 18 + Math.random() * 24;
          el.style.transitionDuration = dur + "s, " + dur + "s";
          skyLifeLayer.appendChild(el);
          requestAnimationFrame(() => {
            el.style.left = endX + "px";
            el.style.setProperty("--top", (7 + Math.random() * 24) + "%");
          });
          setTimeout(() => { if (el.isConnected) el.remove(); }, dur * 1000 + 500);
        }

        function spawnShootingStar() {
          if (reduced || !skyLifeLayer || document.hidden) return;
          const phase = world.dataset.time || "day";
          if (phase !== "night" && phase !== "dusk") return;
          const el = document.createElement("div");
          el.className = "shooting-star";
          el.style.left = (W() * (0.08 + Math.random() * 0.62)) + "px";
          el.style.top = (H() * (0.05 + Math.random() * 0.22)) + "px";
          skyLifeLayer.appendChild(el);
          setTimeout(() => { if (el.isConnected) el.remove(); }, 1400);
        }

        function spawnMicroEvent(kind, x, bottom) {
          if (reduced || !ambientParticleLayer || document.hidden) return;
          const el = document.createElement("div");
          el.className = "micro-event " + kind;
          el.style.left = x + "px";
          el.style.bottom = bottom + "px";
          ambientParticleLayer.appendChild(el);
          setTimeout(() => { if (el.isConnected) el.remove(); }, 1700);
        }

        function microVillageEvent() {
          if (reduced || document.hidden) return;
          const built = houses.filter((h) => h.stage >= 2 && h.el.isConnected);
          if (built.length === 0) return;
          const target = pick(built);
          const bounds = structureFootprintBounds(target.x, target.kind, target.palette, target.upgrade);
          const baseX = clamp((bounds.left + bounds.right) / 2 + (Math.random() - 0.5) * Math.max(12, bounds.right - bounds.left), 8, W() - 8);
          const baseBottom = laneBottom(target.lane) + 14 + Math.random() * 16;
          const kind = target.kind === "blacksmith" ? "ember"
                    : target.kind === "marketstall" || target.kind === "well" ? "bubble"
                    : target.kind === "house" || target.kind === "tavern" ? "door-peek"
                    : "glint";
          const count = target.kind === "blacksmith" ? 3 : target.kind === "marketstall" ? 2 : 1;
          for (let i = 0; i < count; i++) {
            setTimeout(() => spawnMicroEvent(kind, baseX + (Math.random() - 0.5) * 18, baseBottom + Math.random() * 10), i * 180);
          }
        }

        function ambientParticleLoop() {
          if (!document.hidden) {
            const phase = world.dataset.time || "day";
            if (phase === "night" || phase === "dusk" || phase === "dawn") {
              const count = phase === "night" ? 2 : 1;
              for (let i = 0; i < count; i++) spawnFirefly();
            }
            spawnSeasonMote();
            if (currentSeason === "autumn" || currentSeason === "winter") spawnSeasonMote();
          }
          setTimeout(ambientParticleLoop, 700 + Math.random() * 950);
        }

        function skyLifeLoop() {
          if (!document.hidden) {
            const flock = Math.random() < 0.32 ? 2 + Math.floor(Math.random() * 3) : 1;
            for (let i = 0; i < flock; i++) setTimeout(spawnSkyLife, i * (500 + Math.random() * 800));
            if (Math.random() < 0.18) setTimeout(spawnShootingStar, 1200 + Math.random() * 2000);
          }
          setTimeout(skyLifeLoop, 18000 + Math.random() * 34000);
        }

        function microLoop() {
          microVillageEvent();
          setTimeout(microLoop, 4200 + Math.random() * 6200);
        }

        function revealCompletedStructure(el) {
          el.querySelectorAll(".hs-walls, .hs-roof").forEach((part) => {
            part.setAttribute("opacity", 1);
          });
        }
        function setStructureStage(rec, stage) {
          rec.stage = stage;
          rec.el.dataset.stage = String(stage);
        }
        function upgradeScaffoldSVG() {
          return `<svg viewBox="0 0 100 100" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="9" y="12" width="5" height="84" fill="#5a3818"/>
            <rect x="86" y="12" width="5" height="84" fill="#5a3818"/>
            <rect x="6" y="28" width="88" height="4" fill="#8a5a2e"/>
            <rect x="6" y="58" width="88" height="4" fill="#8a5a2e"/>
            <rect x="6" y="88" width="88" height="4" fill="#8a5a2e"/>
            <path d="M14 16L86 88M86 16L14 88" stroke="#6a4828" stroke-width="4"/>
            <path d="M14 16L86 88M86 16L14 88" stroke="#a87848" stroke-width="1.5"/>
            <g class="scaffold-work-lights">
              <rect x="28" y="34" width="9" height="12" fill="#3a2410"/>
              <rect x="30" y="37" width="5" height="7" fill="#f0c440"/>
              <rect x="64" y="34" width="9" height="12" fill="#3a2410"/>
              <rect x="66" y="37" width="5" height="7" fill="#f0c440"/>
            </g>
            <rect x="0" y="74" width="100" height="10" fill="#d8c69a" opacity="0.42"/>
          </svg>`;
        }
        function beginUpgradeConstruction(rec) {
          rec.el.dataset.upgrading = "1";
          rec.el.classList.add("is-upgrading");
          if (!rec.el.querySelector(".upgrade-scaffold")) {
            const scaffold = document.createElement("div");
            scaffold.className = "upgrade-scaffold";
            scaffold.innerHTML = upgradeScaffoldSVG();
            rec.el.appendChild(scaffold);
          }
        }
        function finishUpgradeConstruction(rec) {
          rec.el.classList.remove("is-upgrading");
          delete rec.el.dataset.upgrading;
          const scaffold = rec.el.querySelector(".upgrade-scaffold");
          if (scaffold) scaffold.remove();
        }
        const STRUCTURE_BUILD_LOG = {
          house:    { mid: "Walls rise from the foundation.",    done: "A house stands complete!" },
          tower:    { mid: "The watchtower shaft climbs higher.", done: "A watchtower keeps vigil!" },
          well:     { mid: "Stones are stacked for the well.",   done: "A well brings water to the village." },
          signpost: { mid: null, done: "A signpost is planted at the crossroads." },
          campfire: { mid: "Logs are stacked for the fire.",     done: "A campfire crackles to life." },
          castle:   { mid: "The castle walls rise, stone by stone.", done: "The castle stands — long live the realm!" },
          tavern:   { mid: "Timber framing goes up around the tavern.", done: "The tavern opens its doors — first round on the house!" },
          guildhall:{ mid: "Stone masons set the guildhall walls.",     done: "The guildhall stands proud, banner flying." },
          mill:     { mid: "The mill's stone base is laid.",            done: "The mill's sails begin to turn!" },
          lamppost: { mid: null, done: "A street light is raised — light for the night." },
          garden:   { mid: null, done: "Wildflowers brighten a fresh garden bed." },
          statue:   { mid: "Stone is shaped into a heroic likeness.", done: "A statue commemorates a forgotten hero." },
          marketstall: { mid: "A merchant raises a market stall.", done: "The stall opens for business!" },
          guardpost:   { mid: "A guard post rises beside the road.", done: "Watchmen take their posts." },
          blacksmith:  { mid: "The smithy's chimney climbs skyward.", done: "The forge roars to life — the blacksmith is open!" },
        };

        // Palette variants make each house feel like its own building rather than a copy
        const HOUSE_PALETTES = [
          { wall: "#a87858", wallL: "#c89878", wallD: "#80583a", beam: "#6a4828",
            roof: "#8a3a25", roofL: "#a8442a", roofD: "#6a2818",
            trim: "#d4a017", trimL: "#f0c440", flower: "#e04060", flower2: "#f0c440", accent: "#4080d0", sign: "#8a3a25" }, // classic timber + red tile
          { wall: "#9e9890", wallL: "#c4beb2", wallD: "#706a62", beam: "#5e5850",
            roof: "#38333a", roofL: "#5b5360", roofD: "#18161c", masonry: true,
            trim: "#b8b2aa", trimL: "#e0ded8", flower: "#7bd0f0", flower2: "#c878d8", accent: "#d4a017", sign: "#5e5850" }, // dressed stone walls + slate roof
          { wall: "#e0d8c0", wallL: "#f0e8d4", wallD: "#a8a088", beam: "#7a5028",
            roof: "#7a4828", roofL: "#9a6838", roofD: "#5a3018",
            trim: "#c89044", trimL: "#f0c878", flower: "#e07040", flower2: "#7ac060", accent: "#3a80a0", sign: "#9a6838" }, // whitewash + thatch
          { wall: "#7a5028", wallL: "#9a6838", wallD: "#5a3818", beam: "#3a2410",
            roof: "#3a5a48", roofL: "#5a8060", roofD: "#1a2a28",
            trim: "#92a85f", trimL: "#c0d88a", flower: "#f0c440", flower2: "#d85858", accent: "#70b0a0", sign: "#5a3818" }, // dark wood + forest-green roof
          { wall: "#8a4848", wallL: "#a86060", wallD: "#5a2828", beam: "#3a1818",
            roof: "#4a4060", roofL: "#6a608a", roofD: "#2a2438",
            trim: "#d0b060", trimL: "#f0d890", flower: "#c878d8", flower2: "#f08850", accent: "#71b8d6", sign: "#6a4060" }, // burgundy walls + slate-purple roof
          { wall: "#6f7468", wallL: "#9da58e", wallD: "#4c5148", beam: "#2f302a",
            roof: "#2e5568", roofL: "#4e7890", roofD: "#173342", masonry: true,
            trim: "#d0b768", trimL: "#f0d888", flower: "#d96a55", flower2: "#7ac0d8", accent: "#b86a8a", sign: "#6a4828" }, // mossy riverstone + blue roof
          { wall: "#b88760", wallL: "#e2b37e", wallD: "#805735", beam: "#4a2b18",
            roof: "#b85b2e", roofL: "#de7a45", roofD: "#783018",
            trim: "#e0c878", trimL: "#ffe098", flower: "#6ab86a", flower2: "#c86aa0", accent: "#3a6a8a", sign: "#8a5a30" }, // kiln brick + copper roof
          { wall: "#8f7b62", wallL: "#b9a184", wallD: "#5c4b38", beam: "#2d2318",
            roof: "#6c7b48", roofL: "#91a46a", roofD: "#3b4a2a",
            trim: "#c4a45a", trimL: "#e0c878", flower: "#e09040", flower2: "#d85858", accent: "#7aa090", sign: "#5a3818" }, // moss-roof craftsman
        ];
        const MARKET_PALETTES = [
          { roof: "#c84a35", roofL: "#e06a45", roofD: "#8a2818" },
          { roof: "#2e6f7a", roofL: "#55a0a8", roofD: "#17424a" },
          { roof: "#7a4f9c", roofL: "#a070c8", roofD: "#3f2858" },
          { roof: "#d08a2e", roofL: "#f0b45a", roofD: "#8a4a18" },
        ];
        // House silhouette variants, weighted (cottage is the default)
        const HOUSE_VARIANTS = [
          "cottage", "cottage", "cottage", "cottage", "cottage",
          "two-story", "two-story",
          "a-frame",
          "longhouse",
        ];

        // Markets stay low on the road; only the compact second-counter upgrade is active.
        function marketstallSVG(palette, tier) {
          const awning  = (palette && palette.roof)  || "#c84a35";
          const awningL = (palette && palette.roofL) || "#e06a45";
          const awningD = (palette && palette.roofD) || "#8a2818";
          const t = Math.max(0, Math.min(1, tier || 0));

          if (t === 0) {
            return `<svg viewBox="0 0 32 36" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="0" y="34" width="32" height="2" fill="#3a2818"/>
              <g class="hs-walls" opacity="0">
                <rect x="2" y="14" width="2" height="22" fill="#5a3818"/>
                <rect x="2" y="14" width="2" height="2" fill="#7a4828"/>
                <rect x="28" y="14" width="2" height="22" fill="#5a3818"/>
                <rect x="28" y="14" width="2" height="2" fill="#7a4828"/>
                <rect x="2" y="14" width="28" height="2" fill="#6a4828"/>
                <rect x="2" y="14" width="28" height="0.6" fill="#8a6840"/>
                <rect x="2" y="24" width="28" height="3" fill="#7a5028"/>
                <rect x="2" y="24" width="28" height="0.8" fill="#9a6838"/>
                <rect x="2" y="27" width="28" height="0.8" fill="#5a3818"/>
                <rect x="5" y="27" width="1.5" height="7" fill="#5a3818"/>
                <rect x="14" y="27" width="1.5" height="7" fill="#5a3818"/>
                <rect x="25" y="27" width="1.5" height="7" fill="#5a3818"/>
              </g>
              <g class="hs-roof" opacity="0">
                <polygon points="0,14 32,14 30,8 2,8" fill="${awning}"/>
                <polygon points="2,13 30,13 28,9 4,9" fill="${awningL}"/>
                <rect x="0" y="14" width="32" height="1" fill="${awningD}"/>
                <rect x="6"  y="9"  width="2" height="5" fill="${awningD}" opacity="0.5"/>
                <rect x="13" y="9"  width="2" height="5" fill="${awningD}" opacity="0.5"/>
                <rect x="20" y="9"  width="2" height="5" fill="${awningD}" opacity="0.5"/>
                <rect x="3"  y="14" width="2" height="1.5" fill="${awning}"/>
                <rect x="10" y="14" width="2" height="1.5" fill="${awning}"/>
                <rect x="17" y="14" width="2" height="1.5" fill="${awning}"/>
                <rect x="24" y="14" width="2" height="1.5" fill="${awning}"/>
                <rect x="6" y="20" width="6" height="4" fill="#7a5028"/>
                <rect x="6" y="20" width="6" height="1" fill="#9a6838"/>
                <rect x="6" y="20" width="1" height="4" fill="#5a3818"/>
                <rect x="11" y="20" width="1" height="4" fill="#5a3818"/>
                <rect x="7" y="18" width="1" height="2" fill="#e04060"/>
                <rect x="9" y="17" width="1" height="3" fill="#f0c440"/>
                <rect x="11" y="18" width="1" height="2" fill="#8040b0"/>
                <rect x="16" y="22" width="3" height="2" fill="#d4a017"/>
                <rect x="16" y="22" width="3" height="0.5" fill="#f0c440"/>
                <rect x="20" y="20" width="3" height="4" fill="#a86038"/>
                <rect x="20" y="20" width="3" height="0.5" fill="#c87858"/>
                <rect x="14" y="14" width="0.6" height="3" fill="#3a2410"/>
                <rect x="11" y="17" width="6" height="3" fill="#5a3818"/>
                <rect x="11" y="17" width="6" height="0.6" fill="#7a4828"/>
                <rect x="13" y="18" width="2" height="1" fill="#d4a017"/>
              </g>
              <g class="hs-windows-lit">
                <rect x="25" y="16" width="3" height="3" fill="#f0c440"/>
                <rect x="25" y="15" width="3" height="1" fill="#3a2410"/>
                <rect x="25" y="16" width="3" height="1" fill="#fff4a0"/>
              </g>
            </svg>`;
          }

          if (t === 1) {
            return `<svg viewBox="0 0 52 40" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="0" y="38" width="52" height="2" fill="#3a2818"/>
              <g class="hs-walls" opacity="1">
                <rect x="2" y="14" width="2" height="24" fill="#5a3818"/>
                <rect x="2" y="14" width="2" height="2" fill="#7a4828"/>
                <rect x="25" y="14" width="2" height="24" fill="#5a3818"/>
                <rect x="25" y="14" width="2" height="2" fill="#7a4828"/>
                <rect x="48" y="14" width="2" height="24" fill="#5a3818"/>
                <rect x="48" y="14" width="2" height="2" fill="#7a4828"/>
                <rect x="2" y="14" width="48" height="2" fill="#6a4828"/>
                <rect x="2" y="14" width="48" height="0.6" fill="#8a6840"/>
                <rect x="2" y="26" width="23" height="3" fill="#7a5028"/>
                <rect x="2" y="26" width="23" height="0.8" fill="#9a6838"/>
                <rect x="2" y="29" width="23" height="0.8" fill="#5a3818"/>
                <rect x="27" y="26" width="23" height="3" fill="#7a5028"/>
                <rect x="27" y="26" width="23" height="0.8" fill="#9a6838"/>
                <rect x="27" y="29" width="23" height="0.8" fill="#5a3818"/>
                <rect x="6" y="29" width="1.5" height="9" fill="#5a3818"/>
                <rect x="20" y="29" width="1.5" height="9" fill="#5a3818"/>
                <rect x="32" y="29" width="1.5" height="9" fill="#5a3818"/>
                <rect x="44" y="29" width="1.5" height="9" fill="#5a3818"/>
                <rect x="10" y="34" width="4" height="1.2" fill="#7a4828"/>
                <rect x="11" y="35" width="1" height="3" fill="#5a3818"/>
                <rect x="13" y="35" width="1" height="3" fill="#5a3818"/>
              </g>
              <g class="hs-roof" opacity="1">
                <polygon points="0,14 26,14 24,8 2,8" fill="${awning}"/>
                <polygon points="2,13 24,13 22,9 4,9" fill="${awningL}"/>
                <rect x="0" y="14" width="26" height="1" fill="${awningD}"/>
                <rect x="6"  y="9" width="2" height="5" fill="${awningD}" opacity="0.5"/>
                <rect x="14" y="9" width="2" height="5" fill="${awningD}" opacity="0.5"/>
                <rect x="20" y="9" width="2" height="5" fill="${awningD}" opacity="0.5"/>
                <polygon points="26,14 52,14 50,8 28,8" fill="${awning}"/>
                <polygon points="28,13 50,13 48,9 30,9" fill="${awningL}"/>
                <rect x="26" y="14" width="26" height="1" fill="${awningD}"/>
                <rect x="32" y="9" width="2" height="5" fill="${awningD}" opacity="0.5"/>
                <rect x="40" y="9" width="2" height="5" fill="${awningD}" opacity="0.5"/>
                <rect x="46" y="9" width="2" height="5" fill="${awningD}" opacity="0.5"/>
                <rect x="4"  y="14" width="2" height="1.5" fill="${awning}"/>
                <rect x="11" y="14" width="2" height="1.5" fill="${awning}"/>
                <rect x="18" y="14" width="2" height="1.5" fill="${awning}"/>
                <rect x="30" y="14" width="2" height="1.5" fill="${awning}"/>
                <rect x="37" y="14" width="2" height="1.5" fill="${awning}"/>
                <rect x="44" y="14" width="2" height="1.5" fill="${awning}"/>
                <rect x="5" y="22" width="6" height="4" fill="#7a5028"/>
                <rect x="5" y="22" width="6" height="1" fill="#9a6838"/>
                <rect x="6" y="20" width="1" height="2" fill="#e04060"/>
                <rect x="8" y="19" width="1" height="3" fill="#f0c440"/>
                <rect x="10" y="20" width="1" height="2" fill="#8040b0"/>
                <rect x="13" y="22" width="3" height="4" fill="#a86038"/>
                <rect x="13" y="22" width="3" height="0.5" fill="#c87858"/>
                <rect x="18" y="23" width="4" height="3" fill="#d4a017"/>
                <rect x="18" y="23" width="4" height="0.5" fill="#f0c440"/>
                <rect x="16" y="18" width="0.8" height="4" fill="#5a3818"/>
                <rect x="14" y="18" width="6" height="0.6" fill="#5a3818"/>
                <rect x="14" y="19" width="2" height="0.8" fill="#9a9088"/>
                <rect x="18" y="19" width="2" height="0.8" fill="#9a9088"/>
                <rect x="29" y="22" width="3" height="4" fill="#3a6a8a"/>
                <rect x="29" y="22" width="3" height="0.5" fill="#5a8aaa"/>
                <rect x="33" y="22" width="3" height="4" fill="#8a2818"/>
                <rect x="33" y="22" width="3" height="0.5" fill="#a8483a"/>
                <rect x="37" y="22" width="3" height="4" fill="#6a4828"/>
                <rect x="37" y="22" width="3" height="0.5" fill="#8a6840"/>
                <rect x="41" y="22" width="3" height="4" fill="#5a8a3a"/>
                <rect x="41" y="22" width="3" height="0.5" fill="#7aaa5a"/>
                <rect x="45" y="22" width="3" height="4" fill="#a87838"/>
                <rect x="45" y="22" width="3" height="0.5" fill="#c89858"/>
                <rect x="25.7" y="14" width="0.6" height="4" fill="#3a2410"/>
                <rect x="24" y="17" width="4" height="4" fill="#3a2410"/>
                <rect x="25" y="18" width="2" height="2" fill="#f0c440"/>
                <rect x="12" y="14" width="0.6" height="3" fill="#3a2410"/>
                <rect x="9" y="17" width="6" height="3" fill="#5a3818"/>
                <rect x="9" y="17" width="6" height="0.6" fill="#7a4828"/>
                <rect x="11" y="18" width="2" height="1" fill="#d4a017"/>
                <rect x="38" y="14" width="0.6" height="3" fill="#3a2410"/>
                <rect x="35" y="17" width="6" height="3" fill="#5a3818"/>
                <rect x="35" y="17" width="6" height="0.6" fill="#7a4828"/>
                <rect x="37" y="18" width="2" height="1" fill="#d4a017"/>
              </g>
              <g class="hs-windows-lit">
                <rect x="24" y="17" width="4" height="4" fill="#3a2410"/>
                <rect x="25" y="18" width="2" height="2" fill="#fff4a0"/>
                <rect x="24" y="17" width="4" height="4" fill="#f0c440" opacity="0.4"/>
              </g>
            </svg>`;
          }

          if (t === 2) {
            return `<svg viewBox="0 0 80 54" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="0" y="52" width="80" height="2" fill="#3a2818"/>
              <g class="hs-walls" opacity="1">
                <rect x="0" y="46" width="80" height="6" fill="#a8a098"/>
                <rect x="0" y="46" width="80" height="1" fill="#c8c0b0"/>
                <rect x="0" y="51" width="80" height="1" fill="#80786a"/>
                <rect x="6" y="48" width="4" height="1" fill="#80786a"/>
                <rect x="18" y="48" width="4" height="1" fill="#80786a"/>
                <rect x="30" y="48" width="4" height="1" fill="#80786a"/>
                <rect x="42" y="48" width="4" height="1" fill="#80786a"/>
                <rect x="54" y="48" width="4" height="1" fill="#80786a"/>
                <rect x="66" y="48" width="4" height="1" fill="#80786a"/>
                <rect x="3" y="14" width="2.5" height="32" fill="#5a3818"/>
                <rect x="3" y="14" width="2.5" height="2" fill="#7a4828"/>
                <rect x="27" y="14" width="2.5" height="32" fill="#5a3818"/>
                <rect x="27" y="14" width="2.5" height="2" fill="#7a4828"/>
                <rect x="51" y="14" width="2.5" height="32" fill="#5a3818"/>
                <rect x="51" y="14" width="2.5" height="2" fill="#7a4828"/>
                <rect x="74" y="14" width="2.5" height="32" fill="#5a3818"/>
                <rect x="74" y="14" width="2.5" height="2" fill="#7a4828"/>
                <rect x="3" y="14" width="74" height="2.5" fill="#6a4828"/>
                <rect x="3" y="14" width="74" height="0.8" fill="#8a6840"/>
                <rect x="3" y="32" width="24" height="3.5" fill="#7a5028"/>
                <rect x="3" y="32" width="24" height="0.8" fill="#9a6838"/>
                <rect x="3" y="35" width="24" height="0.8" fill="#5a3818"/>
                <rect x="27" y="32" width="24" height="3.5" fill="#7a5028"/>
                <rect x="27" y="32" width="24" height="0.8" fill="#9a6838"/>
                <rect x="27" y="35" width="24" height="0.8" fill="#5a3818"/>
                <rect x="51" y="32" width="25" height="3.5" fill="#7a5028"/>
                <rect x="51" y="32" width="25" height="0.8" fill="#9a6838"/>
                <rect x="51" y="35" width="25" height="0.8" fill="#5a3818"/>
                <rect x="8" y="36" width="1.5" height="10" fill="#5a3818"/>
                <rect x="20" y="36" width="1.5" height="10" fill="#5a3818"/>
                <rect x="32" y="36" width="1.5" height="10" fill="#5a3818"/>
                <rect x="44" y="36" width="1.5" height="10" fill="#5a3818"/>
                <rect x="56" y="36" width="1.5" height="10" fill="#5a3818"/>
                <rect x="68" y="36" width="1.5" height="10" fill="#5a3818"/>
                <rect x="60" y="40" width="6" height="6" fill="#6a4828"/>
                <rect x="60" y="40" width="6" height="0.8" fill="#8a6840"/>
                <rect x="60" y="42" width="6" height="0.6" fill="#3a2410"/>
                <rect x="60" y="44.5" width="6" height="0.6" fill="#3a2410"/>
                <rect x="68" y="40" width="6" height="6" fill="#6a4828"/>
                <rect x="68" y="40" width="6" height="0.8" fill="#8a6840"/>
                <rect x="68" y="42" width="6" height="0.6" fill="#3a2410"/>
                <rect x="68" y="44.5" width="6" height="0.6" fill="#3a2410"/>
                <rect x="64" y="34" width="6" height="6" fill="#6a4828"/>
                <rect x="64" y="34" width="6" height="0.8" fill="#8a6840"/>
                <rect x="64" y="36" width="6" height="0.6" fill="#3a2410"/>
                <rect x="64" y="38.5" width="6" height="0.6" fill="#3a2410"/>
                <rect x="1" y="40" width="6" height="6" fill="#a87838"/>
                <rect x="1" y="40" width="6" height="0.8" fill="#c89858"/>
                <rect x="1" y="40" width="0.8" height="6" fill="#7a5028"/>
                <rect x="6.2" y="40" width="0.8" height="6" fill="#7a5028"/>
                <rect x="1" y="43" width="6" height="0.6" fill="#7a5028"/>
              </g>
              <g class="hs-roof" opacity="1">
                <polygon points="0,14 80,14 76,4 4,4" fill="${awning}"/>
                <polygon points="3,13 77,13 73,5 7,5" fill="${awningL}"/>
                <rect x="0" y="14" width="80" height="1.2" fill="${awningD}"/>
                <rect x="4" y="3" width="72" height="1.5" fill="${awningD}"/>
                <rect x="10" y="6" width="2.5" height="8" fill="${awningD}" opacity="0.4"/>
                <rect x="22" y="6" width="2.5" height="8" fill="${awningD}" opacity="0.4"/>
                <rect x="34" y="6" width="2.5" height="8" fill="${awningD}" opacity="0.4"/>
                <rect x="46" y="6" width="2.5" height="8" fill="${awningD}" opacity="0.4"/>
                <rect x="58" y="6" width="2.5" height="8" fill="${awningD}" opacity="0.4"/>
                <rect x="68" y="6" width="2.5" height="8" fill="${awningD}" opacity="0.4"/>
                <rect x="6"  y="14" width="3" height="2" fill="${awning}"/>
                <rect x="14" y="14" width="3" height="2" fill="${awning}"/>
                <rect x="22" y="14" width="3" height="2" fill="${awning}"/>
                <rect x="30" y="14" width="3" height="2" fill="${awning}"/>
                <rect x="38" y="14" width="3" height="2" fill="${awning}"/>
                <rect x="46" y="14" width="3" height="2" fill="${awning}"/>
                <rect x="54" y="14" width="3" height="2" fill="${awning}"/>
                <rect x="62" y="14" width="3" height="2" fill="${awning}"/>
                <rect x="70" y="14" width="3" height="2" fill="${awning}"/>
                <rect x="6" y="26" width="6" height="6" fill="#7a5028"/>
                <rect x="6" y="26" width="6" height="1" fill="#9a6838"/>
                <rect x="7" y="23" width="1" height="3" fill="#e04060"/>
                <rect x="9" y="22" width="1" height="4" fill="#f0c440"/>
                <rect x="11" y="23" width="1" height="3" fill="#8040b0"/>
                <rect x="14" y="27" width="5" height="5" fill="#c89858"/>
                <rect x="14" y="27" width="5" height="0.6" fill="#e0b878"/>
                <rect x="20" y="28" width="5" height="4" fill="#a87838"/>
                <rect x="20" y="28" width="5" height="0.6" fill="#c89858"/>
                <rect x="30" y="26" width="3" height="6" fill="#3a6a8a"/>
                <rect x="30" y="26" width="3" height="0.6" fill="#5a8aaa"/>
                <rect x="34" y="26" width="3" height="6" fill="#8a2818"/>
                <rect x="34" y="26" width="3" height="0.6" fill="#a8483a"/>
                <rect x="38" y="26" width="3" height="6" fill="#5a8a3a"/>
                <rect x="38" y="26" width="3" height="0.6" fill="#7aaa5a"/>
                <rect x="42" y="26" width="3" height="6" fill="#6a4828"/>
                <rect x="42" y="26" width="3" height="0.6" fill="#8a6840"/>
                <rect x="46" y="26" width="3" height="6" fill="#a87838"/>
                <rect x="46" y="26" width="3" height="0.6" fill="#c89858"/>
                <rect x="54" y="26" width="0.8" height="6" fill="#5a3818"/>
                <rect x="51.5" y="26" width="6" height="0.6" fill="#5a3818"/>
                <rect x="51.5" y="27" width="2" height="1" fill="#9a9088"/>
                <rect x="55.5" y="27" width="2" height="1" fill="#9a9088"/>
                <rect x="58" y="28" width="2" height="4" fill="#5a8a3a"/>
                <rect x="58" y="28" width="2" height="0.6" fill="#7aaa5a"/>
                <rect x="61" y="29" width="2" height="3" fill="#3a6a8a"/>
                <rect x="61" y="29" width="2" height="0.6" fill="#5a8aaa"/>
                <rect x="38" y="36" width="1.2" height="14" fill="#5a3818"/>
                <rect x="34" y="36" width="9" height="4" fill="#5a3818"/>
                <rect x="34" y="36" width="9" height="0.6" fill="#7a4828"/>
                <rect x="35" y="37" width="3" height="2" fill="#d4a017"/>
                <rect x="39" y="37" width="3" height="2" fill="#d4a017"/>
                <rect x="15" y="14" width="0.6" height="3" fill="#3a2410"/>
                <rect x="13" y="17" width="4" height="4" fill="#3a2410"/>
                <rect x="14" y="18" width="2" height="2" fill="#f0c440"/>
                <rect x="63" y="14" width="0.6" height="3" fill="#3a2410"/>
                <rect x="61" y="17" width="4" height="4" fill="#3a2410"/>
                <rect x="62" y="18" width="2" height="2" fill="#f0c440"/>
              </g>
              <g class="hs-windows-lit">
                <rect x="13" y="17" width="4" height="4" fill="#3a2410"/>
                <rect x="14" y="18" width="2" height="2" fill="#fff4a0"/>
                <rect x="13" y="17" width="4" height="4" fill="#f0c440" opacity="0.4"/>
                <rect x="61" y="17" width="4" height="4" fill="#3a2410"/>
                <rect x="62" y="18" width="2" height="2" fill="#fff4a0"/>
                <rect x="61" y="17" width="4" height="4" fill="#f0c440" opacity="0.4"/>
              </g>
            </svg>`;
          }

          return `<svg viewBox="0 0 120 68" xmlns="http://www.w3.org/2000/svg" overflow="visible">
            <rect x="0" y="66" width="120" height="2" fill="#3a2818"/>
            <g class="hs-walls" opacity="1">
              <rect x="0" y="58" width="120" height="8" fill="#a8a098"/>
              <rect x="0" y="58" width="120" height="1" fill="#c8c0b0"/>
              <rect x="0" y="65" width="120" height="1" fill="#80786a"/>
              <rect x="6" y="61" width="5" height="1.2" fill="#80786a"/>
              <rect x="18" y="61" width="5" height="1.2" fill="#80786a"/>
              <rect x="30" y="61" width="5" height="1.2" fill="#80786a"/>
              <rect x="42" y="61" width="5" height="1.2" fill="#80786a"/>
              <rect x="54" y="61" width="5" height="1.2" fill="#80786a"/>
              <rect x="66" y="61" width="5" height="1.2" fill="#80786a"/>
              <rect x="78" y="61" width="5" height="1.2" fill="#80786a"/>
              <rect x="90" y="61" width="5" height="1.2" fill="#80786a"/>
              <rect x="102" y="61" width="5" height="1.2" fill="#80786a"/>
              <rect x="54" y="62" width="12" height="2" fill="#9a9088"/>
              <rect x="56" y="60" width="8" height="2" fill="#9a9088"/>
              <rect x="58" y="58" width="4" height="2" fill="#9a9088"/>
              <rect x="3" y="22" width="3" height="36" fill="#5a3818"/>
              <rect x="3" y="22" width="3" height="2.5" fill="#7a4828"/>
              <rect x="32" y="22" width="3" height="36" fill="#5a3818"/>
              <rect x="32" y="22" width="3" height="2.5" fill="#7a4828"/>
              <rect x="58.5" y="22" width="3" height="36" fill="#5a3818"/>
              <rect x="58.5" y="22" width="3" height="2.5" fill="#7a4828"/>
              <rect x="85" y="22" width="3" height="36" fill="#5a3818"/>
              <rect x="85" y="22" width="3" height="2.5" fill="#7a4828"/>
              <rect x="114" y="22" width="3" height="36" fill="#5a3818"/>
              <rect x="114" y="22" width="3" height="2.5" fill="#7a4828"/>
              <rect x="3" y="22" width="114" height="3" fill="#6a4828"/>
              <rect x="3" y="22" width="114" height="1" fill="#8a6840"/>
              <rect x="3" y="24.5" width="114" height="0.5" fill="#3a2410"/>
              <rect x="3" y="42" width="29" height="4" fill="#7a5028"/>
              <rect x="3" y="42" width="29" height="1" fill="#9a6838"/>
              <rect x="3" y="45" width="29" height="1" fill="#5a3818"/>
              <rect x="32" y="42" width="26.5" height="4" fill="#7a5028"/>
              <rect x="32" y="42" width="26.5" height="1" fill="#9a6838"/>
              <rect x="32" y="45" width="26.5" height="1" fill="#5a3818"/>
              <rect x="61.5" y="42" width="55.5" height="4" fill="#7a5028"/>
              <rect x="61.5" y="42" width="55.5" height="1" fill="#9a6838"/>
              <rect x="61.5" y="45" width="55.5" height="1" fill="#5a3818"/>
              <rect x="8" y="46" width="1.5" height="12" fill="#5a3818"/>
              <rect x="22" y="46" width="1.5" height="12" fill="#5a3818"/>
              <rect x="38" y="46" width="1.5" height="12" fill="#5a3818"/>
              <rect x="52" y="46" width="1.5" height="12" fill="#5a3818"/>
              <rect x="68" y="46" width="1.5" height="12" fill="#5a3818"/>
              <rect x="80" y="46" width="1.5" height="12" fill="#5a3818"/>
              <rect x="92" y="46" width="1.5" height="12" fill="#5a3818"/>
              <rect x="104" y="46" width="1.5" height="12" fill="#5a3818"/>
              <rect x="1" y="50" width="8" height="8" fill="#a87838"/>
              <rect x="1" y="50" width="8" height="1" fill="#c89858"/>
              <rect x="1" y="50" width="1" height="8" fill="#7a5028"/>
              <rect x="8" y="50" width="1" height="8" fill="#7a5028"/>
              <rect x="1" y="53.5" width="8" height="0.8" fill="#7a5028"/>
              <rect x="3" y="44" width="6" height="6" fill="#a87838"/>
              <rect x="3" y="44" width="6" height="1" fill="#c89858"/>
              <rect x="3" y="44" width="0.8" height="6" fill="#7a5028"/>
              <rect x="8.2" y="44" width="0.8" height="6" fill="#7a5028"/>
            </g>
            <g class="hs-roof" opacity="1">
              <polygon points="0,22 120,22 114,8 6,8" fill="${awning}"/>
              <polygon points="4,21 116,21 110,9 10,9" fill="${awningL}"/>
              <rect x="0" y="22" width="120" height="1.6" fill="${awningD}"/>
              <rect x="6" y="7" width="108" height="2" fill="${awningD}"/>
              <rect x="12" y="10" width="3" height="12" fill="${awningD}" opacity="0.4"/>
              <rect x="26" y="10" width="3" height="12" fill="${awningD}" opacity="0.4"/>
              <rect x="40" y="10" width="3" height="12" fill="${awningD}" opacity="0.4"/>
              <rect x="54" y="10" width="3" height="12" fill="${awningD}" opacity="0.4"/>
              <rect x="68" y="10" width="3" height="12" fill="${awningD}" opacity="0.4"/>
              <rect x="82" y="10" width="3" height="12" fill="${awningD}" opacity="0.4"/>
              <rect x="96" y="10" width="3" height="12" fill="${awningD}" opacity="0.4"/>
              <rect x="108" y="10" width="3" height="12" fill="${awningD}" opacity="0.4"/>
              <rect x="6"  y="22" width="4" height="2.5" fill="${awning}"/>
              <rect x="16" y="22" width="4" height="2.5" fill="${awning}"/>
              <rect x="26" y="22" width="4" height="2.5" fill="${awning}"/>
              <rect x="36" y="22" width="4" height="2.5" fill="${awning}"/>
              <rect x="46" y="22" width="4" height="2.5" fill="${awning}"/>
              <rect x="56" y="22" width="4" height="2.5" fill="${awning}"/>
              <rect x="66" y="22" width="4" height="2.5" fill="${awning}"/>
              <rect x="76" y="22" width="4" height="2.5" fill="${awning}"/>
              <rect x="86" y="22" width="4" height="2.5" fill="${awning}"/>
              <rect x="96" y="22" width="4" height="2.5" fill="${awning}"/>
              <rect x="106" y="22" width="4" height="2.5" fill="${awning}"/>
              <rect x="59.5" y="-6" width="1" height="14" fill="#3a2410"/>
              <polygon points="60.5,-6 70,-3 60.5,0" fill="${awning}"/>
              <polygon points="59.5,1 50,4 59.5,7" fill="${awningD}"/>
              <rect x="7" y="34" width="3" height="8" fill="#5a8a3a"/>
              <rect x="7" y="34" width="3" height="1" fill="#7aaa5a"/>
              <rect x="11" y="36" width="3" height="6" fill="#a87838"/>
              <rect x="11" y="36" width="3" height="0.8" fill="#c89858"/>
              <rect x="15" y="34" width="3" height="8" fill="#8a2818"/>
              <rect x="15" y="34" width="3" height="1" fill="#a8483a"/>
              <rect x="19" y="36" width="3" height="6" fill="#3a6a8a"/>
              <rect x="19" y="36" width="3" height="0.8" fill="#5a8aaa"/>
              <rect x="23" y="34" width="3" height="8" fill="#f0c440"/>
              <rect x="23" y="34" width="3" height="1" fill="#fff4a0"/>
              <rect x="27" y="36" width="3" height="6" fill="#c84a35"/>
              <rect x="27" y="36" width="3" height="0.8" fill="#e06a45"/>
              <rect x="36" y="26" width="2" height="10" fill="#5a3818"/>
              <rect x="35" y="26" width="4" height="1.2" fill="#5a3818"/>
              <rect x="34" y="27" width="6" height="3" fill="#a8483a"/>
              <rect x="35" y="30" width="4" height="3" fill="#c84a35"/>
              <rect x="42" y="27" width="6" height="4" fill="#a8483a"/>
              <rect x="43" y="31" width="4" height="2" fill="#c84a35"/>
              <rect x="50" y="27" width="6" height="3" fill="#a8483a"/>
              <rect x="51" y="30" width="4" height="3" fill="#c84a35"/>
              <rect x="40" y="36" width="8" height="6" fill="#6a4828"/>
              <rect x="40" y="36" width="8" height="1" fill="#8a6840"/>
              <rect x="48" y="37" width="3" height="5" fill="#9a9088"/>
              <rect x="48" y="37" width="3" height="0.6" fill="#c8c0b0"/>
              <rect x="64" y="34" width="4" height="8" fill="#3a6a8a"/>
              <rect x="64" y="34" width="4" height="1" fill="#5a8aaa"/>
              <rect x="70" y="34" width="4" height="8" fill="#8a2818"/>
              <rect x="70" y="34" width="4" height="1" fill="#a8483a"/>
              <rect x="76" y="34" width="4" height="8" fill="#5a8a3a"/>
              <rect x="76" y="34" width="4" height="1" fill="#7aaa5a"/>
              <rect x="82" y="34" width="4" height="8" fill="#6a4828"/>
              <rect x="82" y="34" width="4" height="1" fill="#8a6840"/>
              <rect x="88" y="34" width="4" height="8" fill="#a87838"/>
              <rect x="88" y="34" width="4" height="1" fill="#c89858"/>
              <rect x="97" y="32" width="0.8" height="10" fill="#5a3818"/>
              <rect x="93" y="32" width="9" height="0.8" fill="#5a3818"/>
              <rect x="93" y="33" width="3" height="1" fill="#9a9088"/>
              <rect x="99" y="33" width="3" height="1" fill="#9a9088"/>
              <rect x="105" y="36" width="3" height="6" fill="#3a6a8a"/>
              <rect x="105" y="36" width="3" height="0.8" fill="#5a8aaa"/>
              <rect x="109" y="34" width="3" height="8" fill="#5a8a3a"/>
              <rect x="109" y="34" width="3" height="0.8" fill="#7aaa5a"/>
              <rect x="113" y="36" width="3" height="6" fill="#c84a35"/>
              <rect x="113" y="36" width="3" height="0.8" fill="#e06a45"/>
              <rect x="18" y="22" width="0.6" height="4" fill="#3a2410"/>
              <rect x="15" y="26" width="6" height="5" fill="#3a2410"/>
              <rect x="16.5" y="27" width="3" height="3" fill="#f0c440"/>
              <rect x="58.5" y="22" width="0.6" height="4" fill="#3a2410"/>
              <rect x="56" y="26" width="6" height="5" fill="#3a2410"/>
              <rect x="57.5" y="27" width="3" height="3" fill="#f0c440"/>
              <rect x="98" y="22" width="0.6" height="4" fill="#3a2410"/>
              <rect x="95" y="26" width="6" height="5" fill="#3a2410"/>
              <rect x="96.5" y="27" width="3" height="3" fill="#f0c440"/>
              <rect x="6" y="28" width="0.6" height="6" fill="#3a2410"/>
              <rect x="2" y="30" width="8" height="0.8" fill="#3a2410"/>
              <rect x="2" y="30.8" width="2.5" height="1" fill="#9a9088"/>
              <rect x="7.5" y="30.8" width="2.5" height="1" fill="#9a9088"/>
              <rect x="22" y="22" width="0.6" height="4" fill="#3a2410"/>
              <rect x="18" y="26" width="9" height="4" fill="#5a3818"/>
              <rect x="18" y="26" width="9" height="0.8" fill="#7a4828"/>
              <rect x="20" y="27" width="5" height="2" fill="#d4a017"/>
              <rect x="78" y="22" width="0.6" height="4" fill="#3a2410"/>
              <rect x="74" y="26" width="9" height="4" fill="#5a3818"/>
              <rect x="74" y="26" width="9" height="0.8" fill="#7a4828"/>
              <rect x="76" y="27" width="5" height="2" fill="#d4a017"/>
            </g>
            <g class="hs-windows-lit">
              <rect x="15" y="26" width="6" height="5" fill="#3a2410"/>
              <rect x="16.5" y="27" width="3" height="3" fill="#fff4a0"/>
              <rect x="15" y="26" width="6" height="5" fill="#f0c440" opacity="0.4"/>
              <rect x="56" y="26" width="6" height="5" fill="#3a2410"/>
              <rect x="57.5" y="27" width="3" height="3" fill="#fff4a0"/>
              <rect x="56" y="26" width="6" height="5" fill="#f0c440" opacity="0.4"/>
              <rect x="95" y="26" width="6" height="5" fill="#3a2410"/>
              <rect x="96.5" y="27" width="3" height="3" fill="#fff4a0"/>
              <rect x="95" y="26" width="6" height="5" fill="#f0c440" opacity="0.4"/>
            </g>
          </svg>`;
        }

        // Hand-drawn castle tiers. Early tiers widen the castle; later tiers add
        // a connected rear citadel and foreground wings, without CSS scaling.
        function castleSVG(palette, tier) {
          const t = Math.max(0, Math.min(CASTLE_MAX_UPGRADE, tier || 0));
          const w = CASTLE_UPGRADE_WIDTHS[t];
          const h = CASTLE_UPGRADE_HEIGHTS[t];
          const stone = "#a8a098";
          const stoneL = "#c8c0b0";
          const stoneM = "#9a9088";
          const stoneD = "#80786a";
          const roofD = "#6a2818";
          const roof = "#8a3a25";
          const roofL = "#a8442a";
          const shadow = "#1a1208";
          const gold = "#d4a017";
          const base = "#5a4030";
          const baseL = "#7a5840";
          const baseD = "#3a2818";

          const tier1 = t >= 1 ? `
            <!-- Tier 1: outer drum tower on the right -->
            <g class="castle-ext">
              <rect x="200" y="142" width="40" height="8" fill="#5a4030"/>
              <rect x="200" y="142" width="40" height="2" fill="#7a5840"/>
              <rect x="200" y="148" width="40" height="2" fill="#3a2818"/>
              <rect x="206" y="76" width="28" height="66" fill="#a8a098"/>
              <rect x="206" y="76" width="28" height="3" fill="#c8c0b0"/>
              <rect x="206" y="139" width="28" height="3" fill="#80786a"/>
              <rect x="210" y="84" width="4" height="2" fill="#80786a"/>
              <rect x="224" y="84" width="4" height="2" fill="#80786a"/>
              <rect x="212" y="96" width="4" height="2" fill="#9a9088"/>
              <rect x="222" y="96" width="4" height="2" fill="#80786a"/>
              <rect x="210" y="108" width="4" height="2" fill="#80786a"/>
              <rect x="224" y="108" width="4" height="2" fill="#9a9088"/>
              <rect x="212" y="120" width="4" height="2" fill="#9a9088"/>
              <rect x="222" y="120" width="4" height="2" fill="#80786a"/>
              <rect x="215" y="88" width="2" height="6" fill="#1a1208"/>
              <rect x="221" y="88" width="2" height="6" fill="#1a1208"/>
              <rect x="215" y="106" width="2" height="6" fill="#1a1208"/>
              <rect x="221" y="106" width="2" height="6" fill="#1a1208"/>
              <rect x="202" y="118" width="36" height="2" fill="#6a6258"/>
              <rect x="202" y="118" width="36" height="0.6" fill="#8a8580"/>
              <rect x="204" y="120" width="1" height="3" fill="#6a6258"/>
              <rect x="218" y="120" width="1" height="3" fill="#6a6258"/>
              <rect x="234" y="120" width="1" height="3" fill="#6a6258"/>
              <rect x="216" y="128" width="3" height="9" fill="#1a1208"/>
              <rect x="220" y="128" width="3" height="9" fill="#1a1208"/>
              <rect x="202" y="72" width="36" height="4" fill="#80786a"/>
              <rect x="202" y="68" width="4" height="4" fill="#80786a"/>
              <rect x="210" y="68" width="4" height="4" fill="#80786a"/>
              <rect x="218" y="68" width="4" height="4" fill="#80786a"/>
              <rect x="226" y="68" width="4" height="4" fill="#80786a"/>
              <rect x="234" y="68" width="4" height="4" fill="#80786a"/>
              <polygon points="202,68 238,68 220,44" fill="#6a2818"/>
              <polygon points="205,68 235,68 220,48" fill="#8a3a25"/>
              <polygon points="208,68 232,68 220,52" fill="#a8442a"/>
              <rect x="204" y="64" width="32" height="0.6" fill="#5a1810" opacity="0.6"/>
              <rect x="208" y="58" width="24" height="0.6" fill="#5a1810" opacity="0.6"/>
              <rect x="219.5" y="36" width="1" height="10" fill="#3a2410"/>
              <polygon points="220,40 230,42 220,44" fill="#c84a35"/>
            </g>
            <g class="hs-windows-lit">
              <rect x="215" y="88" width="2" height="6" fill="#d4a017"/>
              <rect x="221" y="88" width="2" height="6" fill="#d4a017"/>
              <rect x="215" y="106" width="2" height="6" fill="#d4a017"/>
              <rect x="221" y="106" width="2" height="6" fill="#d4a017"/>
              <rect x="216" y="128" width="3" height="9" fill="#d4a017"/>
              <rect x="220" y="128" width="3" height="9" fill="#d4a017"/>
            </g>
          ` : "";

          const tier2 = t >= 2 ? `
            <!-- Tier 2: extended outer wall + smaller turret -->
            <g class="castle-ext">
              <rect x="235" y="142" width="55" height="8" fill="#5a4030"/>
              <rect x="235" y="142" width="55" height="2" fill="#7a5840"/>
              <rect x="235" y="148" width="55" height="2" fill="#3a2818"/>
              <rect x="238" y="106" width="42" height="36" fill="#a8a098"/>
              <rect x="238" y="106" width="42" height="2" fill="#c8c0b0"/>
              <rect x="238" y="139" width="42" height="3" fill="#80786a"/>
              <rect x="238" y="102" width="42" height="4" fill="#80786a"/>
              <rect x="240" y="98" width="4" height="4" fill="#80786a"/>
              <rect x="250" y="98" width="4" height="4" fill="#80786a"/>
              <rect x="260" y="98" width="4" height="4" fill="#80786a"/>
              <rect x="270" y="98" width="4" height="4" fill="#80786a"/>
              <rect x="244" y="114" width="4" height="2" fill="#80786a"/>
              <rect x="258" y="114" width="4" height="2" fill="#9a9088"/>
              <rect x="272" y="114" width="4" height="2" fill="#80786a"/>
              <rect x="248" y="126" width="4" height="2" fill="#9a9088"/>
              <rect x="266" y="126" width="4" height="2" fill="#80786a"/>
              <rect x="245" y="120" width="1.5" height="6" fill="#1a1208"/>
              <rect x="260" y="120" width="1.5" height="6" fill="#1a1208"/>
              <rect x="273" y="120" width="1.5" height="6" fill="#1a1208"/>
              <rect x="276" y="86" width="18" height="56" fill="#a8a098"/>
              <rect x="276" y="86" width="18" height="3" fill="#c8c0b0"/>
              <rect x="276" y="139" width="18" height="3" fill="#80786a"/>
              <rect x="280" y="92" width="3" height="2" fill="#80786a"/>
              <rect x="288" y="92" width="3" height="2" fill="#80786a"/>
              <rect x="280" y="106" width="3" height="2" fill="#9a9088"/>
              <rect x="288" y="106" width="3" height="2" fill="#80786a"/>
              <rect x="282" y="98" width="2" height="6" fill="#1a1208"/>
              <rect x="287" y="98" width="2" height="6" fill="#1a1208"/>
              <rect x="282" y="115" width="2" height="6" fill="#1a1208"/>
              <rect x="287" y="115" width="2" height="6" fill="#1a1208"/>
              <rect x="283" y="124" width="4" height="9" fill="#1a1208"/>
              <rect x="274" y="82" width="22" height="4" fill="#80786a"/>
              <rect x="274" y="78" width="4" height="4" fill="#80786a"/>
              <rect x="282" y="78" width="4" height="4" fill="#80786a"/>
              <rect x="290" y="78" width="4" height="4" fill="#80786a"/>
              <polygon points="274,78 296,78 285,60" fill="#6a2818"/>
              <polygon points="276,78 294,78 285,64" fill="#8a3a25"/>
              <rect x="285" y="52" width="0.8" height="8" fill="#3a2410"/>
              <polygon points="286,53 293,55 286,57" fill="#c84a35"/>
            </g>
            <g class="hs-windows-lit">
              <rect x="245" y="120" width="1.5" height="6" fill="#d4a017"/>
              <rect x="260" y="120" width="1.5" height="6" fill="#d4a017"/>
              <rect x="273" y="120" width="1.5" height="6" fill="#d4a017"/>
              <rect x="282" y="98" width="2" height="6" fill="#d4a017"/>
              <rect x="287" y="98" width="2" height="6" fill="#d4a017"/>
              <rect x="282" y="115" width="2" height="6" fill="#d4a017"/>
              <rect x="287" y="115" width="2" height="6" fill="#d4a017"/>
              <rect x="283" y="124" width="4" height="9" fill="#d4a017"/>
            </g>
          ` : "";

          const tier3 = t >= 3 ? `
            <!-- Tier 3: great-hall east bailey -->
            <g class="castle-ext">
              <rect x="294" y="160" width="68" height="8" fill="#5a4030"/>
              <rect x="294" y="160" width="68" height="2" fill="#7a5840"/>
              <rect x="298" y="100" width="58" height="60" fill="#a8a098"/>
              <rect x="298" y="100" width="58" height="3" fill="#c8c0b0"/>
              <rect x="298" y="157" width="58" height="3" fill="#80786a"/>
              <rect x="298" y="100" width="3" height="60" fill="#80786a"/>
              <rect x="353" y="100" width="3" height="60" fill="#80786a"/>
              <rect x="306" y="112" width="4" height="14" fill="#1a1208"/>
              <rect x="318" y="112" width="4" height="14" fill="#1a1208"/>
              <rect x="330" y="112" width="4" height="14" fill="#1a1208"/>
              <rect x="342" y="112" width="4" height="14" fill="#1a1208"/>
              <rect x="320" y="138" width="12" height="22" fill="#3a2410"/>
              <rect x="320" y="138" width="12" height="2" fill="#5a3820"/>
              <rect x="322" y="142" width="8" height="18" fill="#5a3818"/>
              <polygon points="295,100 359,100 327,72" fill="#6a2818"/>
              <polygon points="298,100 356,100 327,76" fill="#8a3a25"/>
              <polygon points="301,100 353,100 327,80" fill="#a8442a"/>
              <rect x="298" y="95" width="58" height="0.8" fill="#5a1810" opacity="0.6"/>
              <rect x="304" y="88" width="46" height="0.8" fill="#5a1810" opacity="0.6"/>
              <rect x="312" y="80" width="30" height="0.8" fill="#5a1810" opacity="0.6"/>
              <rect x="326" y="62" width="1.2" height="14" fill="#3a2410"/>
              <polygon points="327,64 340,66 327,68" fill="#d4a017"/>
            </g>
            <g class="hs-windows-lit">
              <rect x="306" y="112" width="4" height="14" fill="#d4a017"/>
              <rect x="318" y="112" width="4" height="14" fill="#d4a017"/>
              <rect x="330" y="112" width="4" height="14" fill="#d4a017"/>
              <rect x="342" y="112" width="4" height="14" fill="#d4a017"/>
              <rect x="322" y="142" width="8" height="18" fill="#d4a017" opacity="0.5"/>
            </g>
          ` : "";

          const tier4 = t >= 4 ? `
            <!-- Tier 4: grand cathedral palace wing with stained glass + soaring spire -->
            <g class="castle-ext">
              <rect x="360" y="180" width="68" height="8" fill="#5a4030"/>
              <rect x="360" y="180" width="68" height="2" fill="#7a5840"/>
              <rect x="364" y="120" width="58" height="60" fill="#a8a098"/>
              <rect x="364" y="120" width="58" height="3" fill="#c8c0b0"/>
              <rect x="364" y="177" width="58" height="3" fill="#80786a"/>
              <rect x="364" y="120" width="3" height="60" fill="#80786a"/>
              <rect x="380" y="120" width="2" height="60" fill="#80786a"/>
              <rect x="404" y="120" width="2" height="60" fill="#80786a"/>
              <rect x="419" y="120" width="3" height="60" fill="#80786a"/>
              <rect x="369" y="130" width="9" height="18" fill="#1a1208"/>
              <rect x="370" y="131" width="3" height="6" fill="#3a6a8a"/>
              <rect x="374" y="131" width="3" height="6" fill="#c84a35"/>
              <rect x="370" y="138" width="3" height="6" fill="#5a8a3a"/>
              <rect x="374" y="138" width="3" height="6" fill="#d4a017"/>
              <rect x="384" y="130" width="9" height="18" fill="#1a1208"/>
              <rect x="385" y="131" width="3" height="6" fill="#c84a35"/>
              <rect x="389" y="131" width="3" height="6" fill="#3a6a8a"/>
              <rect x="385" y="138" width="3" height="6" fill="#d4a017"/>
              <rect x="389" y="138" width="3" height="6" fill="#5a8a3a"/>
              <rect x="394" y="130" width="9" height="18" fill="#1a1208"/>
              <rect x="395" y="131" width="3" height="6" fill="#5a8a3a"/>
              <rect x="399" y="131" width="3" height="6" fill="#d4a017"/>
              <rect x="395" y="138" width="3" height="6" fill="#3a6a8a"/>
              <rect x="399" y="138" width="3" height="6" fill="#c84a35"/>
              <rect x="408" y="130" width="9" height="18" fill="#1a1208"/>
              <rect x="409" y="131" width="3" height="6" fill="#d4a017"/>
              <rect x="413" y="131" width="3" height="6" fill="#5a8a3a"/>
              <rect x="409" y="138" width="3" height="6" fill="#c84a35"/>
              <rect x="413" y="138" width="3" height="6" fill="#3a6a8a"/>
              <rect x="370" y="160" width="4" height="12" fill="#1a1208"/>
              <rect x="383" y="160" width="4" height="12" fill="#1a1208"/>
              <rect x="395" y="160" width="4" height="12" fill="#1a1208"/>
              <rect x="408" y="160" width="4" height="12" fill="#1a1208"/>
              <polygon points="361,120 425,120 393,90" fill="#6a2818"/>
              <polygon points="364,120 422,120 393,94" fill="#8a3a25"/>
              <polygon points="367,120 419,120 393,98" fill="#a8442a"/>
              <rect x="364" y="115" width="58" height="0.8" fill="#5a1810" opacity="0.6"/>
              <rect x="370" y="108" width="46" height="0.8" fill="#5a1810" opacity="0.6"/>
              <rect x="378" y="100" width="30" height="0.8" fill="#5a1810" opacity="0.6"/>
              <rect x="390" y="50" width="6" height="40" fill="#a8a098"/>
              <rect x="390" y="50" width="6" height="2" fill="#c8c0b0"/>
              <polygon points="388,50 398,50 393,18" fill="#6a2818"/>
              <polygon points="389,50 397,50 393,24" fill="#8a3a25"/>
              <rect x="392.5" y="6" width="1" height="14" fill="#d4a017"/>
              <rect x="391" y="10" width="4" height="1" fill="#d4a017"/>
              <rect x="391" y="14" width="4" height="1" fill="#d4a017"/>
            </g>
            <g class="hs-windows-lit">
              <rect x="370" y="160" width="4" height="12" fill="#d4a017"/>
              <rect x="383" y="160" width="4" height="12" fill="#d4a017"/>
              <rect x="395" y="160" width="4" height="12" fill="#d4a017"/>
              <rect x="408" y="160" width="4" height="12" fill="#d4a017"/>
              <rect x="369" y="130" width="9" height="18" fill="#fff4a0" opacity="0.25"/>
              <rect x="384" y="130" width="9" height="18" fill="#fff4a0" opacity="0.25"/>
              <rect x="394" y="130" width="9" height="18" fill="#fff4a0" opacity="0.25"/>
              <rect x="408" y="130" width="9" height="18" fill="#fff4a0" opacity="0.25"/>
            </g>
          ` : "";

          const tier5 = t >= 5 ? `
            <!-- Tier 5: royal barracks and vaulted loggia -->
            <g class="castle-ext">
              <rect x="428" y="210" width="70" height="8" fill="${base}"/>
              <rect x="428" y="210" width="70" height="2" fill="${baseL}"/>
              <rect x="428" y="216" width="70" height="2" fill="${baseD}"/>
              <rect x="432" y="140" width="60" height="70" fill="${stone}"/>
              <rect x="432" y="140" width="60" height="3" fill="${stoneL}"/>
              <rect x="432" y="207" width="60" height="3" fill="${stoneD}"/>
              ${stoneTexture(432, 140, 60, 70, stoneD, stoneL, stoneM)}
              <rect x="432" y="136" width="60" height="4" fill="${stoneD}"/>
              <rect x="436" y="132" width="5" height="4" fill="${stoneD}"/>
              <rect x="448" y="132" width="5" height="4" fill="${stoneD}"/>
              <rect x="460" y="132" width="5" height="4" fill="${stoneD}"/>
              <rect x="472" y="132" width="5" height="4" fill="${stoneD}"/>
              <rect x="484" y="132" width="5" height="4" fill="${stoneD}"/>
              <polygon points="428,132 496,132 462,104" fill="${roofD}"/>
              <polygon points="432,132 492,132 462,109" fill="${roof}"/>
              <polygon points="436,132 488,132 462,114" fill="${roofL}"/>
              ${roofTileBands(432, 124, [[0, 0, 60], [6, -7, 48], [14, -13, 32]], "#5a1810")}
              <rect x="438" y="154" width="8" height="20" fill="${shadow}"/>
              <rect x="454" y="154" width="8" height="20" fill="${shadow}"/>
              <rect x="470" y="154" width="8" height="20" fill="${shadow}"/>
              <rect x="442" y="188" width="8" height="14" fill="${shadow}"/>
              <rect x="474" y="188" width="8" height="14" fill="${shadow}"/>
              <rect x="456" y="178" width="16" height="32" fill="#3a2410"/>
              <rect x="456" y="178" width="16" height="2" fill="#5a3820"/>
              <rect x="458" y="184" width="12" height="24" fill="#5a3818"/>
              <rect x="462" y="190" width="2" height="2" fill="${gold}"/>
              <rect x="461.5" y="92" width="1" height="14" fill="#3a2410"/>
              <polygon points="462,96 474,98 462,101" fill="#3a6a8a"/>
            </g>
            <g class="hs-windows-lit">
              <rect x="438" y="154" width="8" height="20" fill="${gold}"/>
              <rect x="454" y="154" width="8" height="20" fill="${gold}"/>
              <rect x="470" y="154" width="8" height="20" fill="${gold}"/>
              <rect x="442" y="188" width="8" height="14" fill="${gold}"/>
              <rect x="474" y="188" width="8" height="14" fill="${gold}"/>
              <rect x="458" y="184" width="12" height="24" fill="${gold}" opacity="0.35"/>
            </g>
          ` : "";

          const tier6 = t >= 6 ? `
            <!-- Tier 6: astrologer's observatory tower -->
            <g class="castle-ext">
              <rect x="498" y="224" width="70" height="8" fill="${base}"/>
              <rect x="498" y="224" width="70" height="2" fill="${baseL}"/>
              <rect x="498" y="230" width="70" height="2" fill="${baseD}"/>
              <rect x="500" y="162" width="24" height="12" fill="${stoneD}"/>
              <rect x="500" y="166" width="24" height="4" fill="${stone}"/>
              <rect x="514" y="108" width="40" height="116" fill="${stone}"/>
              <rect x="514" y="108" width="40" height="3" fill="${stoneL}"/>
              <rect x="514" y="221" width="40" height="3" fill="${stoneD}"/>
              ${stoneTexture(514, 108, 40, 116, stoneD, stoneL, stoneM)}
              <rect x="508" y="98" width="52" height="10" fill="${stoneD}"/>
              <rect x="508" y="94" width="6" height="4" fill="${stoneD}"/>
              <rect x="520" y="94" width="6" height="4" fill="${stoneD}"/>
              <rect x="532" y="94" width="6" height="4" fill="${stoneD}"/>
              <rect x="544" y="94" width="6" height="4" fill="${stoneD}"/>
              <rect x="556" y="94" width="4" height="4" fill="${stoneD}"/>
              <polygon points="506,94 562,94 534,68" fill="#2f4f76"/>
              <polygon points="510,94 558,94 534,73" fill="#3a6a8a"/>
              <rect x="520" y="84" width="28" height="8" fill="${shadow}"/>
              <rect x="522" y="85" width="6" height="6" fill="#5a8aa8"/>
              <rect x="531" y="85" width="6" height="6" fill="#c8e0f0"/>
              <rect x="540" y="85" width="6" height="6" fill="#5a8aa8"/>
              <rect x="526" y="124" width="5" height="16" fill="${shadow}"/>
              <rect x="538" y="124" width="5" height="16" fill="${shadow}"/>
              <rect x="526" y="154" width="5" height="16" fill="${shadow}"/>
              <rect x="538" y="154" width="5" height="16" fill="${shadow}"/>
              <rect x="526" y="186" width="5" height="18" fill="${shadow}"/>
              <rect x="538" y="186" width="5" height="18" fill="${shadow}"/>
              <rect x="533.5" y="54" width="1" height="16" fill="${gold}"/>
              <polygon points="534,58 546,60 534,64" fill="${gold}"/>
            </g>
            <g class="hs-windows-lit">
              <rect x="522" y="85" width="6" height="6" fill="#fff4a0" opacity="0.45"/>
              <rect x="531" y="85" width="6" height="6" fill="#fff4a0" opacity="0.6"/>
              <rect x="540" y="85" width="6" height="6" fill="#fff4a0" opacity="0.45"/>
              <rect x="526" y="124" width="5" height="16" fill="${gold}"/>
              <rect x="538" y="124" width="5" height="16" fill="${gold}"/>
              <rect x="526" y="154" width="5" height="16" fill="${gold}"/>
              <rect x="538" y="154" width="5" height="16" fill="${gold}"/>
              <rect x="526" y="186" width="5" height="18" fill="${gold}"/>
              <rect x="538" y="186" width="5" height="18" fill="${gold}"/>
            </g>
          ` : "";

          const tier7 = t >= 7 ? `
            <!-- Tier 7: high keep linked by a guarded skybridge -->
            <g class="castle-ext">
              <rect x="568" y="238" width="70" height="8" fill="${base}"/>
              <rect x="568" y="238" width="70" height="2" fill="${baseL}"/>
              <rect x="568" y="244" width="70" height="2" fill="${baseD}"/>
              <rect x="552" y="154" width="64" height="12" fill="${stoneD}"/>
              <rect x="552" y="154" width="64" height="2" fill="${stoneL}"/>
              <rect x="556" y="166" width="4" height="28" fill="${stoneD}"/>
              <rect x="584" y="166" width="4" height="28" fill="${stoneD}"/>
              <rect x="612" y="166" width="4" height="28" fill="${stoneD}"/>
              <rect x="602" y="142" width="30" height="96" fill="${stone}"/>
              <rect x="602" y="142" width="30" height="3" fill="${stoneL}"/>
              <rect x="602" y="235" width="30" height="3" fill="${stoneD}"/>
              ${stoneTexture(602, 142, 30, 96, stoneD, stoneL, stoneM)}
              <rect x="596" y="134" width="42" height="8" fill="${stoneD}"/>
              <rect x="596" y="130" width="5" height="4" fill="${stoneD}"/>
              <rect x="607" y="130" width="5" height="4" fill="${stoneD}"/>
              <rect x="618" y="130" width="5" height="4" fill="${stoneD}"/>
              <rect x="629" y="130" width="5" height="4" fill="${stoneD}"/>
              <polygon points="596,130 638,130 617,96" fill="${roofD}"/>
              <polygon points="599,130 635,130 617,102" fill="${roof}"/>
              <polygon points="604,130 630,130 617,110" fill="${roofL}"/>
              <rect x="611" y="154" width="4" height="18" fill="${shadow}"/>
              <rect x="620" y="154" width="4" height="18" fill="${shadow}"/>
              <rect x="611" y="184" width="4" height="18" fill="${shadow}"/>
              <rect x="620" y="184" width="4" height="18" fill="${shadow}"/>
              <rect x="610" y="214" width="14" height="24" fill="#3a2410"/>
              <rect x="616.5" y="82" width="1" height="16" fill="#3a2410"/>
              <polygon points="617,86 630,88 617,92" fill="#6a2848"/>
            </g>
            <g class="hs-windows-lit">
              <rect x="560" y="157" width="5" height="6" fill="${gold}"/>
              <rect x="578" y="157" width="5" height="6" fill="${gold}"/>
              <rect x="596" y="157" width="5" height="6" fill="${gold}"/>
              <rect x="611" y="154" width="4" height="18" fill="${gold}"/>
              <rect x="620" y="154" width="4" height="18" fill="${gold}"/>
              <rect x="611" y="184" width="4" height="18" fill="${gold}"/>
              <rect x="620" y="184" width="4" height="18" fill="${gold}"/>
              <rect x="612" y="218" width="10" height="18" fill="${gold}" opacity="0.4"/>
            </g>
          ` : "";

          const tier8 = t >= 8 ? `
            <!-- Tier 8: royal archive with copper lantern stacks -->
            <g class="castle-ext">
              <rect x="638" y="252" width="70" height="8" fill="${base}"/>
              <rect x="638" y="252" width="70" height="2" fill="${baseL}"/>
              <rect x="638" y="258" width="70" height="2" fill="${baseD}"/>
              <rect x="644" y="156" width="56" height="96" fill="${stone}"/>
              <rect x="644" y="156" width="56" height="3" fill="${stoneL}"/>
              <rect x="644" y="249" width="56" height="3" fill="${stoneD}"/>
              ${stoneTexture(644, 156, 56, 96, stoneD, stoneL, stoneM)}
              <polygon points="640,156 704,156 672,118" fill="#5a4820"/>
              <polygon points="644,156 700,156 672,124" fill="#8a6a28"/>
              <polygon points="650,156 694,156 672,132" fill="${gold}"/>
              <rect x="650" y="170" width="8" height="24" fill="${shadow}"/>
              <rect x="666" y="170" width="8" height="24" fill="${shadow}"/>
              <rect x="682" y="170" width="8" height="24" fill="${shadow}"/>
              <rect x="650" y="208" width="8" height="24" fill="${shadow}"/>
              <rect x="666" y="208" width="8" height="24" fill="${shadow}"/>
              <rect x="682" y="208" width="8" height="24" fill="${shadow}"/>
              <rect x="638" y="146" width="68" height="10" fill="${stoneD}"/>
              <rect x="642" y="142" width="5" height="4" fill="${stoneD}"/>
              <rect x="654" y="142" width="5" height="4" fill="${stoneD}"/>
              <rect x="666" y="142" width="5" height="4" fill="${stoneD}"/>
              <rect x="678" y="142" width="5" height="4" fill="${stoneD}"/>
              <rect x="690" y="142" width="5" height="4" fill="${stoneD}"/>
              <rect x="672" y="96" width="10" height="46" fill="${stone}"/>
              <rect x="672" y="96" width="10" height="2" fill="${stoneL}"/>
              <polygon points="668,96 686,96 677,66" fill="#5a4820"/>
              <polygon points="671,96 683,96 677,74" fill="#8a6a28"/>
              <rect x="676.5" y="52" width="1" height="16" fill="${gold}"/>
              <polygon points="677,56 690,58 677,62" fill="${gold}"/>
            </g>
            <g class="hs-windows-lit">
              <rect x="650" y="170" width="8" height="24" fill="${gold}"/>
              <rect x="666" y="170" width="8" height="24" fill="${gold}"/>
              <rect x="682" y="170" width="8" height="24" fill="${gold}"/>
              <rect x="650" y="208" width="8" height="24" fill="${gold}"/>
              <rect x="666" y="208" width="8" height="24" fill="${gold}"/>
              <rect x="682" y="208" width="8" height="24" fill="${gold}"/>
              <rect x="674" y="104" width="6" height="20" fill="#fff4a0" opacity="0.45"/>
            </g>
          ` : "";

          const tier9 = t >= 9 ? `
            <!-- Tier 9: imperial gatehouse and banner court -->
            <g class="castle-ext">
              <rect x="708" y="266" width="70" height="8" fill="${base}"/>
              <rect x="708" y="266" width="70" height="2" fill="${baseL}"/>
              <rect x="708" y="272" width="70" height="2" fill="${baseD}"/>
              <rect x="714" y="170" width="22" height="96" fill="${stone}"/>
              <rect x="750" y="170" width="22" height="96" fill="${stone}"/>
              <rect x="714" y="170" width="22" height="3" fill="${stoneL}"/>
              <rect x="750" y="170" width="22" height="3" fill="${stoneL}"/>
              <rect x="714" y="263" width="22" height="3" fill="${stoneD}"/>
              <rect x="750" y="263" width="22" height="3" fill="${stoneD}"/>
              ${stoneTexture(714, 170, 22, 96, stoneD, stoneL, stoneM)}
              ${stoneTexture(750, 170, 22, 96, stoneD, stoneL, stoneM)}
              <rect x="710" y="160" width="30" height="10" fill="${stoneD}"/>
              <rect x="746" y="160" width="30" height="10" fill="${stoneD}"/>
              <rect x="710" y="156" width="5" height="4" fill="${stoneD}"/>
              <rect x="722" y="156" width="5" height="4" fill="${stoneD}"/>
              <rect x="734" y="156" width="5" height="4" fill="${stoneD}"/>
              <rect x="746" y="156" width="5" height="4" fill="${stoneD}"/>
              <rect x="758" y="156" width="5" height="4" fill="${stoneD}"/>
              <rect x="770" y="156" width="5" height="4" fill="${stoneD}"/>
              <polygon points="710,156 740,156 725,126" fill="${roofD}"/>
              <polygon points="714,156 736,156 725,134" fill="${roof}"/>
              <polygon points="746,156 776,156 761,126" fill="${roofD}"/>
              <polygon points="750,156 772,156 761,134" fill="${roof}"/>
              <rect x="734" y="198" width="20" height="68" fill="${stoneD}"/>
              <rect x="736" y="200" width="16" height="66" fill="#3a2410"/>
              <rect x="738" y="204" width="12" height="60" fill="#5a3818"/>
              <rect x="734" y="192" width="20" height="6" fill="${stoneD}"/>
              <rect x="718" y="188" width="4" height="18" fill="${shadow}"/>
              <rect x="728" y="188" width="4" height="18" fill="${shadow}"/>
              <rect x="754" y="188" width="4" height="18" fill="${shadow}"/>
              <rect x="764" y="188" width="4" height="18" fill="${shadow}"/>
              <rect x="724.5" y="112" width="1" height="16" fill="#3a2410"/>
              <polygon points="725,116 738,118 725,122" fill="#c84a35"/>
              <rect x="760.5" y="112" width="1" height="16" fill="#3a2410"/>
              <polygon points="761,116 748,118 761,122" fill="#3a6a8a"/>
            </g>
            <g class="hs-windows-lit">
              <rect x="718" y="188" width="4" height="18" fill="${gold}"/>
              <rect x="728" y="188" width="4" height="18" fill="${gold}"/>
              <rect x="754" y="188" width="4" height="18" fill="${gold}"/>
              <rect x="764" y="188" width="4" height="18" fill="${gold}"/>
              <rect x="740" y="212" width="8" height="50" fill="${gold}" opacity="0.32"/>
            </g>
          ` : "";

          const tier10 = t >= 10 ? `
            <!-- Tier 10: celestial citadel spire -->
            <g class="castle-ext">
              <rect x="778" y="280" width="70" height="8" fill="${base}"/>
              <rect x="778" y="280" width="70" height="2" fill="${baseL}"/>
              <rect x="778" y="286" width="70" height="2" fill="${baseD}"/>
              <rect x="790" y="172" width="44" height="108" fill="${stone}"/>
              <rect x="790" y="172" width="44" height="3" fill="${stoneL}"/>
              <rect x="790" y="277" width="44" height="3" fill="${stoneD}"/>
              ${stoneTexture(790, 172, 44, 108, stoneD, stoneL, stoneM)}
              <rect x="784" y="162" width="56" height="10" fill="${stoneD}"/>
              <rect x="784" y="158" width="6" height="4" fill="${stoneD}"/>
              <rect x="796" y="158" width="6" height="4" fill="${stoneD}"/>
              <rect x="808" y="158" width="6" height="4" fill="${stoneD}"/>
              <rect x="820" y="158" width="6" height="4" fill="${stoneD}"/>
              <rect x="832" y="158" width="6" height="4" fill="${stoneD}"/>
              <polygon points="782,158 842,158 812,98" fill="#442040"/>
              <polygon points="787,158 837,158 812,108" fill="#6a2848"/>
              <polygon points="794,158 830,158 812,120" fill="#8a3868"/>
              <rect x="808" y="72" width="8" height="28" fill="${stone}"/>
              <rect x="808" y="72" width="8" height="2" fill="${stoneL}"/>
              <polygon points="804,72 820,72 812,34" fill="#442040"/>
              <polygon points="807,72 817,72 812,46" fill="#6a2848"/>
              <rect x="811.5" y="18" width="1" height="18" fill="${gold}"/>
              <rect x="806" y="26" width="12" height="1.5" fill="${gold}"/>
              <rect x="808" y="22" width="8" height="1.5" fill="${gold}"/>
              <rect x="802" y="188" width="5" height="22" fill="${shadow}"/>
              <rect x="817" y="188" width="5" height="22" fill="${shadow}"/>
              <rect x="802" y="226" width="5" height="24" fill="${shadow}"/>
              <rect x="817" y="226" width="5" height="24" fill="${shadow}"/>
              <rect x="808" y="252" width="12" height="28" fill="#3a2410"/>
              <rect x="810" y="258" width="8" height="20" fill="#5a3818"/>
              <rect x="784" y="230" width="10" height="50" fill="${stoneD}"/>
              <rect x="830" y="230" width="10" height="50" fill="${stoneD}"/>
              <polygon points="782,230 796,230 789,208" fill="#442040"/>
              <polygon points="828,230 842,230 835,208" fill="#442040"/>
            </g>
            <g class="hs-windows-lit">
              <rect x="802" y="188" width="5" height="22" fill="${gold}"/>
              <rect x="817" y="188" width="5" height="22" fill="${gold}"/>
              <rect x="802" y="226" width="5" height="24" fill="${gold}"/>
              <rect x="817" y="226" width="5" height="24" fill="${gold}"/>
              <rect x="810" y="258" width="8" height="20" fill="${gold}" opacity="0.36"/>
              <rect x="810" y="80" width="4" height="16" fill="#fff4a0" opacity="0.5"/>
              <rect x="811" y="132" width="4" height="18" fill="#fff4a0" opacity="0.7"/>
            </g>
          ` : "";

          const rearWindows = (x, y, width, height, rows, lit = false) => Array.from({ length: rows }, (_, row) => {
            const yy = y + 18 + row * Math.max(18, Math.floor((height - 38) / Math.max(1, rows - 1)));
            const left = x + Math.floor(width * 0.28);
            const right = x + Math.floor(width * 0.58);
            const fill = lit ? gold : shadow;
            return `<rect x="${left}" y="${yy}" width="3" height="10" fill="${fill}"/>
              <rect x="${right}" y="${yy}" width="3" height="10" fill="${fill}"/>`;
          }).join("");
          const rearTower = ({ x, bottom, width, height, roofHeight, roofFill = roof, flagFill = "#c84a35", opacity = 0.78, rows = 3 }) => {
            const y = bottom - height;
            const capY = y + 4;
            const roofBase = y + 4;
            const roofTip = roofBase - roofHeight;
            const mid = x + width / 2;
            return `<g class="castle-rear-tower" opacity="${opacity}">
              <rect x="${x}" y="${y}" width="${width}" height="${height}" fill="${stoneM}"/>
              <rect x="${x}" y="${y}" width="${width}" height="3" fill="${stoneL}"/>
              <rect x="${x}" y="${bottom - 3}" width="${width}" height="3" fill="${stoneD}"/>
              ${stoneTexture(x, y, width, height, stoneD, stoneL, stoneM)}
              <rect x="${x - 4}" y="${capY}" width="${width + 8}" height="5" fill="${stoneD}"/>
              <rect x="${x - 4}" y="${capY - 4}" width="5" height="4" fill="${stoneD}"/>
              <rect x="${x + width * 0.24}" y="${capY - 4}" width="5" height="4" fill="${stoneD}"/>
              <rect x="${x + width * 0.58}" y="${capY - 4}" width="5" height="4" fill="${stoneD}"/>
              <rect x="${x + width + 1}" y="${capY - 4}" width="5" height="4" fill="${stoneD}"/>
              <polygon points="${x - 6},${roofBase} ${x + width + 6},${roofBase} ${mid},${roofTip}" fill="${roofD}"/>
              <polygon points="${x - 1},${roofBase} ${x + width + 1},${roofBase} ${mid},${roofTip + 7}" fill="${roofFill}"/>
              <rect x="${mid - 0.5}" y="${roofTip - 10}" width="1" height="12" fill="#3a2410"/>
              <polygon points="${mid},${roofTip - 8} ${mid + 10},${roofTip - 6} ${mid},${roofTip - 3}" fill="${flagFill}"/>
              ${rearWindows(x, y, width, height, rows)}
              <g class="hs-windows-lit">
                ${rearWindows(x, y, width, height, rows, true)}
              </g>
            </g>`;
          };
          const crenels = (x, y, width, count, fill = stoneD) => Array.from({ length: count }, (_, i) => {
            const gap = width / count;
            return `<rect x="${(x + i * gap + gap * 0.18).toFixed(1)}" y="${y}" width="${Math.max(4, gap * 0.46).toFixed(1)}" height="5" fill="${fill}"/>`;
          }).join("");
          const rearCurtain = ({ x, bottom, width, height, opacity = 0.64, rows = 1 }) => {
            const y = bottom - height;
            const merlons = Math.max(3, Math.round(width / 16));
            return `<g class="castle-rear-curtain" opacity="${opacity}">
              <rect x="${x}" y="${y}" width="${width}" height="${height}" fill="${stoneM}"/>
              <rect x="${x}" y="${y}" width="${width}" height="3" fill="${stoneL}"/>
              <rect x="${x}" y="${bottom - 3}" width="${width}" height="3" fill="${stoneD}"/>
              ${stoneTexture(x, y, width, height, stoneD, stoneL, stoneM)}
              <rect x="${x - 2}" y="${y - 5}" width="${width + 4}" height="5" fill="${stoneD}"/>
              ${crenels(x - 1, y - 10, width + 2, merlons)}
              ${rearWindows(x, y - 2, width, height + 2, rows)}
              <g class="hs-windows-lit">
                ${rearWindows(x, y - 2, width, height + 2, rows, true)}
              </g>
            </g>`;
          };
          const rearSkybridge = ({ x, y, width, opacity = 0.7 }) => {
            const supports = Array.from({ length: Math.max(2, Math.floor(width / 36)) }, (_, i) => {
              const sx = x + 12 + i * ((width - 24) / Math.max(1, Math.floor(width / 36) - 1));
              return `<rect x="${sx.toFixed(1)}" y="${y + 11}" width="4" height="32" fill="${stoneD}" opacity="0.8"/>`;
            }).join("");
            const lamps = Array.from({ length: Math.max(2, Math.floor(width / 28)) }, (_, i) => {
              const lx = x + 10 + i * ((width - 20) / Math.max(1, Math.floor(width / 28) - 1));
              return `<rect x="${lx.toFixed(1)}" y="${y + 4}" width="3" height="7" fill="${shadow}"/>
                <g class="hs-windows-lit"><rect x="${lx.toFixed(1)}" y="${y + 4}" width="3" height="7" fill="${gold}"/></g>`;
            }).join("");
            return `<g class="castle-rear-bridge" opacity="${opacity}">
              ${supports}
              <rect x="${x}" y="${y}" width="${width}" height="13" fill="${stoneM}"/>
              <rect x="${x}" y="${y}" width="${width}" height="2" fill="${stoneL}"/>
              <rect x="${x}" y="${y + 11}" width="${width}" height="2" fill="${stoneD}"/>
              <rect x="${x - 2}" y="${y - 4}" width="${width + 4}" height="4" fill="${stoneD}"/>
              ${crenels(x, y - 9, width, Math.max(3, Math.round(width / 18)))}
              ${lamps}
            </g>`;
          };
          const rearConnections = [
            t >= 5 ? `<!-- Tier 5: connected rear curtain wall -->
              ${rearCurtain({ x: 78, bottom: h - 48, width: 82, height: 44, opacity: 0.56, rows: 1 })}` : "",
            t >= 6 ? `<!-- Tier 6: observatory wall link -->
              ${rearCurtain({ x: 178, bottom: h - 50, width: 72, height: 52, opacity: 0.58, rows: 2 })}
              ${rearSkybridge({ x: 178, y: h - 130, width: 74, opacity: 0.62 })}` : "",
            t >= 7 ? `<!-- Tier 7: outer keep curtain links -->
              ${rearCurtain({ x: 50, bottom: h - 42, width: 118, height: 58, opacity: 0.5, rows: 2 })}
              ${rearCurtain({ x: 258, bottom: h - 42, width: 72, height: 58, opacity: 0.5, rows: 2 })}
              ${rearSkybridge({ x: 132, y: h - 150, width: 210, opacity: 0.6 })}` : "",
            t >= 8 ? `<!-- Tier 8: archive gallery stitching the skyline -->
              ${rearCurtain({ x: 136, bottom: h - 56, width: 154, height: 66, opacity: 0.58, rows: 2 })}
              ${rearSkybridge({ x: 104, y: h - 176, width: 222, opacity: 0.66 })}` : "",
            t >= 9 ? `<!-- Tier 9: banner court ring wall -->
              ${rearCurtain({ x: 246, bottom: h - 50, width: 126, height: 70, opacity: 0.6, rows: 2 })}
              ${rearSkybridge({ x: 278, y: h - 190, width: 118, opacity: 0.66 })}` : "",
            t >= 10 ? `<!-- Tier 10: celestial inner ring -->
              ${rearCurtain({ x: 170, bottom: h - 44, width: 92, height: 78, opacity: 0.68, rows: 3 })}
              ${rearSkybridge({ x: 154, y: h - 218, width: 126, opacity: 0.72 })}` : "",
          ].join("");
          const rearTiers = [
            t >= 5 ? `<!-- Tier 5: rear curtain towers -->
              ${rearTower({ x: 54, bottom: h - 48, width: 28, height: 124, roofHeight: 22, roofFill: "#8a3a25", flagFill: "#3a6a8a", rows: 3 })}
              ${rearTower({ x: 156, bottom: h - 48, width: 28, height: 120, roofHeight: 20, roofFill: "#8a3a25", flagFill: "#c84a35", rows: 3 })}` : "",
            t >= 6 ? `<!-- Tier 6: rear observatory tower -->
              ${rearTower({ x: 244, bottom: h - 50, width: 34, height: 138, roofHeight: 24, roofFill: "#3a6a8a", flagFill: gold, rows: 4 })}` : "",
            t >= 7 ? `<!-- Tier 7: rear high keeps -->
              ${rearTower({ x: 20, bottom: h - 42, width: 32, height: 142, roofHeight: 26, roofFill: "#6a2848", flagFill: "#c84a35", opacity: 0.72, rows: 4 })}
              ${rearTower({ x: 326, bottom: h - 42, width: 34, height: 146, roofHeight: 28, roofFill: "#6a2848", flagFill: "#3a6a8a", opacity: 0.72, rows: 4 })}` : "",
            t >= 8 ? `<!-- Tier 8: rear archive tower -->
              ${rearTower({ x: 104, bottom: h - 56, width: 38, height: 154, roofHeight: 30, roofFill: "#8a6a28", flagFill: gold, opacity: 0.8, rows: 4 })}` : "",
            t >= 9 ? `<!-- Tier 9: rear banner towers -->
              ${rearTower({ x: 286, bottom: h - 50, width: 30, height: 156, roofHeight: 28, roofFill: "#8a3a25", flagFill: "#c84a35", opacity: 0.76, rows: 4 })}
              ${rearTower({ x: 368, bottom: h - 50, width: 30, height: 152, roofHeight: 28, roofFill: "#8a3a25", flagFill: "#3a6a8a", opacity: 0.76, rows: 4 })}` : "",
            t >= 10 ? `<!-- Tier 10: rear celestial spire -->
              ${rearTower({ x: 196, bottom: h - 44, width: 44, height: 176, roofHeight: 38, roofFill: "#6a2848", flagFill: gold, opacity: 0.84, rows: 5 })}` : "",
          ].join("");

			          // Core castle (200x150) — at upgrade tiers, walls/roof are revealed immediately.
			          const wallOpacity = t === 0 ? 0 : 1;
			          const roofOpacity = t === 0 ? 0 : 1;
			          const coreShift = h - 150;
			          const tier1Shift = h - 150;
			          const tier2Shift = h - 150;
			          const tier3Shift = h - 168;
			          const tier4Shift = h - 188;
			          const shiftedPart = (markup, dy) => markup ? `<g transform="translate(0 ${dy})">${markup}</g>` : "";
			          const lateDy = (level) => h - CASTLE_UPGRADE_HEIGHTS[level] - (level - 3) * 2;
			          const shiftedLatePart = (markup, dx, dy) => markup ? `<g transform="translate(${dx} ${dy})">${markup}</g>` : "";
			          const lateForegroundTiers = [
			            shiftedLatePart(tier5, -72, lateDy(5)),
			            shiftedLatePart(tier6, -212, lateDy(6)),
			            shiftedLatePart(tier7, -312, lateDy(7)),
			            shiftedLatePart(tier8, -528, lateDy(8)),
			            shiftedLatePart(tier9, -682, lateDy(9)),
			            shiftedLatePart(tier10, -596, lateDy(10)),
			          ].join("");

		          return `<svg viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg" overflow="visible">
		            ${rearConnections}
		            ${rearTiers}
		            <g transform="translate(0 ${coreShift})">
	            <!-- foundation plinth + moat -->
	            <rect x="0" y="142" width="200" height="8" fill="#5a4030"/>
            <rect x="0" y="142" width="200" height="2" fill="#7a5840"/>
            <rect x="0" y="148" width="200" height="2" fill="#3a2818"/>
            <rect x="14" y="141" width="3" height="1" fill="#4a6a30"/>
            <rect x="58" y="141" width="2" height="1" fill="#5a7a36"/>
            <rect x="148" y="141" width="3" height="1" fill="#4a6a30"/>
            <rect x="184" y="141" width="2" height="1" fill="#5a7a36"/>
            <rect x="74" y="138" width="52" height="4" fill="#2a4878"/>
            <rect x="74" y="138" width="52" height="1" fill="#4a78a8"/>
            <rect x="80" y="139" width="6" height="1" fill="#4a78a8" opacity="0.5"/>
            <rect x="100" y="139" width="6" height="1" fill="#4a78a8" opacity="0.5"/>
            <rect x="116" y="139" width="6" height="1" fill="#4a78a8" opacity="0.5"/>

            <g class="hs-walls" opacity="${wallOpacity}">
              <rect x="44" y="80" width="112" height="62" fill="#80786a"/>
              <rect x="44" y="80" width="112" height="2" fill="#9a9088"/>
              <rect x="30" y="86" width="140" height="56" fill="#a8a098"/>
              <rect x="30" y="86" width="140" height="3" fill="#c8c0b0"/>
              <rect x="30" y="139" width="140" height="3" fill="#80786a"/>
              <!-- quiet masonry courses and sunlit stone faces -->
              <path d="M32 99h35m52 0h49M32 112h39m58 0h39M32 126h37m62 0h37" fill="none" stroke="#716c68" stroke-width=".8" opacity=".55"/>
              <path d="M38 89v10m23 0v13m-16 0v14m15 0v13m83-50v10m-18 0v13m25 0v14m-18 0v13" fill="none" stroke="#f0e3cd" stroke-width=".8" opacity=".34"/>
              <path d="M30 89h3v50h-3m137-50h3v50h-3" fill="#675f58" opacity=".58"/>
              <path d="M33 90h2v48h-2m131-48h2v48h-2" fill="#dfd0b8" opacity=".5"/>
              <path d="M67 92h3v47h-3m63-47h3v47h-3" fill="#696159" opacity=".48"/>
              <path d="M70 92h2v47h-2m59-47h2v47h-2" fill="#e4d7c2" opacity=".48"/>
              <rect x="36" y="94" width="4" height="2" fill="#80786a"/>
              <rect x="52" y="94" width="4" height="2" fill="#80786a"/>
              <rect x="68" y="94" width="4" height="2" fill="#9a9088"/>
              <rect x="128" y="94" width="4" height="2" fill="#9a9088"/>
              <rect x="144" y="94" width="4" height="2" fill="#80786a"/>
              <rect x="160" y="94" width="4" height="2" fill="#80786a"/>
              <rect x="38" y="106" width="4" height="2" fill="#9a9088"/>
              <rect x="56" y="106" width="4" height="2" fill="#80786a"/>
              <rect x="140" y="106" width="4" height="2" fill="#80786a"/>
              <rect x="158" y="106" width="4" height="2" fill="#9a9088"/>
              <rect x="40" y="120" width="4" height="2" fill="#80786a"/>
              <rect x="62" y="120" width="4" height="2" fill="#9a9088"/>
              <rect x="136" y="120" width="4" height="2" fill="#80786a"/>
              <rect x="156" y="120" width="4" height="2" fill="#9a9088"/>
              <rect x="48" y="100" width="1.5" height="6" fill="#1a1208"/>
              <rect x="64" y="100" width="1.5" height="6" fill="#1a1208"/>
              <rect x="134" y="100" width="1.5" height="6" fill="#1a1208"/>
              <rect x="150" y="100" width="1.5" height="6" fill="#1a1208"/>
              <rect x="42" y="112" width="4" height="10" fill="#1a1208"/>
              <rect x="154" y="112" width="4" height="10" fill="#1a1208"/>
              <rect x="4" y="60" width="28" height="82" fill="#a8a098"/>
              <rect x="4" y="60" width="28" height="3" fill="#c8c0b0"/>
              <rect x="4" y="139" width="28" height="3" fill="#80786a"/>
              <path d="M5 64h3v75H5m24-75h3v75h-3" fill="#6c655e" opacity=".55"/>
              <path d="M8 83h20M8 104h20M8 129h20" fill="none" stroke="#e2d4bd" stroke-width=".8" opacity=".4"/>
              <rect x="8" y="68" width="4" height="2" fill="#80786a"/>
              <rect x="22" y="68" width="4" height="2" fill="#80786a"/>
              <rect x="10" y="78" width="4" height="2" fill="#80786a"/>
              <rect x="20" y="78" width="4" height="2" fill="#80786a"/>
              <rect x="13" y="72" width="2" height="6" fill="#1a1208"/>
              <rect x="20" y="72" width="2" height="6" fill="#1a1208"/>
              <rect x="13" y="92" width="2" height="6" fill="#1a1208"/>
              <rect x="20" y="92" width="2" height="6" fill="#1a1208"/>
              <rect x="0" y="106" width="36" height="2" fill="#6a6258"/>
              <rect x="0" y="106" width="36" height="0.6" fill="#8a8580"/>
              <rect x="2" y="108" width="1" height="3" fill="#6a6258"/>
              <rect x="10" y="108" width="1" height="3" fill="#6a6258"/>
              <rect x="25" y="108" width="1" height="3" fill="#6a6258"/>
              <rect x="33" y="108" width="1" height="3" fill="#6a6258"/>
              <rect x="11" y="118" width="3" height="9" fill="#1a1208"/>
              <rect x="22" y="118" width="3" height="9" fill="#1a1208"/>
              <rect x="168" y="60" width="28" height="82" fill="#a8a098"/>
              <rect x="168" y="60" width="28" height="3" fill="#c8c0b0"/>
              <rect x="168" y="139" width="28" height="3" fill="#80786a"/>
              <path d="M169 64h3v75h-3m24-75h3v75h-3" fill="#6c655e" opacity=".55"/>
              <path d="M172 83h20m-20 21h20m-20 25h20" fill="none" stroke="#e2d4bd" stroke-width=".8" opacity=".4"/>
              <rect x="172" y="68" width="4" height="2" fill="#80786a"/>
              <rect x="186" y="68" width="4" height="2" fill="#80786a"/>
              <rect x="174" y="78" width="4" height="2" fill="#80786a"/>
              <rect x="184" y="78" width="4" height="2" fill="#80786a"/>
              <rect x="177" y="72" width="2" height="6" fill="#1a1208"/>
              <rect x="184" y="72" width="2" height="6" fill="#1a1208"/>
              <rect x="177" y="92" width="2" height="6" fill="#1a1208"/>
              <rect x="184" y="92" width="2" height="6" fill="#1a1208"/>
              <rect x="164" y="106" width="36" height="2" fill="#6a6258"/>
              <rect x="164" y="106" width="36" height="0.6" fill="#8a8580"/>
              <rect x="166" y="108" width="1" height="3" fill="#6a6258"/>
              <rect x="174" y="108" width="1" height="3" fill="#6a6258"/>
              <rect x="189" y="108" width="1" height="3" fill="#6a6258"/>
              <rect x="197" y="108" width="1" height="3" fill="#6a6258"/>
              <rect x="175" y="118" width="3" height="9" fill="#1a1208"/>
              <rect x="186" y="118" width="3" height="9" fill="#1a1208"/>
              <rect x="38" y="64" width="22" height="22" fill="#80786a"/>
              <rect x="38" y="64" width="22" height="2" fill="#9a9088"/>
              <rect x="42" y="70" width="2" height="6" fill="#1a1208"/>
              <rect x="54" y="70" width="2" height="6" fill="#1a1208"/>
              <rect x="140" y="64" width="22" height="22" fill="#80786a"/>
              <rect x="140" y="64" width="22" height="2" fill="#9a9088"/>
              <rect x="144" y="70" width="2" height="6" fill="#1a1208"/>
              <rect x="156" y="70" width="2" height="6" fill="#1a1208"/>
              <rect x="68" y="92" width="14" height="50" fill="#a8a098"/>
              <rect x="68" y="92" width="14" height="3" fill="#c8c0b0"/>
              <rect x="118" y="92" width="14" height="50" fill="#a8a098"/>
              <rect x="118" y="92" width="14" height="3" fill="#c8c0b0"/>
              <rect x="72" y="100" width="2" height="6" fill="#1a1208"/>
              <rect x="76" y="100" width="2" height="6" fill="#1a1208"/>
              <rect x="124" y="100" width="2" height="6" fill="#1a1208"/>
              <rect x="128" y="100" width="2" height="6" fill="#1a1208"/>
              <rect x="82" y="100" width="36" height="42" fill="#3a2410"/>
              <rect x="82" y="100" width="36" height="3" fill="#5a3820"/>
              <path d="M79 141v-37q0-21 21-21t21 21v37" fill="none" stroke="#6b6258" stroke-width="3"/>
              <path d="M81 141v-37q0-19 19-19t19 19v37" fill="none" stroke="#e0d1b9" stroke-width="1.3"/>
              <path d="M98 82h4v5h-4z" fill="#ead8bb"/>
              <rect x="82" y="100" width="3" height="3" fill="#5a4030"/>
              <rect x="115" y="100" width="3" height="3" fill="#5a4030"/>
              <rect x="86" y="104" width="1.5" height="36" fill="#7a5828"/>
              <rect x="92" y="104" width="1.5" height="36" fill="#7a5828"/>
              <rect x="98" y="104" width="1.5" height="36" fill="#7a5828"/>
              <rect x="104" y="104" width="1.5" height="36" fill="#7a5828"/>
              <rect x="110" y="104" width="1.5" height="36" fill="#7a5828"/>
              <rect x="114" y="104" width="1.5" height="36" fill="#7a5828"/>
              <rect x="84" y="110" width="34" height="1.5" fill="#7a5828"/>
              <rect x="84" y="122" width="34" height="1.5" fill="#7a5828"/>
              <rect x="84" y="134" width="34" height="1.5" fill="#7a5828"/>
              <rect x="80" y="142" width="40" height="3" fill="#5a3818"/>
              <rect x="80" y="142" width="40" height="0.8" fill="#7a4828"/>
              <rect x="82" y="142" width="0.8" height="3" fill="#3a2410"/>
              <rect x="88" y="142" width="0.8" height="3" fill="#3a2410"/>
              <rect x="94" y="142" width="0.8" height="3" fill="#3a2410"/>
              <rect x="100" y="142" width="0.8" height="3" fill="#3a2410"/>
              <rect x="106" y="142" width="0.8" height="3" fill="#3a2410"/>
              <rect x="112" y="142" width="0.8" height="3" fill="#3a2410"/>
              <rect x="80" y="98" width="0.6" height="44" fill="#3a3530"/>
              <rect x="119" y="98" width="0.6" height="44" fill="#3a3530"/>
              <rect x="30" y="84" width="140" height="2" fill="#80786a"/>
            </g>

            <g class="hs-roof" opacity="${roofOpacity}">
              <rect x="30" y="82" width="140" height="4" fill="#80786a"/>
              <rect x="30" y="78" width="5" height="4" fill="#80786a"/>
              <rect x="40" y="78" width="5" height="4" fill="#80786a"/>
              <rect x="50" y="78" width="5" height="4" fill="#80786a"/>
              <rect x="60" y="78" width="5" height="4" fill="#80786a"/>
              <rect x="70" y="78" width="5" height="4" fill="#80786a"/>
              <rect x="80" y="78" width="5" height="4" fill="#80786a"/>
              <rect x="90" y="78" width="5" height="4" fill="#80786a"/>
              <rect x="105" y="78" width="5" height="4" fill="#80786a"/>
              <rect x="115" y="78" width="5" height="4" fill="#80786a"/>
              <rect x="125" y="78" width="5" height="4" fill="#80786a"/>
              <rect x="135" y="78" width="5" height="4" fill="#80786a"/>
              <rect x="145" y="78" width="5" height="4" fill="#80786a"/>
              <rect x="155" y="78" width="5" height="4" fill="#80786a"/>
              <rect x="165" y="78" width="5" height="4" fill="#80786a"/>
              <rect x="0" y="56" width="36" height="4" fill="#80786a"/>
              <rect x="0" y="52" width="4" height="4" fill="#80786a"/>
              <rect x="8" y="52" width="4" height="4" fill="#80786a"/>
              <rect x="16" y="52" width="4" height="4" fill="#80786a"/>
              <rect x="24" y="52" width="4" height="4" fill="#80786a"/>
              <rect x="32" y="52" width="4" height="4" fill="#80786a"/>
              <polygon points="0,52 36,52 18,28" fill="#6a2818"/>
              <polygon points="3,52 33,52 18,32" fill="#8a3a25"/>
              <polygon points="6,52 30,52 18,36" fill="#a8442a"/>
              <path d="M5 49h26m-22-5h18m-14-5h10" fill="none" stroke="#d07448" stroke-width=".9" opacity=".55"/>
              <path d="M18 30 4 51h3l11-17z" fill="#f39a68" opacity=".26"/>
              <rect x="2" y="48" width="32" height="0.6" fill="#5a1810" opacity="0.6"/>
              <rect x="5" y="42" width="26" height="0.6" fill="#5a1810" opacity="0.6"/>
              <rect x="17.5" y="20" width="1" height="10" fill="#3a2410"/>
              <rect x="14" y="22" width="1" height="4" fill="#3a2410"/>
              <rect x="21" y="22" width="1" height="4" fill="#3a2410"/>
              <polygon points="14,22 22,22 18,16" fill="#d4a017"/>
              <rect x="164" y="56" width="36" height="4" fill="#80786a"/>
              <rect x="164" y="52" width="4" height="4" fill="#80786a"/>
              <rect x="172" y="52" width="4" height="4" fill="#80786a"/>
              <rect x="180" y="52" width="4" height="4" fill="#80786a"/>
              <rect x="188" y="52" width="4" height="4" fill="#80786a"/>
              <rect x="196" y="52" width="4" height="4" fill="#80786a"/>
              <polygon points="164,52 200,52 182,28" fill="#6a2818"/>
              <polygon points="167,52 197,52 182,32" fill="#8a3a25"/>
              <polygon points="170,52 194,52 182,36" fill="#a8442a"/>
              <path d="M169 49h26m-22-5h18m-14-5h10" fill="none" stroke="#d07448" stroke-width=".9" opacity=".55"/>
              <path d="m182 30-14 21h3l11-17z" fill="#f39a68" opacity=".26"/>
              <rect x="166" y="48" width="32" height="0.6" fill="#5a1810" opacity="0.6"/>
              <rect x="169" y="42" width="26" height="0.6" fill="#5a1810" opacity="0.6"/>
              <rect x="181.5" y="20" width="1" height="10" fill="#3a2410"/>
              <rect x="178" y="22" width="1" height="4" fill="#3a2410"/>
              <rect x="185" y="22" width="1" height="4" fill="#3a2410"/>
              <polygon points="178,22 186,22 182,16" fill="#d4a017"/>
              <rect x="36" y="60" width="26" height="4" fill="#80786a"/>
              <rect x="36" y="56" width="4" height="4" fill="#80786a"/>
              <rect x="44" y="56" width="4" height="4" fill="#80786a"/>
              <rect x="52" y="56" width="4" height="4" fill="#80786a"/>
              <rect x="58" y="56" width="4" height="4" fill="#80786a"/>
              <polygon points="36,56 62,56 49,42" fill="#6a2818"/>
              <polygon points="38,56 60,56 49,46" fill="#8a3a25"/>
              <rect x="138" y="60" width="26" height="4" fill="#80786a"/>
              <rect x="138" y="56" width="4" height="4" fill="#80786a"/>
              <rect x="146" y="56" width="4" height="4" fill="#80786a"/>
              <rect x="154" y="56" width="4" height="4" fill="#80786a"/>
              <rect x="160" y="56" width="4" height="4" fill="#80786a"/>
              <polygon points="138,56 164,56 151,42" fill="#6a2818"/>
              <polygon points="140,56 162,56 151,46" fill="#8a3a25"/>
              <rect x="82" y="42" width="36" height="40" fill="#a8a098"/>
              <rect x="82" y="42" width="36" height="3" fill="#c8c0b0"/>
              <rect x="82" y="42" width="3" height="4" fill="#80786a"/>
              <rect x="82" y="50" width="3" height="4" fill="#80786a"/>
              <rect x="82" y="58" width="3" height="4" fill="#80786a"/>
              <rect x="82" y="66" width="3" height="4" fill="#80786a"/>
              <rect x="82" y="74" width="3" height="4" fill="#80786a"/>
              <rect x="115" y="42" width="3" height="4" fill="#80786a"/>
              <rect x="115" y="50" width="3" height="4" fill="#80786a"/>
              <rect x="115" y="58" width="3" height="4" fill="#80786a"/>
              <rect x="115" y="66" width="3" height="4" fill="#80786a"/>
              <rect x="115" y="74" width="3" height="4" fill="#80786a"/>
              <rect x="89" y="50" width="4" height="8" fill="#1a1208"/>
              <rect x="107" y="50" width="4" height="8" fill="#1a1208"/>
              <rect x="98" y="60" width="4" height="10" fill="#1a1208"/>
              <rect x="80" y="38" width="40" height="4" fill="#80786a"/>
              <rect x="80" y="34" width="4" height="4" fill="#80786a"/>
              <rect x="88" y="34" width="4" height="4" fill="#80786a"/>
              <rect x="96" y="34" width="4" height="4" fill="#80786a"/>
              <rect x="104" y="34" width="4" height="4" fill="#80786a"/>
              <rect x="112" y="34" width="4" height="4" fill="#80786a"/>
              <polygon points="78,34 122,34 100,4" fill="#6a2818"/>
              <polygon points="81,34 119,34 100,9" fill="#8a3a25"/>
              <polygon points="84,34 116,34 100,14" fill="#a8442a"/>
              <path d="M83 31h34m-29-6h24m-20-6h16m-11-6h6" fill="none" stroke="#d07448" stroke-width="1" opacity=".6"/>
              <path d="M100 7 81 34h4l15-22z" fill="#f39a68" opacity=".3"/>
              <rect x="82" y="28" width="36" height="0.6" fill="#5a1810" opacity="0.6"/>
              <rect x="86" y="22" width="28" height="0.6" fill="#5a1810" opacity="0.6"/>
              <rect x="90" y="16" width="20" height="0.6" fill="#5a1810" opacity="0.6"/>
              <rect x="99" y="-12" width="1.5" height="20" fill="#5a3818"/>
              <polygon points="100,-10 116,-10 116,-2 100,-2" fill="#6a2848"/>
              <polygon points="100,-10 116,-10 112,-6 116,-2 100,-2" fill="#6a2848"/>
              <rect x="100" y="-10" width="16" height="1.5" fill="#8a3868"/>
              <rect x="106" y="-6" width="2.5" height="2.5" fill="#d4a017"/>
              <rect x="98" y="-13" width="3" height="1" fill="#d4a017"/>
              <rect x="99" y="-15" width="1.5" height="2" fill="#d4a017"/>
              <rect x="17" y="14" width="1" height="8" fill="#5a3818"/>
              <polygon points="18,15 26,17 18,19" fill="#c84a35"/>
              <rect x="181" y="14" width="1" height="8" fill="#5a3818"/>
              <polygon points="182,15 190,17 182,19" fill="#c84a35"/>
              <rect x="49" y="34" width="1" height="8" fill="#5a3818"/>
              <polygon points="50,35 56,37 50,39" fill="#c84a35"/>
              <rect x="151" y="34" width="1" height="8" fill="#5a3818"/>
              <polygon points="152,35 158,37 152,39" fill="#c84a35"/>
            </g>

            <g class="hs-windows-lit">
              <rect x="13" y="72" width="2" height="6" fill="#d4a017"/>
              <rect x="20" y="72" width="2" height="6" fill="#d4a017"/>
              <rect x="13" y="92" width="2" height="6" fill="#d4a017"/>
              <rect x="20" y="92" width="2" height="6" fill="#d4a017"/>
              <rect x="11" y="118" width="3" height="9" fill="#d4a017"/>
              <rect x="22" y="118" width="3" height="9" fill="#d4a017"/>
              <rect x="177" y="72" width="2" height="6" fill="#d4a017"/>
              <rect x="184" y="72" width="2" height="6" fill="#d4a017"/>
              <rect x="177" y="92" width="2" height="6" fill="#d4a017"/>
              <rect x="184" y="92" width="2" height="6" fill="#d4a017"/>
              <rect x="175" y="118" width="3" height="9" fill="#d4a017"/>
              <rect x="186" y="118" width="3" height="9" fill="#d4a017"/>
              <rect x="42" y="70" width="2" height="6" fill="#d4a017"/>
              <rect x="54" y="70" width="2" height="6" fill="#d4a017"/>
              <rect x="144" y="70" width="2" height="6" fill="#d4a017"/>
              <rect x="156" y="70" width="2" height="6" fill="#d4a017"/>
              <rect x="72" y="100" width="2" height="6" fill="#d4a017"/>
              <rect x="76" y="100" width="2" height="6" fill="#d4a017"/>
              <rect x="124" y="100" width="2" height="6" fill="#d4a017"/>
              <rect x="128" y="100" width="2" height="6" fill="#d4a017"/>
              <rect x="42" y="112" width="4" height="10" fill="#d4a017"/>
              <rect x="154" y="112" width="4" height="10" fill="#d4a017"/>
	              <rect x="89" y="50" width="4" height="8" fill="#d4a017"/>
	              <rect x="107" y="50" width="4" height="8" fill="#d4a017"/>
	              <rect x="98" y="60" width="4" height="10" fill="#d4a017"/>
	              <rect x="84" y="134" width="34" height="6" fill="#d4a017" opacity="0.4"/>
	            </g>
	            </g>
			            ${shiftedPart(tier1, tier1Shift)}
			            ${shiftedPart(tier2, tier2Shift)}
			            ${shiftedPart(tier3, tier3Shift)}
			            ${shiftedPart(tier4, tier4Shift)}
			            ${lateForegroundTiers}
			          </svg>`;
			        }

        function stoneTexture(x, y, w, h, dark = "#80786a", light = "#c8c0b0", mid = "#9a9088") {
          let out = "";
          const course = 7;
          for (let yy = y + course; yy < y + h - 2; yy += course) {
            out += `<rect x="${x}" y="${yy}" width="${w}" height="1" fill="${dark}" opacity="0.42"/>`;
            for (let xx = x + ((Math.floor((yy - y) / course) % 2) ? 4 : 8); xx < x + w - 2; xx += 10) {
              out += `<rect x="${xx}" y="${yy - 4}" width="1" height="4" fill="${dark}" opacity="0.32"/>`;
            }
          }
          out += `<rect x="${x + 2}" y="${y + 2}" width="${Math.max(3, Math.floor(w * 0.26))}" height="1" fill="${light}" opacity="0.42"/>`;
          out += `<rect x="${x + Math.max(4, Math.floor(w * 0.58))}" y="${y + Math.max(5, Math.floor(h * 0.34))}" width="${Math.max(3, Math.floor(w * 0.22))}" height="1" fill="${mid}" opacity="0.38"/>`;
          out += `<rect x="${x + Math.max(5, Math.floor(w * 0.36))}" y="${y + Math.max(8, Math.floor(h * 0.68))}" width="${Math.max(3, Math.floor(w * 0.2))}" height="1" fill="${dark}" opacity="0.34"/>`;
          return out;
        }

        function roofTileBands(x, y, widths, color, opacity = 0.42) {
          return widths.map(([dx, dy, w]) =>
            `<rect x="${x + dx}" y="${y + dy}" width="${w}" height="1" fill="${color}" opacity="${opacity}"/>`
          ).join("");
        }

        function upgradeWindows(windows, lit = false) {
          return windows.map(([x, y, w, h]) => {
            if (lit) {
              return `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#f0c440"/>
                <rect x="${x}" y="${y}" width="${w}" height="1" fill="#ffe080" opacity="0.9"/>`;
            }
            return `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#2a211b"/>
              <rect x="${x + 1}" y="${y + 1}" width="${Math.max(1, w - 2)}" height="${Math.max(1, h - 2)}" fill="#5a4830"/>
              <rect x="${x + Math.floor(w / 2)}" y="${y + 1}" width="1" height="${Math.max(1, h - 2)}" fill="#2a211b" opacity="0.85"/>
              <rect x="${x + 1}" y="${y + Math.floor(h / 2)}" width="${Math.max(1, w - 2)}" height="1" fill="#2a211b" opacity="0.85"/>`;
          }).join("");
        }

        function upgradedTowerSVG(palette, tier) {
          const t = Math.max(1, Math.min(4, tier|0));
          const sizes = [[32, 64], [38, 70], [42, 76], [46, 82], [50, 88]];
          const [w, h] = sizes[t];
          const baseY = h - 6;
          const shaftW = [20, 24, 28, 32, 36][t];
          const shaftH = [42, 48, 54, 60, 66][t];
          const shaftX = Math.round((w - shaftW) / 2);
          const shaftY = baseY - shaftH;
          const capY = shaftY - 6;
          const windows = [
            [shaftX + Math.round(shaftW * 0.22), shaftY + Math.round(shaftH * 0.32), 3, 8],
            [shaftX + Math.round(shaftW * 0.63), shaftY + Math.round(shaftH * 0.32), 3, 8],
            [shaftX + Math.round(shaftW * 0.45), shaftY + Math.round(shaftH * 0.58), 3, 9],
          ];
          const sideTowers = t >= 2 ? `
            <g class="hs-walls" opacity="1">
              <rect x="${shaftX - 7}" y="${shaftY + 16}" width="7" height="${shaftH - 18}" fill="#a8a098"/>
              <rect x="${shaftX + shaftW}" y="${shaftY + 16}" width="7" height="${shaftH - 18}" fill="#a8a098"/>
              <rect x="${shaftX - 7}" y="${shaftY + 16}" width="7" height="2" fill="#c8c0b0"/>
              <rect x="${shaftX + shaftW}" y="${shaftY + 16}" width="7" height="2" fill="#c8c0b0"/>
              <rect x="${shaftX - 5}" y="${shaftY + 28}" width="2" height="5" fill="#1a1208"/>
              <rect x="${shaftX + shaftW + 3}" y="${shaftY + 28}" width="2" height="5" fill="#1a1208"/>
            </g>
            <g class="hs-roof" opacity="1">
              <polygon points="${shaftX - 9},${shaftY + 16} ${shaftX - 3.5},${shaftY + 5} ${shaftX + 2},${shaftY + 16}" fill="#8a3a25"/>
              <polygon points="${shaftX + shaftW - 2},${shaftY + 16} ${shaftX + shaftW + 3.5},${shaftY + 5} ${shaftX + shaftW + 9},${shaftY + 16}" fill="#8a3a25"/>
            </g>` : "";
          const spire = t >= 3 ? `
            <g class="hs-roof" opacity="1">
              <polygon points="${shaftX + 2},${capY} ${shaftX + shaftW - 2},${capY} ${w / 2},${Math.max(0, capY - 18 - t * 2)}" fill="#8a3a25"/>
              <polygon points="${shaftX + 5},${capY} ${shaftX + shaftW - 5},${capY} ${w / 2},${Math.max(3, capY - 13 - t)}" fill="#a8442a"/>
              ${t >= 4 ? `<rect x="${w / 2 - 0.5}" y="${Math.max(0, capY - 34)}" width="1" height="18" fill="#3a2410"/>
                <rect x="${w / 2 + 0.5}" y="${Math.max(0, capY - 32)}" width="11" height="5" fill="#c84a35"/>
                <polygon points="${w / 2 + 11.5},${Math.max(0, capY - 32)} ${w / 2 + 17},${Math.max(0, capY - 29.5)} ${w / 2 + 11.5},${Math.max(0, capY - 27)}" fill="#c84a35"/>` : ""}
            </g>` : "";

          return `<svg viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg" overflow="visible">
            <rect x="1" y="${baseY}" width="${w - 2}" height="6" fill="#5a4030"/>
            <rect x="1" y="${baseY}" width="${w - 2}" height="2" fill="#7a5840"/>
            <g class="hs-walls" opacity="1">
              <rect x="${shaftX}" y="${shaftY}" width="${shaftW}" height="${shaftH}" fill="#a8a098"/>
              <rect x="${shaftX}" y="${shaftY}" width="${shaftW}" height="2" fill="#c8c0b0"/>
              <rect x="${shaftX}" y="${baseY - 2}" width="${shaftW}" height="2" fill="#80786a"/>
              ${stoneTexture(shaftX, shaftY + 3, shaftW, shaftH - 5, "#5a544e", "#c8c0b0", "#80786a")}
              <rect x="${shaftX - 2}" y="${capY}" width="${shaftW + 4}" height="6" fill="#80786a"/>
              ${Array.from({ length: t + 4 }, (_, i) => `<rect x="${Math.round(shaftX - 2 + i * ((shaftW + 1) / (t + 3)))}" y="${capY - 4}" width="3" height="4" fill="#80786a"/>`).join("")}
              ${upgradeWindows(windows)}
              <rect x="${Math.round(w / 2 - 3)}" y="${baseY - 12}" width="6" height="12" fill="#3a2410"/>
              <rect x="${Math.round(w / 2 - 3)}" y="${baseY - 12}" width="6" height="2" fill="#5a4030"/>
              ${t >= 4 ? `<rect x="${shaftX + 3}" y="${shaftY + shaftH - 17}" width="${shaftW - 6}" height="2" fill="#d4a017"/>` : ""}
            </g>
            ${sideTowers}
            ${spire}
            <g class="hs-windows-lit">
              ${upgradeWindows(windows, true)}
              ${t >= 2 ? `<rect x="${shaftX - 5}" y="${shaftY + 28}" width="2" height="5" fill="#d4a017"/><rect x="${shaftX + shaftW + 3}" y="${shaftY + 28}" width="2" height="5" fill="#d4a017"/>` : ""}
            </g>
          </svg>`;
        }

        function houseUpgradeSVG(palette, tier) {
          const p = palette || HOUSE_PALETTES[0];
          const t = Math.max(1, Math.min(4, tier|0));
          const variant = p.variant || "cottage";
          const sizeMap = {
            cottage: [[36, 32], [56, 40], [80, 48], [104, 56], [128, 64]],
            "two-story": [[32, 44], [60, 64], [78, 72], [100, 82], [122, 94]],
            "a-frame": [[36, 40], [64, 58], [82, 66], [104, 76], [126, 86]],
            longhouse: [[56, 32], [84, 44], [104, 52], [124, 62], [144, 72]],
          };
          const [w, h] = (sizeMap[variant] || sizeMap.cottage)[t];
          const baseY = h - 6;
          const wallW = variant === "longhouse" ? w - 14 : Math.round(w * (variant === "two-story" ? 0.58 : 0.62));
          const wallH = variant === "two-story" ? Math.round(h * 0.58) : variant === "a-frame" ? Math.round(h * 0.28) : Math.round(h * 0.42);
          const wallX = Math.round((w - wallW) / 2);
          const wallY = baseY - wallH;
          const roofPeakY = variant === "a-frame" ? Math.max(0, wallY - Math.round(h * 0.62)) : Math.max(0, wallY - 12 - t * 3);
          const winCount = variant === "longhouse" ? Math.min(6, 3 + t) : Math.min(4, 1 + t);
          const winW = Math.max(4, Math.floor(wallW / (variant === "longhouse" ? 12 : 9)));
          const winH = Math.max(5, Math.floor(wallH / 5));
          const windows = Array.from({ length: winCount }, (_, i) => {
            const gap = wallW / (winCount + 1);
            const y = Math.round(wallY + wallH * (variant === "two-story" && i % 2 ? 0.55 : 0.28));
            return [Math.round(wallX + gap * (i + 1) - winW / 2), y, winW, winH];
          });
          const doorW = Math.max(6, Math.floor(wallW * 0.14));
          const doorH = Math.max(10, Math.floor(wallH * 0.38));
          const doorX = Math.round(w / 2 - doorW / 2);
          const doorY = baseY - doorH;
          const sideWing = t >= 2 && variant !== "a-frame" ? `
            <g class="hs-walls" opacity="1">
              <rect x="${Math.max(1, wallX - 18 - t * 2)}" y="${baseY - Math.round(wallH * 0.58)}" width="${18 + t * 2}" height="${Math.round(wallH * 0.58)}" fill="${p.wall}"/>
              <rect x="${Math.max(1, wallX - 18 - t * 2)}" y="${baseY - Math.round(wallH * 0.58)}" width="${18 + t * 2}" height="2" fill="${p.wallL}"/>
              <rect x="${Math.max(2, wallX - 12 - t)}" y="${baseY - Math.round(wallH * 0.38)}" width="${winW}" height="${winH}" fill="#2a211b"/>
            </g>
            <g class="hs-roof" opacity="1">
              <polygon points="${Math.max(0, wallX - 22 - t * 2)},${baseY - Math.round(wallH * 0.58)} ${Math.max(2, wallX - 7 - t)},${baseY - Math.round(wallH * 0.82)} ${wallX + 6},${baseY - Math.round(wallH * 0.58)}" fill="${p.roof}"/>
            </g>` : "";
          const dormer = t >= 3 ? `
            <g class="hs-roof" opacity="1">
              <rect x="${Math.round(w / 2 - 9)}" y="${Math.max(1, wallY - 8)}" width="18" height="10" fill="${p.wall}"/>
              <polygon points="${Math.round(w / 2 - 12)},${Math.max(1, wallY - 8)} ${Math.round(w / 2)},${Math.max(0, wallY - 18)} ${Math.round(w / 2 + 12)},${Math.max(1, wallY - 8)}" fill="${p.roof}"/>
              <rect x="${Math.round(w / 2 - 4)}" y="${Math.max(2, wallY - 5)}" width="8" height="5" fill="#2a211b"/>
            </g>` : "";
          const turret = t >= 4 ? `
            <g class="hs-walls" opacity="1">
              <rect x="${wallX + wallW - 4}" y="${wallY - 6}" width="${Math.max(13, Math.floor(w * 0.12))}" height="${baseY - wallY + 6}" fill="${p.wallD || p.wall}"/>
              <rect x="${wallX + wallW}" y="${wallY + 8}" width="5" height="9" fill="#2a211b"/>
              <rect x="${wallX + wallW + 1}" y="${wallY + 9}" width="3" height="7" fill="#f0c440"/>
            </g>
            <g class="hs-roof" opacity="1">
              <polygon points="${wallX + wallW - 7},${wallY - 6} ${wallX + wallW + 4},${Math.max(0, wallY - 20)} ${wallX + wallW + 15},${wallY - 6}" fill="${p.roof}"/>
            </g>` : "";
          const roofMarkup = variant === "a-frame"
            ? `<polygon points="0,${baseY} ${w / 2},${roofPeakY} ${w},${baseY}" fill="${p.roof}"/>
               <polygon points="4,${baseY} ${w / 2},${roofPeakY + 5} ${w - 4},${baseY}" fill="${p.roofL}"/>`
            : `<polygon points="${Math.max(0, wallX - 8 - t)},${wallY} ${w / 2},${roofPeakY} ${Math.min(w, wallX + wallW + 8 + t)},${wallY}" fill="${p.roof}"/>
               <polygon points="${wallX - 3},${wallY - 1} ${w / 2},${roofPeakY + 5} ${wallX + wallW + 3},${wallY - 1}" fill="${p.roofL}"/>
               <rect x="${Math.max(0, wallX - 8 - t)}" y="${wallY - 1}" width="${Math.min(w, wallX + wallW + 8 + t) - Math.max(0, wallX - 8 - t)}" height="3" fill="${p.roofD || "#4a1c12"}"/>`;

          return `<svg viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg" overflow="visible">
            <rect x="0" y="${baseY}" width="${w}" height="6" fill="#5a4030"/>
            <rect x="0" y="${baseY}" width="${w}" height="2" fill="#7a5840"/>
            ${sideWing}
            <g class="hs-walls" opacity="1">
              <rect x="${wallX}" y="${wallY}" width="${wallW}" height="${wallH}" fill="${p.wall}"/>
              <rect x="${wallX}" y="${wallY}" width="${wallW}" height="2" fill="${p.wallL}"/>
              <rect x="${wallX}" y="${baseY - 2}" width="${wallW}" height="2" fill="${p.wallD}"/>
              ${stoneTexture(wallX, wallY + 2, wallW, wallH - 4, p.wallD || "#6f482d", p.wallL || "#d0a06a", p.beam || "#5a351f")}
              ${upgradeWindows(windows)}
              <rect x="${doorX}" y="${doorY}" width="${doorW}" height="${doorH}" fill="#3a2410"/>
              <rect x="${doorX + doorW - 3}" y="${doorY + Math.floor(doorH / 2)}" width="1" height="1" fill="${p.trim || "#d4a017"}"/>
              <rect x="${wallX + 2}" y="${baseY - 5}" width="${wallW - 4}" height="1" fill="${p.trim || "#d4a017"}" opacity="${t >= 4 ? 1 : 0.45}"/>
              <rect x="${wallX - 5}" y="${baseY - 3}" width="10" height="3" fill="#4a3018"/>
              <rect x="${wallX - 3}" y="${baseY - 7}" width="1" height="1" fill="${p.flower || "#e04060"}"/>
            </g>
            ${turret}
            <g class="hs-roof" opacity="1">
              ${roofMarkup}
              <rect x="${Math.round(w * 0.68)}" y="${Math.max(0, roofPeakY + 2)}" width="${3 + t}" height="${Math.max(7, wallY - roofPeakY - 2)}" fill="#3a2410"/>
              ${t >= 4 ? `<rect x="${Math.round(w / 2 - 9)}" y="${Math.max(0, roofPeakY - 4)}" width="18" height="1" fill="${p.trimL || "#f0c440"}"/>` : ""}
            </g>
            ${dormer}
            <g class="hs-windows-lit">
              ${upgradeWindows(windows, true)}
              ${t >= 3 ? `<rect x="${Math.round(w / 2 - 4)}" y="${Math.max(2, wallY - 5)}" width="8" height="5" fill="#f0c440"/>` : ""}
            </g>
          </svg>`;
        }

        function tavernUpgradeSVG(tier) {
          const t = Math.max(1, Math.min(4, tier|0));
          const sizes = [[64, 50], [84, 64], [108, 76], [132, 90], [158, 104]];
          const [w, h] = sizes[t];
          const baseY = h - 7;
          const wallX = Math.round(w * 0.12);
          const wallW = Math.round(w * 0.76);
          const wallH = Math.round(h * 0.42);
          const wallY = baseY - wallH;
          const roofPeakY = Math.max(0, wallY - 16 - t * 3);
          const count = Math.min(6, 2 + t);
          const windows = Array.from({ length: count }, (_, i) => {
            const gap = wallW / (count + 1);
            return [Math.round(wallX + gap * (i + 1) - 4), Math.round(wallY + (i % 2 ? wallH * 0.5 : wallH * 0.22)), 8, 6];
          });
          const side = t >= 2 ? `
            <g class="hs-walls" opacity="1">
              <rect x="2" y="${baseY - Math.round(wallH * 0.55)}" width="${wallX + 6}" height="${Math.round(wallH * 0.55)}" fill="#956a42"/>
              <rect x="${wallX + wallW - 6}" y="${baseY - Math.round(wallH * 0.58)}" width="${w - wallX - wallW + 4}" height="${Math.round(wallH * 0.58)}" fill="#956a42"/>
            </g>
            <g class="hs-roof" opacity="1">
              <polygon points="0,${baseY - Math.round(wallH * 0.55)} ${wallX / 2 + 4},${baseY - Math.round(wallH * 0.82)} ${wallX + 12},${baseY - Math.round(wallH * 0.55)}" fill="#7b2f20"/>
              <polygon points="${wallX + wallW - 10},${baseY - Math.round(wallH * 0.58)} ${w - 11},${baseY - Math.round(wallH * 0.84)} ${w},${baseY - Math.round(wallH * 0.58)}" fill="#7b2f20"/>
            </g>` : "";
          const top = t >= 3 ? `
            <g class="hs-roof" opacity="1">
              <rect x="${Math.round(w / 2 - 22)}" y="${wallY - 4}" width="44" height="14" fill="#7b2f20"/>
              <polygon points="${Math.round(w / 2 - 26)},${wallY - 4} ${w / 2},${roofPeakY + 7} ${Math.round(w / 2 + 26)},${wallY - 4}" fill="#672719"/>
              ${upgradeWindows([[Math.round(w / 2 - 16), wallY, 8, 6], [Math.round(w / 2 + 8), wallY, 8, 6]])}
            </g>` : "";

          return `<svg viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg" overflow="visible">
            <rect x="1" y="${baseY}" width="${w - 2}" height="7" fill="#4a2f1e"/>
            <rect x="1" y="${baseY}" width="${w - 2}" height="2" fill="#7a5636"/>
            ${side}
            <g class="hs-walls" opacity="1">
              <rect x="${wallX}" y="${wallY}" width="${wallW}" height="${wallH}" fill="#b48654"/>
              <rect x="${wallX}" y="${wallY}" width="${wallW}" height="2" fill="#d0a06a"/>
              <rect x="${wallX}" y="${baseY - 2}" width="${wallW}" height="2" fill="#765033"/>
              ${stoneTexture(wallX, wallY + 3, wallW, wallH - 5, "#5c341f", "#d0a06a", "#8a5a34")}
              ${upgradeWindows(windows)}
              <rect x="${Math.round(w / 2 - 7)}" y="${baseY - 15}" width="14" height="15" fill="#2a180f"/>
              <rect x="${Math.round(w / 2 - 8)}" y="${baseY - 16}" width="16" height="3" fill="#5a351f"/>
              <rect x="${wallX + 6}" y="${baseY - 5}" width="10" height="5" fill="#6a3f20"/>
              <rect x="${wallX + wallW - 18}" y="${baseY - 5}" width="12" height="5" fill="#7a4828"/>
            </g>
            <g class="hs-roof" opacity="1">
              <polygon points="${Math.max(0, wallX - 8)},${wallY} ${w / 2},${roofPeakY} ${Math.min(w, wallX + wallW + 8)},${wallY}" fill="#672719"/>
              <polygon points="${wallX - 3},${wallY - 1} ${w / 2},${roofPeakY + 6} ${wallX + wallW + 3},${wallY - 1}" fill="#9c432c"/>
              <rect x="${Math.max(0, wallX - 8)}" y="${wallY - 1}" width="${Math.min(w, wallX + wallW + 8) - Math.max(0, wallX - 8)}" height="3" fill="#3c140c"/>
              ${roofTileBands(0, 0, [[wallX, wallY - 2, wallW], [wallX + 8, wallY - 8, wallW - 16], [wallX + 18, wallY - 14, Math.max(16, wallW - 36)]], "#3c140c", 0.38)}
              <rect x="${Math.round(w * 0.72)}" y="${Math.max(0, roofPeakY + 2)}" width="${5 + t}" height="${Math.max(8, wallY - roofPeakY - 2)}" fill="#2a180f"/>
              ${t >= 4 ? `<rect x="${Math.round(w / 2)}" y="${Math.max(0, roofPeakY - 12)}" width="1" height="12" fill="#4b2d1d"/><rect x="${Math.round(w / 2 + 1)}" y="${Math.max(0, roofPeakY - 11)}" width="14" height="5" fill="#c84a35"/>` : ""}
            </g>
            ${top}
            <g class="hs-windows-lit">
              ${upgradeWindows(windows, true)}
              ${t >= 3 ? `<rect x="${Math.round(w / 2 - 16)}" y="${wallY}" width="8" height="6" fill="#f0c440"/><rect x="${Math.round(w / 2 + 8)}" y="${wallY}" width="8" height="6" fill="#f0c440"/>` : ""}
            </g>
          </svg>`;
        }

        function guildhallUpgradeSVG(tier) {
          const t = Math.max(1, Math.min(4, tier|0));
          const sizes = [[62, 64], [78, 76], [100, 86], [124, 96], [150, 110]];
          const [w, h] = sizes[t];
          const baseY = h - 8;
          const wallW = Math.round(w * 0.5);
          const wallH = Math.round(h * 0.46);
          const wallX = Math.round(w / 2 - wallW / 2);
          const wallY = baseY - wallH;
          const roofPeakY = Math.max(0, wallY - 16 - t * 3);
          const sideW = Math.max(10, Math.round(w * 0.13));
          const windows = [
            [wallX + Math.round(wallW * 0.18), wallY + Math.round(wallH * 0.33), 6, 10],
            [wallX + Math.round(wallW * 0.66), wallY + Math.round(wallH * 0.33), 6, 10],
            [Math.round(w / 2 - 4), wallY + Math.round(wallH * 0.16), 8, 11],
          ];
          const sideTowers = `
            <g class="hs-walls" opacity="1">
              <rect x="${wallX - sideW + 3}" y="${wallY + 7}" width="${sideW}" height="${baseY - wallY - 7}" fill="#817b74"/>
              <rect x="${wallX + wallW - 3}" y="${wallY + 7}" width="${sideW}" height="${baseY - wallY - 7}" fill="#817b74"/>
              ${stoneTexture(wallX - sideW + 3, wallY + 10, sideW, baseY - wallY - 12, "#665f57", "#b8b2aa", "#817b74")}
              ${stoneTexture(wallX + wallW - 3, wallY + 10, sideW, baseY - wallY - 12, "#665f57", "#b8b2aa", "#817b74")}
              <rect x="${wallX - sideW + 6}" y="${wallY + 19}" width="4" height="8" fill="#2a211b"/>
              <rect x="${wallX + wallW + 1}" y="${wallY + 19}" width="4" height="8" fill="#2a211b"/>
            </g>
            <g class="hs-roof" opacity="1">
              <polygon points="${wallX - sideW + 1},${wallY + 7} ${wallX - sideW / 2 + 3},${wallY - 5} ${wallX + 5},${wallY + 7}" fill="#302c32"/>
              <polygon points="${wallX + wallW - 5},${wallY + 7} ${wallX + wallW + sideW / 2 - 3},${wallY - 5} ${wallX + wallW + sideW - 1},${wallY + 7}" fill="#302c32"/>
            </g>`;
          const centerTower = t >= 2 ? `
            <g class="hs-walls" opacity="1">
              <rect x="${Math.round(w / 2 - 9)}" y="${Math.max(2, wallY - 18)}" width="18" height="${wallY + 16 - Math.max(2, wallY - 18)}" fill="#817b74"/>
              <rect x="${Math.round(w / 2 - 3)}" y="${Math.max(7, wallY - 7)}" width="6" height="9" fill="#2a211b"/>
            </g>
            <g class="hs-roof" opacity="1">
              <polygon points="${Math.round(w / 2 - 12)},${Math.max(2, wallY - 18)} ${w / 2},${Math.max(0, wallY - 35)} ${Math.round(w / 2 + 12)},${Math.max(2, wallY - 18)}" fill="#302c32"/>
              <rect x="${Math.round(w / 2 - 6)}" y="${Math.max(0, wallY - 40)}" width="12" height="2" fill="#d4a017"/>
            </g>` : "";
          const wings = t >= 3 ? `
            <g class="hs-walls" opacity="1">
              <rect x="2" y="${baseY - Math.round(wallH * 0.38)}" width="${wallX - 1}" height="${Math.round(wallH * 0.38)}" fill="#817b74"/>
              <rect x="${wallX + wallW - 1}" y="${baseY - Math.round(wallH * 0.38)}" width="${w - wallX - wallW - 1}" height="${Math.round(wallH * 0.38)}" fill="#817b74"/>
            </g>` : "";

          return `<svg viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg" overflow="visible">
            <rect x="2" y="${baseY}" width="${w - 4}" height="8" fill="#3f3a34"/>
            <rect x="2" y="${baseY}" width="${w - 4}" height="2" fill="#777068"/>
            ${sideTowers}
            ${wings}
            <g class="hs-walls" opacity="1">
              <rect x="${wallX}" y="${wallY}" width="${wallW}" height="${wallH}" fill="#918b82"/>
              <rect x="${wallX}" y="${wallY}" width="${wallW}" height="2" fill="#c4beb2"/>
              <rect x="${wallX}" y="${baseY - 2}" width="${wallW}" height="2" fill="#665f57"/>
              ${stoneTexture(wallX, wallY + 3, wallW, wallH - 5, "#6f685f", "#c4beb2", "#817b74")}
              ${upgradeWindows(windows)}
              <rect x="${Math.round(w / 2 - 7)}" y="${baseY - 15}" width="14" height="15" fill="#2a211b"/>
              <polygon points="${Math.round(w / 2 - 8)},${baseY - 15} ${w / 2},${baseY - 24} ${Math.round(w / 2 + 8)},${baseY - 15}" fill="#5f574e"/>
              ${t >= 4 ? `<rect x="${wallX + 4}" y="${wallY + 9}" width="${wallW - 8}" height="2" fill="#d4a017"/>` : ""}
            </g>
            <g class="hs-roof" opacity="1">
              <polygon points="${Math.max(0, wallX - 9)},${wallY} ${w / 2},${roofPeakY} ${Math.min(w, wallX + wallW + 9)},${wallY}" fill="#302c32"/>
              <polygon points="${wallX - 4},${wallY - 1} ${w / 2},${roofPeakY + 5} ${wallX + wallW + 4},${wallY - 1}" fill="#5b5360"/>
              <rect x="${Math.max(0, wallX - 9)}" y="${wallY - 1}" width="${Math.min(w, wallX + wallW + 9) - Math.max(0, wallX - 9)}" height="3" fill="#19171d"/>
              ${t >= 4 ? `<rect x="${Math.round(w / 2)}" y="${Math.max(0, roofPeakY - 12)}" width="1" height="12" fill="#d4a017"/><rect x="${Math.round(w / 2 + 1)}" y="${Math.max(0, roofPeakY - 11)}" width="14" height="4" fill="#6a2848"/>` : ""}
            </g>
            ${centerTower}
            <g class="hs-windows-lit">
              ${upgradeWindows(windows, true)}
              <rect x="${wallX - sideW + 6}" y="${wallY + 19}" width="4" height="8" fill="#f0c440"/>
              <rect x="${wallX + wallW + 1}" y="${wallY + 19}" width="4" height="8" fill="#f0c440"/>
              ${t >= 2 ? `<rect x="${Math.round(w / 2 - 3)}" y="${Math.max(7, wallY - 7)}" width="6" height="9" fill="#f0c440"/>` : ""}
            </g>
          </svg>`;
        }

        // PER-TIER WATCHTOWER — upgrades widen and heighten the displayed footprint
        // while keeping the compact stonework details.
        function towerSVG(palette, tier) {
          const t = Math.max(0, Math.min(4, tier|0));
          const stone="#a8a098", stoneL="#c8c0b0", stoneD="#80786a", stoneB="#5a544e";
          const wood="#5a4030", woodL="#7a5840", woodD="#3a2410";
          const dark="#1a1208", roofR="#8a3a25", roofRL="#a8442a";
          const gold="#d4a017", goldL="#f0c440", flag="#c84a35", flagL="#e06a45";

          const compactDecoratedTower = (level) => {
            const tier1 = level >= 1 ? `
              <g class="tw-tier-1">
                <rect x="5" y="20" width="22" height="2" fill="${stoneD}"/>
                <rect x="5" y="34" width="22" height="2" fill="${stoneD}"/>
                <rect x="5" y="48" width="22" height="2" fill="${stoneD}"/>
                <rect x="4" y="56" width="24" height="2" fill="${woodD}"/>
                <rect x="7" y="58" width="1" height="4" fill="${woodL}" opacity="0.55"/>
                <rect x="14" y="58" width="1" height="4" fill="${woodL}" opacity="0.55"/>
                <rect x="21" y="58" width="1" height="4" fill="${woodL}" opacity="0.55"/>
                <rect x="3" y="30" width="4" height="8" fill="${stone}"/>
                <rect x="25" y="30" width="4" height="8" fill="${stone}"/>
                <rect x="3" y="30" width="4" height="1" fill="${stoneL}"/>
                <rect x="25" y="30" width="4" height="1" fill="${stoneL}"/>
                <rect x="4" y="33" width="2" height="3" fill="${dark}"/>
                <rect x="26" y="33" width="2" height="3" fill="${dark}"/>
                <rect x="3" y="28" width="4" height="2" fill="${stoneD}"/>
                <rect x="25" y="28" width="4" height="2" fill="${stoneD}"/>
                <polygon points="2,28 5,24 8,28" fill="${roofR}"/>
                <polygon points="24,28 27,24 30,28" fill="${roofR}"/>
              </g>` : "";
            const tier2 = level >= 2 ? `
              <g class="tw-tier-2">
                <rect x="8" y="24" width="16" height="1" fill="${gold}" opacity="0.9"/>
                <rect x="8" y="44" width="16" height="1" fill="${gold}" opacity="0.9"/>
                <rect x="9" y="28" width="2" height="6" fill="${dark}"/>
                <rect x="21" y="28" width="2" height="6" fill="${dark}"/>
                <rect x="15" y="40" width="2" height="8" fill="${dark}"/>
                <rect x="11" y="51" width="10" height="7" fill="${woodD}"/>
                <rect x="11" y="51" width="10" height="2" fill="${wood}"/>
                <polygon points="11,51 16,46 21,51" fill="${stoneD}"/>
                <rect x="15" y="53" width="2" height="5" fill="${woodL}" opacity="0.45"/>
                <rect x="19" y="54" width="1" height="1" fill="${gold}"/>
                <rect x="6" y="38" width="1" height="5" fill="${woodD}"/>
                <rect x="25" y="38" width="1" height="5" fill="${woodD}"/>
                <rect x="4" y="42" width="5" height="1" fill="${woodD}"/>
                <rect x="23" y="42" width="5" height="1" fill="${woodD}"/>
              </g>` : "";
            const tier3 = level >= 3 ? `
              <g class="tw-tier-3">
                <rect x="2" y="22" width="5" height="18" fill="${stone}"/>
                <rect x="25" y="22" width="5" height="18" fill="${stone}"/>
                <rect x="2" y="22" width="5" height="1" fill="${stoneL}"/>
                <rect x="25" y="22" width="5" height="1" fill="${stoneL}"/>
                <rect x="2" y="39" width="5" height="1" fill="${stoneD}"/>
                <rect x="25" y="39" width="5" height="1" fill="${stoneD}"/>
                <rect x="3" y="19" width="3" height="3" fill="${stoneD}"/>
                <rect x="26" y="19" width="3" height="3" fill="${stoneD}"/>
                <polygon points="1,19 4.5,13 8,19" fill="${roofR}"/>
                <polygon points="24,19 27.5,13 31,19" fill="${roofR}"/>
                <rect x="4" y="16" width="1" height="4" fill="${gold}"/>
                <rect x="27" y="16" width="1" height="4" fill="${gold}"/>
                <rect x="3" y="28" width="2" height="4" fill="${dark}"/>
                <rect x="27" y="28" width="2" height="4" fill="${dark}"/>
                <rect x="8" y="18" width="16" height="1" fill="${goldL}" opacity="0.75"/>
                <rect x="10" y="12" width="12" height="2" fill="${stoneD}"/>
                <rect x="10" y="10" width="2" height="2" fill="${stoneD}"/>
                <rect x="15" y="10" width="2" height="2" fill="${stoneD}"/>
                <rect x="20" y="10" width="2" height="2" fill="${stoneD}"/>
              </g>` : "";
            const tier4 = level >= 4 ? `
              <g class="tw-tier-4">
                <polygon points="8,10 16,0 24,10" fill="${roofR}"/>
                <polygon points="10,10 16,3 22,10" fill="${roofRL}"/>
                <rect x="15" y="-1" width="1" height="7" fill="${gold}"/>
                <rect x="16" y="0" width="8" height="4" fill="${flag}"/>
                <rect x="16" y="0" width="8" height="1" fill="${flagL}"/>
                <polygon points="24,0 28,2 24,4" fill="${flag}"/>
                <rect x="4" y="44" width="3" height="10" fill="${stoneD}"/>
                <rect x="25" y="44" width="3" height="10" fill="${stoneD}"/>
                <rect x="5" y="46" width="1" height="6" fill="${gold}"/>
                <rect x="26" y="46" width="1" height="6" fill="${gold}"/>
                <rect x="12" y="26" width="8" height="2" fill="${gold}"/>
                <rect x="13" y="29" width="6" height="1" fill="${goldL}"/>
                <rect x="7" y="36" width="18" height="1" fill="${goldL}"/>
                <rect x="12" y="15" width="2" height="2" fill="${gold}"/>
                <rect x="18" y="15" width="2" height="2" fill="${gold}"/>
                <rect x="15" y="22" width="2" height="2" fill="${gold}"/>
                <rect x="8" y="52" width="2" height="2" fill="${gold}"/>
                <rect x="22" y="52" width="2" height="2" fill="${gold}"/>
              </g>` : "";
            return `<svg viewBox="0 0 32 64" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="2" y="58" width="28" height="6" fill="${wood}"/>
              <rect x="2" y="58" width="28" height="2" fill="${woodL}"/>
              <rect x="6" y="16" width="20" height="42" fill="${stone}"/>
              <rect x="6" y="16" width="20" height="2" fill="${stoneL}"/>
              <rect x="6" y="56" width="20" height="2" fill="${stoneD}"/>
              <rect x="6" y="30" width="20" height="1" fill="${stoneB}"/>
              <rect x="6" y="44" width="20" height="1" fill="${stoneB}"/>
              ${stoneTexture(6, 18, 20, 38, stoneB, stoneL, stoneD)}
              <rect x="6" y="16" width="2" height="40" fill="${stoneD}" opacity="0.45"/>
              <rect x="24" y="16" width="2" height="40" fill="${stoneD}" opacity="0.45"/>
              <rect x="7" y="18" width="2" height="2" fill="${stoneL}" opacity="0.55"/>
              <rect x="23" y="25" width="2" height="2" fill="${stoneB}" opacity="0.5"/>
              <rect x="7" y="39" width="2" height="2" fill="${stoneB}" opacity="0.45"/>
              <rect x="9" y="26" width="2" height="6" fill="${dark}"/>
              <rect x="21" y="26" width="2" height="6" fill="${dark}"/>
              <rect x="15" y="38" width="2" height="8" fill="${dark}"/>
              <rect x="14" y="48" width="4" height="10" fill="${woodD}"/>
              <rect x="14" y="48" width="4" height="2" fill="${wood}"/>
              <rect x="4" y="14" width="24" height="4" fill="${stoneD}"/>
              <rect x="4" y="10" width="3" height="4" fill="${stoneD}"/>
              <rect x="9" y="10" width="3" height="4" fill="${stoneD}"/>
              <rect x="14" y="10" width="4" height="4" fill="${stoneD}"/>
              <rect x="20" y="10" width="3" height="4" fill="${stoneD}"/>
              <rect x="25" y="10" width="3" height="4" fill="${stoneD}"/>
              <rect x="15" y="0" width="1" height="14" fill="#5a3818"/>
              <rect x="16" y="2" width="6" height="4" fill="${flag}"/>
              <rect x="16" y="2" width="6" height="1" fill="${flagL}"/>
              <rect x="16" y="6" width="6" height="1" fill="#8a2818" opacity="0.65"/>
              <rect x="5" y="18" width="22" height="1" fill="${stoneL}" opacity="0.28"/>
              <rect x="4" y="14" width="24" height="1" fill="${stoneL}" opacity="0.34"/>
              ${tier1}
              ${tier2}
              ${tier3}
              ${tier4}
              <g class="hs-windows-lit">
                <rect x="9" y="26" width="2" height="6" fill="${gold}"/>
                <rect x="21" y="26" width="2" height="6" fill="${gold}"/>
                <rect x="15" y="38" width="2" height="8" fill="${gold}"/>
                ${level >= 1 ? `<rect x="4" y="33" width="2" height="3" fill="${gold}"/><rect x="26" y="33" width="2" height="3" fill="${gold}"/>` : ""}
                ${level >= 2 ? `<rect x="9" y="28" width="2" height="6" fill="${gold}"/><rect x="21" y="28" width="2" height="6" fill="${gold}"/><rect x="15" y="40" width="2" height="8" fill="${gold}"/>` : ""}
                ${level >= 3 ? `<rect x="3" y="28" width="2" height="4" fill="${gold}"/><rect x="27" y="28" width="2" height="4" fill="${gold}"/>` : ""}
                ${level >= 4 ? `<rect x="5" y="46" width="1" height="6" fill="${goldL}"/><rect x="26" y="46" width="1" height="6" fill="${goldL}"/>` : ""}
              </g>
            </svg>`;
          };

          if (t > 0) return compactDecoratedTower(t);

          // t === 0 fallback — delegate to structureSVG via the existing case (this should not be hit)
          return "";
        }

        function millSVG(tier) {
          const t = Math.max(0, Math.min(4, tier|0));
          const sizes = [[44, 60], [60, 70], [78, 82], [100, 96], [124, 112]];
          const [w, h] = sizes[t];
          const cx = Math.round(w / 2);
          const foundationH = [6, 7, 8, 9, 10][t];
          const wallW = [24, 30, 38, 48, 58][t];
          const wallH = [32, 38, 46, 54, 62][t];
          const roofH = [14, 16, 18, 20, 22][t];
          const bladeLen = [32, 38, 46, 55, 64][t];
          const bladeW = [3, 4, 4, 5, 5][t];
          const wallX = cx - wallW / 2;
          const baseY = h - foundationH;
          const wallY = baseY - wallH;
          const roofY = wallY;
          const rotorY = roofY - roofH + 4;
          const doorW = [8, 9, 10, 12, 14][t];
          const doorH = [12, 14, 16, 18, 20][t];
          const doorX = cx - doorW / 2;
          const doorY = baseY - doorH;
          const windowW = [4, 4, 5, 6, 7][t];
          const windowH = [4, 5, 5, 6, 7][t];
          const leftWinX = wallX + Math.max(3, Math.round(wallW * 0.14));
          const rightWinX = wallX + wallW - Math.max(3, Math.round(wallW * 0.14)) - windowW;
          const winY = wallY + Math.round(wallH * 0.28);
          const trimY = wallY + Math.round(wallH * 0.55);
          const builtOpacity = t === 0 ? 0 : 1;
          const roofLeft = wallX - 4 - t;
          const roofRight = wallX + wallW + 4 + t;
          const roofPeakY = roofY - roofH;

          const tier1 = t >= 1 ? `
                <rect x="${wallX - 8}" y="${baseY - 4}" width="8" height="4" fill="#c8a060"/>
                <rect x="${wallX - 8}" y="${baseY - 4}" width="8" height="1" fill="#e0c080"/>
                <rect x="${wallX + wallW}" y="${baseY - 5}" width="10" height="5" fill="#7a5028"/>
                <rect x="${wallX + wallW + 1}" y="${baseY - 6}" width="8" height="1" fill="#9a6838"/>
                <rect x="${wallX + wallW + 2}" y="${baseY - 3}" width="1" height="3" fill="#5a3818"/>
                <rect x="${wallX + wallW + 7}" y="${baseY - 3}" width="1" height="3" fill="#5a3818"/>` : "";
          const tier2Walls = t >= 2 ? `
                <rect x="${wallX - 18}" y="${baseY - 18}" width="18" height="18" fill="#8a6840"/>
                <rect x="${wallX - 18}" y="${baseY - 18}" width="18" height="2" fill="#b08a58"/>
                <rect x="${wallX - 12}" y="${baseY - 12}" width="7" height="8" fill="#3a2410"/>` : "";
          const tier2Roof = t >= 2 ? `
                <polygon points="${wallX - 21},${baseY - 18} ${wallX - 9},${baseY - 29} ${wallX + 3},${baseY - 18}" fill="#6a2818"/>
                <polygon points="${wallX - 18},${baseY - 19} ${wallX - 9},${baseY - 26} ${wallX},${baseY - 19}" fill="#8a3a25"/>` : "";
          const tier3Walls = t >= 3 ? `
                <rect x="${wallX + wallW}" y="${baseY - 28}" width="15" height="28" fill="#5a3818"/>
                <rect x="${wallX + wallW + 2}" y="${baseY - 27}" width="11" height="26" fill="#7a4828"/>
                <rect x="${wallX + wallW - 1}" y="${baseY - 24}" width="17" height="2" fill="#3a2410"/>
                <rect x="${wallX + wallW - 1}" y="${baseY - 16}" width="17" height="2" fill="#3a2410"/>
                <rect x="${wallX + wallW - 1}" y="${baseY - 8}" width="17" height="2" fill="#3a2410"/>` : "";
          const tier4Walls = t >= 4 ? `
                <rect x="${cx - 8}" y="${wallY + 8}" width="16" height="14" fill="#3a2410"/>
                <rect x="${cx - 7}" y="${wallY + 9}" width="14" height="3" fill="#5a3820"/>
                <rect x="${cx - 3}" y="${wallY + 14}" width="6" height="5" fill="#f0c440"/>
                <rect x="${wallX + 4}" y="${baseY + 2}" width="5" height="2" fill="#8a8580"/>
                <rect x="${cx - 3}" y="${baseY + 1}" width="6" height="2" fill="#6a6258"/>
                <rect x="${wallX + wallW - 9}" y="${baseY + 2}" width="5" height="2" fill="#8a8580"/>` : "";
          const tier4Roof = t >= 4 ? `
                <rect x="${cx - 1}" y="${roofPeakY - 8}" width="2" height="8" fill="#d4a017"/>
                <rect x="${cx + 1}" y="${roofPeakY - 7}" width="10" height="4" fill="#c84a35"/>
                <rect x="${cx + 1}" y="${roofPeakY - 7}" width="10" height="1" fill="#e06a45"/>
                <polygon points="${cx + 11},${roofPeakY - 7} ${cx + 15},${roofPeakY - 5} ${cx + 11},${roofPeakY - 3}" fill="#c84a35"/>` : "";

          return `<svg viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="${Math.max(0, wallX - 6)}" y="${baseY}" width="${Math.min(w, wallW + 12)}" height="${foundationH}" fill="#5a4030"/>
              <rect x="${Math.max(0, wallX - 6)}" y="${baseY}" width="${Math.min(w, wallW + 12)}" height="2" fill="#7a5840"/>
              <g class="hs-walls" opacity="${builtOpacity}">
                <rect x="${wallX}" y="${wallY}" width="${wallW}" height="${wallH}" fill="#a87858"/>
                <rect x="${wallX}" y="${wallY}" width="${wallW}" height="2" fill="#c89878"/>
                <rect x="${wallX}" y="${baseY - 2}" width="${wallW}" height="2" fill="#80583a"/>
                <rect x="${doorX}" y="${doorY}" width="${doorW}" height="${doorH}" fill="#3a2410"/>
                <rect x="${doorX + doorW - 4}" y="${doorY + Math.round(doorH / 2)}" width="1" height="1" fill="#d4a017"/>
                <rect x="${leftWinX}" y="${winY}" width="${windowW}" height="${windowH}" fill="#5a4830"/>
                <rect x="${rightWinX}" y="${winY}" width="${windowW}" height="${windowH}" fill="#5a4830"/>
                <rect x="${wallX}" y="${trimY}" width="${wallW}" height="1" fill="#80583a"/>
                ${tier1}
                ${tier2Walls}
                ${tier3Walls}
                ${tier4Walls}
              </g>
              <g class="hs-roof" opacity="${builtOpacity}">
                <polygon points="${roofLeft},${roofY} ${roofRight},${roofY} ${cx},${roofPeakY}" fill="#6a2818"/>
                <polygon points="${roofLeft + 3},${roofY - 1} ${roofRight - 3},${roofY - 1} ${cx},${roofPeakY + 3}" fill="#8a3a25"/>
                <rect x="${cx - 2}" y="${roofPeakY + 2}" width="4" height="5" fill="#3a2410"/>
                <g class="mill-blades">
                  <rect x="${cx - bladeLen}" y="${rotorY - bladeW / 2}" width="${bladeLen * 2}" height="${bladeW}" fill="#8a6840"/>
                  <rect x="${cx - bladeLen}" y="${rotorY - bladeW / 2}" width="${bladeLen * 2}" height="1" fill="#a87838"/>
                  <rect x="${cx - bladeW / 2}" y="${rotorY - bladeLen}" width="${bladeW}" height="${bladeLen * 2}" fill="#8a6840"/>
                  <rect x="${cx - bladeW / 2}" y="${rotorY - bladeLen}" width="1" height="${bladeLen * 2}" fill="#a87838"/>
                </g>
                <rect x="${cx - 2}" y="${rotorY - 2}" width="4" height="4" fill="#6a4828"/>
                <rect x="${cx - 1}" y="${rotorY - 1}" width="2" height="2" fill="#d4a017"/>
                ${tier2Roof}
                ${tier4Roof}
              </g>
              <g class="hs-windows-lit">
                <rect x="${leftWinX}" y="${winY}" width="${windowW}" height="${windowH}" fill="#f0c440"/>
                <rect x="${rightWinX}" y="${winY}" width="${windowW}" height="${windowH}" fill="#f0c440"/>
                ${t >= 2 ? `<rect x="${wallX - 11}" y="${baseY - 11}" width="5" height="6" fill="#f0c440"/>` : ""}
                ${t >= 4 ? `<rect x="${cx - 3}" y="${wallY + 14}" width="6" height="5" fill="#f0c440"/>` : ""}
              </g>
            </svg>`;
        }

        function tavernSVG(tier) {
          const t = Math.max(0, Math.min(4, tier | 0));
          const sizes = [[72, 58], [84, 64], [108, 76], [132, 90], [158, 104]];
          const [w, h] = sizes[t];
          const cx = Math.round(w / 2);
          const baseH = [7, 7, 8, 9, 10][t];
          const baseY = h - baseH;
          const mainW = [54, 62, 74, 88, 104][t];
          const mainH = [28, 32, 38, 46, 54][t];
          const mainX = Math.round(cx - mainW / 2);
          const mainY = baseY - mainH;
          const roofH = [17, 19, 22, 26, 30][t];
          const roofY = mainY;
          const roofPeakY = roofY - roofH;
          const roofLeft = mainX - 5 - t;
          const roofRight = mainX + mainW + 5 + t;
          const doorW = [10, 11, 13, 15, 17][t];
          const doorH = [13, 15, 18, 22, 26][t];
          const doorX = cx - Math.round(doorW / 2);
          const doorY = baseY - doorH;
          const winW = [7, 8, 9, 10, 12][t];
          const winH = [6, 7, 8, 9, 10][t];
          const winY = mainY + Math.max(5, Math.round(mainH * 0.22));
          const leftWinX = mainX + Math.max(7, Math.round(mainW * 0.16));
          const rightWinX = mainX + mainW - Math.max(7, Math.round(mainW * 0.16)) - winW;
          const signW = [20, 22, 26, 30, 34][t];
          const signH = [8, 8, 9, 10, 11][t];
          const signX = cx - Math.round(signW / 2);
          const signY = Math.min(doorY - signH - 2, mainY + Math.round(mainH * 0.47));
          const leftWingW = [0, 0, 22, 28, 34][t];
          const leftWingH = [0, 0, 23, 29, 36][t];
          const leftWingX = Math.max(2, mainX - leftWingW + 3);
          const leftWingY = baseY - leftWingH;
          const rightWingW = [0, 0, 0, 28, 34][t];
          const rightWingH = [0, 0, 0, 36, 45][t];
          const rightWingX = Math.min(mainX + mainW - 3, w - rightWingW - 2);
          const rightWingY = baseY - rightWingH;
          const beams = `
                <rect x="${mainX + 3}" y="${mainY + 2}" width="3" height="${mainH - 3}" fill="#4b2d1d"/>
                <rect x="${cx - 2}" y="${mainY + 2}" width="4" height="${mainH - 3}" fill="#4b2d1d"/>
                <rect x="${mainX + mainW - 6}" y="${mainY + 2}" width="3" height="${mainH - 3}" fill="#4b2d1d"/>
                <rect x="${mainX}" y="${mainY + Math.round(mainH * 0.43)}" width="${mainW}" height="3" fill="#4b2d1d"/>
                <rect x="${mainX}" y="${baseY - 4}" width="${mainW}" height="2" fill="#765033"/>`;
          const leftWing = t >= 2 ? (() => {
            const ew = leftWingW;
            const eh = leftWingH;
            const ex = leftWingX;
            const ey = leftWingY;
            const ePeak = ey - [0, 0, 11, 13, 16][t];
            return `
                <rect x="${ex}" y="${ey}" width="${ew}" height="${eh}" fill="#a8754a"/>
                <rect x="${ex}" y="${ey}" width="${ew}" height="2" fill="#d0a06a"/>
                <rect x="${ex + 3}" y="${ey + 3}" width="3" height="${eh - 4}" fill="#4b2d1d"/>
                <rect x="${ex + ew - 6}" y="${ey + 3}" width="3" height="${eh - 4}" fill="#4b2d1d"/>
                <rect x="${ex + 6}" y="${ey + 9}" width="${Math.max(7, ew - 13)}" height="${Math.max(6, Math.round(eh * 0.26))}" fill="#423025"/>
                <rect x="${ex + 7}" y="${ey + 10}" width="${Math.max(5, ew - 15)}" height="${Math.max(4, Math.round(eh * 0.2))}" fill="#f0c440"/>
                <polygon points="${ex - 3},${ey} ${ex + ew + 3},${ey} ${ex + Math.round(ew / 2)},${ePeak}" fill="#672719"/>
                <polygon points="${ex},${ey - 1} ${ex + ew},${ey - 1} ${ex + Math.round(ew / 2)},${ePeak + 3}" fill="#9c432c"/>
                <rect x="${ex - 3}" y="${ey - 1}" width="${ew + 6}" height="2" fill="#3c140c"/>`;
          })() : "";
          const rightWing = t >= 3 ? (() => {
            const ew = rightWingW;
            const eh = rightWingH;
            const ex = rightWingX;
            const ey = rightWingY;
            const ePeak = ey - [0, 0, 0, 15, 19][t];
            const eWinW = Math.max(7, Math.round(ew * 0.32));
            return `
                <rect x="${ex}" y="${ey}" width="${ew}" height="${eh}" fill="#a8754a"/>
                <rect x="${ex}" y="${ey}" width="${ew}" height="2" fill="#d0a06a"/>
                <rect x="${ex + 3}" y="${ey + 3}" width="3" height="${eh - 4}" fill="#4b2d1d"/>
                <rect x="${ex + ew - 6}" y="${ey + 3}" width="3" height="${eh - 4}" fill="#4b2d1d"/>
                <rect x="${ex}" y="${ey + Math.round(eh * 0.5)}" width="${ew}" height="2" fill="#4b2d1d"/>
                <rect x="${ex + 8}" y="${ey + 9}" width="${eWinW}" height="${Math.max(7, Math.round(eh * 0.2))}" fill="#423025"/>
                <rect x="${ex + 9}" y="${ey + 10}" width="${eWinW - 2}" height="${Math.max(5, Math.round(eh * 0.15))}" fill="#f0c440"/>
                <rect x="${ex + 8}" y="${ey + Math.round(eh * 0.6)}" width="${eWinW}" height="${Math.max(7, Math.round(eh * 0.18))}" fill="#423025"/>
                <rect x="${ex + 9}" y="${ey + Math.round(eh * 0.6) + 1}" width="${eWinW - 2}" height="${Math.max(5, Math.round(eh * 0.13))}" fill="#f0c440"/>
                <polygon points="${ex - 4},${ey} ${ex + ew + 4},${ey} ${ex + Math.round(ew / 2)},${ePeak}" fill="#672719"/>
                <polygon points="${ex - 1},${ey - 1} ${ex + ew + 1},${ey - 1} ${ex + Math.round(ew / 2)},${ePeak + 4}" fill="#9c432c"/>
                <rect x="${ex - 4}" y="${ey - 1}" width="${ew + 8}" height="2" fill="#3c140c"/>`;
          })() : "";
          const grandDormer = t >= 4 ? `
                <rect x="${cx - 18}" y="${roofPeakY + 9}" width="36" height="23" fill="#8f623d"/>
                <rect x="${cx - 18}" y="${roofPeakY + 9}" width="36" height="2" fill="#c2905e"/>
                <rect x="${cx - 3}" y="${roofPeakY + 14}" width="6" height="14" fill="#4b2d1d"/>
                <rect x="${cx - 15}" y="${roofPeakY + 18}" width="8" height="7" fill="#423025"/>
                <rect x="${cx - 14}" y="${roofPeakY + 19}" width="6" height="5" fill="#f0c440"/>
                <rect x="${cx + 7}" y="${roofPeakY + 18}" width="8" height="7" fill="#423025"/>
                <rect x="${cx + 8}" y="${roofPeakY + 19}" width="6" height="5" fill="#f0c440"/>
                <polygon points="${cx - 22},${roofPeakY + 9} ${cx + 22},${roofPeakY + 9} ${cx},${roofPeakY - 4}" fill="#672719"/>
                <polygon points="${cx - 18},${roofPeakY + 8} ${cx + 18},${roofPeakY + 8} ${cx},${roofPeakY}" fill="#b85035"/>
                <rect x="${cx - 23}" y="${roofPeakY + 8}" width="46" height="2" fill="#d4a017"/>
                <rect x="${cx - 1}" y="${roofPeakY - 11}" width="2" height="8" fill="#d4a017"/>
                <rect x="${cx + 1}" y="${roofPeakY - 10}" width="10" height="4" fill="#c84a35"/>
                <rect x="${cx + 1}" y="${roofPeakY - 10}" width="10" height="1" fill="#e06a45"/>
                <polygon points="${cx + 11},${roofPeakY - 10} ${cx + 15},${roofPeakY - 8} ${cx + 11},${roofPeakY - 6}" fill="#c84a35"/>` : "";
          const chimney = t >= 1 ? `
                <rect x="${roofRight - 18}" y="${roofPeakY - 2}" width="6" height="${Math.max(11, roofH - 4)}" fill="#2a180f"/>
                <rect x="${roofRight - 18}" y="${roofPeakY - 2}" width="6" height="2" fill="#5a3820"/>
                <rect x="${roofRight - 18}" y="${roofPeakY + 4}" width="6" height="1" fill="#5a3820" opacity="0.75"/>
                <g class="chimney-smoke">
                  <circle cx="${roofRight - 15}" cy="${roofPeakY - 5}" r="1.7" fill="#d8d4c8" opacity="0.8"/>
                  <circle cx="${roofRight - 17}" cy="${roofPeakY - 9}" r="1.2" fill="#c8c4b8" opacity="0.68"/>
                  <circle cx="${roofRight - 14}" cy="${roofPeakY - 12}" r="0.9" fill="#b8b4a8" opacity="0.52"/>
                </g>` : "";
          const seating = t >= 1 ? `
                <rect x="${mainX + 4}" y="${baseY - 4}" width="12" height="4" fill="#6a3f20"/>
                <rect x="${mainX + 5}" y="${baseY - 5}" width="10" height="1" fill="#9a6838"/>
                <rect x="${mainX + mainW - 16}" y="${baseY - 4}" width="12" height="4" fill="#6a3f20"/>
                <rect x="${mainX + mainW - 15}" y="${baseY - 5}" width="10" height="1" fill="#9a6838"/>` : "";
          const lowerWindows = t >= 2 ? `
                <rect x="${mainX + 9}" y="${doorY + Math.round(doorH * 0.38)}" width="${winW}" height="${Math.max(5, Math.round(winH * 0.8))}" fill="#423025"/>
                <rect x="${mainX + 10}" y="${doorY + Math.round(doorH * 0.38) + 1}" width="${winW - 2}" height="${Math.max(3, Math.round(winH * 0.55))}" fill="#f0c440"/>
                <rect x="${mainX + mainW - 9 - winW}" y="${doorY + Math.round(doorH * 0.38)}" width="${winW}" height="${Math.max(5, Math.round(winH * 0.8))}" fill="#423025"/>
                <rect x="${mainX + mainW - 8 - winW}" y="${doorY + Math.round(doorH * 0.38) + 1}" width="${winW - 2}" height="${Math.max(3, Math.round(winH * 0.55))}" fill="#f0c440"/>` : "";
          return `<svg viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="${Math.max(0, mainX - 4)}" y="${baseY}" width="${Math.min(w, mainW + 8)}" height="${baseH}" fill="#4a2f1e"/>
              <rect x="${Math.max(0, mainX - 4)}" y="${baseY}" width="${Math.min(w, mainW + 8)}" height="2" fill="#7a5636"/>
              <rect x="${Math.max(2, mainX)}" y="${h - 2}" width="${Math.min(w - 4, mainW)}" height="2" fill="#24170f"/>
              <g class="hs-walls" opacity="0">
                ${leftWing}
                ${rightWing}
                <rect x="${mainX}" y="${mainY}" width="${mainW}" height="${mainH}" fill="#b48654"/>
                <rect x="${mainX}" y="${mainY}" width="${mainW}" height="2" fill="#d0a06a"/>
                ${beams}
                <rect x="${doorX}" y="${doorY}" width="${doorW}" height="${doorH}" fill="#2a180f"/>
                <rect x="${doorX}" y="${doorY}" width="${doorW}" height="2" fill="#5a351f"/>
                <rect x="${doorX + doorW - 3}" y="${doorY + Math.round(doorH / 2)}" width="1" height="1" fill="#f0c440"/>
                <rect x="${leftWinX}" y="${winY}" width="${winW}" height="${winH}" fill="#423025"/>
                <rect x="${leftWinX + 1}" y="${winY + 1}" width="${winW - 2}" height="${winH - 2}" fill="#ffd77a"/>
                <rect x="${rightWinX}" y="${winY}" width="${winW}" height="${winH}" fill="#423025"/>
                <rect x="${rightWinX + 1}" y="${winY + 1}" width="${winW - 2}" height="${winH - 2}" fill="#ffd77a"/>
                ${lowerWindows}
                <rect x="${signX}" y="${signY}" width="${signW}" height="${signH}" fill="#6a4828"/>
                <rect x="${signX}" y="${signY}" width="${signW}" height="2" fill="#9a6838"/>
                <rect x="${signX + 4}" y="${signY + 3}" width="${signW - 8}" height="2" fill="#d4a017"/>
                <rect x="${cx - 3}" y="${signY + 5}" width="6" height="2" fill="#d4a017"/>
                ${seating}
              </g>
              <g class="hs-roof" opacity="0">
                <polygon points="${roofLeft},${roofY} ${roofRight},${roofY} ${cx},${roofPeakY}" fill="#672719"/>
                <polygon points="${roofLeft + 4},${roofY - 1} ${roofRight - 4},${roofY - 1} ${cx},${roofPeakY + 4}" fill="#9c432c"/>
                <rect x="${roofLeft}" y="${roofY - 1}" width="${roofRight - roofLeft}" height="3" fill="#3c140c"/>
                <rect x="${roofLeft + 9}" y="${roofY - 5}" width="${roofRight - roofLeft - 18}" height="1" fill="#3c140c" opacity="0.5"/>
                <rect x="${roofLeft + 17}" y="${roofY - 9}" width="${roofRight - roofLeft - 34}" height="1" fill="#3c140c" opacity="0.45"/>
                <rect x="${roofLeft + 26}" y="${roofY - 13}" width="${Math.max(10, roofRight - roofLeft - 52)}" height="1" fill="#3c140c" opacity="0.4"/>
                ${chimney}
                ${grandDormer}
                <rect x="${roofLeft}" y="${roofY - 1}" width="${roofRight - roofLeft}" height="1" fill="#b86040" opacity="0.5"/>
                ${t >= 4 ? `<rect x="${roofLeft}" y="${roofY - 1}" width="${roofRight - roofLeft}" height="1" fill="#d4a017"/>` : ""}
              </g>
              <g class="hs-windows-lit">
                <rect x="${leftWinX}" y="${winY}" width="${winW}" height="${winH}" fill="#f0c440"/>
                <rect x="${rightWinX}" y="${winY}" width="${winW}" height="${winH}" fill="#f0c440"/>
                <rect x="${doorX + 3}" y="${doorY + Math.max(4, Math.round(doorH * 0.35))}" width="${doorW - 6}" height="${Math.max(4, Math.round(doorH * 0.32))}" fill="#f0c440"/>
                ${t >= 2 ? `<rect x="${mainX + 9}" y="${doorY + Math.round(doorH * 0.38)}" width="${winW}" height="${Math.max(5, Math.round(winH * 0.8))}" fill="#f0c440"/>
                <rect x="${mainX + mainW - 9 - winW}" y="${doorY + Math.round(doorH * 0.38)}" width="${winW}" height="${Math.max(5, Math.round(winH * 0.8))}" fill="#f0c440"/>
                <rect x="${leftWingX + 7}" y="${leftWingY + 10}" width="${Math.max(5, leftWingW - 15)}" height="${Math.max(4, Math.round(leftWingH * 0.2))}" fill="#f0c440"/>` : ""}
                ${t >= 3 ? `<rect x="${rightWingX + 8}" y="${rightWingY + 10}" width="${Math.max(7, Math.round(rightWingW * 0.32))}" height="${Math.max(7, Math.round(rightWingH * 0.2))}" fill="#f0c440"/>
                <rect x="${rightWingX + 8}" y="${rightWingY + Math.round(rightWingH * 0.6)}" width="${Math.max(7, Math.round(rightWingW * 0.32))}" height="${Math.max(7, Math.round(rightWingH * 0.18))}" fill="#f0c440"/>` : ""}
                ${t >= 4 ? `<rect x="${cx - 15}" y="${roofPeakY + 18}" width="8" height="7" fill="#f0c440"/>
                <rect x="${cx + 7}" y="${roofPeakY + 18}" width="8" height="7" fill="#f0c440"/>` : ""}
              </g>
            </svg>`;
        }

        function structureSVG(kind, palette) {
          switch (kind) {
            case "house": {
              const p = palette || HOUSE_PALETTES[0];
              const variant = (palette && palette.variant) || "cottage";
              const isStone = Boolean(p.masonry);
              const trim = p.trim || "#d4a017";
              const trimL = p.trimL || "#f0c440";
              const flower = p.flower || "#e04060";
              const flower2 = p.flower2 || "#f0c440";
              const accent = p.accent || "#4080d0";
              const sign = p.sign || "#8a3a25";
              const stoneCottage = isStone ? `
                <rect x="4" y="16" width="28" height="1" fill="${p.wallD}" opacity="0.45"/>
                <rect x="4" y="21" width="28" height="1" fill="${p.wallD}" opacity="0.45"/>
                <rect x="12" y="14" width="1" height="3" fill="${p.wallL}" opacity="0.55"/>
                <rect x="22" y="17" width="1" height="4" fill="${p.wallD}" opacity="0.4"/>
                <rect x="13" y="21" width="1" height="3" fill="${p.wallD}" opacity="0.4"/>
                <rect x="30" y="14" width="2" height="12" fill="${p.beam}" opacity="0.75"/>` : "";
              const stoneTwoStory = isStone ? `
                    <rect x="4" y="20" width="24" height="1" fill="${p.wallD}" opacity="0.5"/>
                    <rect x="4" y="31" width="24" height="1" fill="${p.wallD}" opacity="0.5"/>
                    <rect x="11" y="16" width="1" height="4" fill="${p.wallL}" opacity="0.6"/>
                    <rect x="20" y="20" width="1" height="5" fill="${p.wallD}" opacity="0.4"/>
                    <rect x="14" y="32" width="1" height="4" fill="${p.wallD}" opacity="0.45"/>
                    <rect x="26" y="25" width="2" height="13" fill="${p.beam}" opacity="0.75"/>` : "";
              const stoneAFrame = isStone ? `
                    <rect x="3" y="31" width="30" height="1" fill="${p.wallD}" opacity="0.5"/>
                    <rect x="8" y="28" width="1" height="3" fill="${p.wallL}" opacity="0.55"/>
                    <rect x="27" y="28" width="1" height="4" fill="${p.wallD}" opacity="0.45"/>` : "";
              const stoneLonghouse = isStone ? `
                    <rect x="2" y="17" width="52" height="1" fill="${p.wallD}" opacity="0.48"/>
                    <rect x="2" y="22" width="52" height="1" fill="${p.wallD}" opacity="0.48"/>
                    <rect x="10" y="14" width="1" height="3" fill="${p.wallL}" opacity="0.55"/>
                    <rect x="21" y="17" width="1" height="5" fill="${p.wallD}" opacity="0.4"/>
                    <rect x="34" y="14" width="1" height="3" fill="${p.wallL}" opacity="0.55"/>
                    <rect x="47" y="22" width="1" height="3" fill="${p.wallD}" opacity="0.4"/>` : "";

              if (variant === "two-story") {
                return `<svg viewBox="0 0 32 44" xmlns="http://www.w3.org/2000/svg" overflow="visible">
                  <rect x="0" y="38" width="32" height="6" fill="#5a4030"/>
                  <rect x="0" y="38" width="32" height="2" fill="#7a5840"/>
                  <rect x="2" y="42" width="28" height="2" fill="#3a2818"/>
                  <g class="hs-walls" opacity="0">
                    <rect x="4" y="14" width="24" height="24" fill="${p.wall}"/>
                    <rect x="4" y="14" width="24" height="2" fill="${p.wallL}"/>
                    <rect x="4" y="36" width="24" height="2" fill="${p.wallD}"/>
                    <rect x="4" y="25" width="24" height="1" fill="${p.beam}"/>
                    <rect x="5" y="16" width="2" height="20" fill="${p.beam}"/>
                    <rect x="25" y="16" width="2" height="20" fill="${p.beam}"/>
                    ${stoneTwoStory}
                    <rect x="13" y="29" width="6" height="9" fill="#3a2410"/>
                    <rect x="17" y="33" width="1" height="1" fill="#d4a017"/>
                    <rect x="8" y="18" width="4" height="4" fill="#5a4830"/>
                    <rect x="9" y="19" width="1" height="2" fill="#f0d890"/>
                    <rect x="11" y="19" width="1" height="2" fill="#f0d890"/>
                    <rect x="20" y="18" width="4" height="4" fill="#5a4830"/>
                    <rect x="21" y="19" width="1" height="2" fill="#f0d890"/>
                    <rect x="23" y="19" width="1" height="2" fill="#f0d890"/>
                    <rect x="8" y="29" width="3" height="4" fill="#5a4830"/>
                    <rect x="9" y="30" width="1" height="3" fill="#f0d890"/>
                    <rect x="21" y="29" width="3" height="4" fill="#5a4830"/>
                    <rect x="22" y="30" width="1" height="3" fill="#f0d890"/>
                  </g>
                  <g class="hs-windows-lit">
                    <rect x="8" y="18" width="4" height="4" fill="#d4a017"/>
                    <rect x="20" y="18" width="4" height="4" fill="#d4a017"/>
                    <rect x="8" y="29" width="3" height="4" fill="#d4a017"/>
                    <rect x="21" y="29" width="3" height="4" fill="#d4a017"/>
                  </g>
                  <g class="hs-roof" opacity="0">
                    <polygon points="0,14 16,2 32,14" fill="${p.roof}"/>
                    <polygon points="2,13 16,4 30,13" fill="${p.roofL}"/>
                    <rect x="0" y="13" width="32" height="2" fill="${p.roofD}"/>
                    <polygon points="4,11 16,5 28,11" fill="${p.roofD}" opacity="0.35"/>
                    <polygon points="6,9 16,4 26,9" fill="${p.roofD}" opacity="0.35"/>
                    <!-- prominent chimney -->
                    <rect x="22" y="-6" width="4" height="11" fill="#3a2410"/>
                    <rect x="22" y="-6" width="4" height="2" fill="#5a3820"/>
                    <rect x="22" y="-2" width="4" height="0.5" fill="#5a3820" opacity="0.6"/>
                    <rect x="22" y="1" width="4" height="0.5" fill="#5a3820" opacity="0.6"/>
                  </g>

                  <g class="up-1">
                    <!-- chimney smoke + small fence -->
                    <g class="chimney-smoke">
                      <circle cx="24" cy="-8" r="1.6" fill="#d8d4c8" opacity="0.85"/>
                      <circle cx="23" cy="-11" r="1.2" fill="#c8c4b8" opacity="0.75"/>
                      <circle cx="25" cy="-13" r="0.9" fill="#b8b4a8" opacity="0.55"/>
                    </g>
                    <rect x="-4" y="41" width="6" height="3" fill="#8a6840"/>
                    <rect x="0" y="39" width="1" height="5" fill="#5a3818"/>
                    <rect x="30" y="41" width="6" height="3" fill="#8a6840"/>
                    <rect x="31" y="39" width="1" height="5" fill="#5a3818"/>
                  </g>

                  <g class="up-2">
                    <!-- planter boxes under both upper windows -->
                    <rect x="7" y="22" width="6" height="2" fill="#6a4828"/>
                    <rect x="7" y="21" width="6" height="1" fill="#9a6838"/>
                    <rect x="8" y="20" width="1" height="1" fill="${flower}"/>
                    <rect x="10" y="20" width="1" height="1" fill="${flower2}"/>
                    <rect x="19" y="22" width="6" height="2" fill="#6a4828"/>
                    <rect x="19" y="21" width="6" height="1" fill="#9a6838"/>
                    <rect x="20" y="20" width="1" height="1" fill="${accent}"/>
                    <rect x="22" y="20" width="1" height="1" fill="${flower}"/>
                    <!-- door awning -->
                    <rect x="11" y="28" width="10" height="1" fill="${p.roof}"/>
                    <rect x="11" y="28" width="10" height="0.5" fill="${p.roofL}"/>
                  </g>

                  <g class="up-3">
                    <!-- balcony on second floor -->
                    <rect x="6" y="24" width="20" height="1" fill="#6a4828"/>
                    <rect x="6" y="25" width="1" height="2" fill="#6a4828"/>
                    <rect x="12" y="25" width="1" height="2" fill="#6a4828"/>
                    <rect x="19" y="25" width="1" height="2" fill="#6a4828"/>
                    <rect x="25" y="25" width="1" height="2" fill="#6a4828"/>
                    <!-- garden plot -->
                    <rect x="-3" y="40" width="6" height="2" fill="#4a3018"/>
                    <rect x="-3" y="40" width="6" height="0.5" fill="#6a4828"/>
                    <rect x="-2" y="38" width="1" height="2" fill="#3a5a28"/>
                    <rect x="0" y="38" width="1" height="2" fill="#3a5a28"/>
                    <rect x="2" y="38" width="1" height="2" fill="#3a5a28"/>
                  </g>

                  <g class="up-4">
                    <!-- gold trim + climbing vine -->
                    <rect x="0" y="13" width="32" height="1" fill="${trim}"/>
                    <rect x="22" y="-6" width="4" height="1" fill="${trim}"/>
                    <!-- climbing vine up left wall -->
                    <rect x="4" y="20" width="1" height="4" fill="#3a5a28"/>
                    <rect x="3" y="22" width="2" height="1" fill="#5a7a36"/>
                    <rect x="4" y="26" width="1" height="6" fill="#3a5a28"/>
                    <rect x="3" y="28" width="2" height="1" fill="#5a7a36"/>
                    <rect x="3" y="32" width="2" height="1" fill="#5a7a36"/>
                    <rect x="2" y="20" width="1" height="1" fill="${flower}"/>
                    <rect x="2" y="28" width="1" height="1" fill="${flower}"/>
                    <!-- weathervane -->
                    <rect x="15" y="-3" width="1" height="5" fill="#3a2410"/>
                    <rect x="13" y="-5" width="1" height="2" fill="#3a2410"/>
                    <rect x="17" y="-5" width="1" height="2" fill="#3a2410"/>
                  </g>
                </svg>`;
              }

              if (variant === "a-frame") {
                return `<svg viewBox="0 0 36 40" xmlns="http://www.w3.org/2000/svg" overflow="visible">
                  <rect x="0" y="34" width="36" height="6" fill="#5a4030"/>
                  <rect x="0" y="34" width="36" height="2" fill="#7a5840"/>
                  <rect x="2" y="38" width="32" height="2" fill="#3a2818"/>
                  <g class="hs-walls" opacity="0">
                    <!-- small base showing through under the roof -->
                    <rect x="3" y="28" width="30" height="6" fill="${p.wall}"/>
                    <rect x="3" y="28" width="30" height="1" fill="${p.wallL}"/>
                    <rect x="3" y="33" width="30" height="1" fill="${p.wallD}"/>
                    <!-- prominent door -->
                    <rect x="15" y="26" width="6" height="8" fill="#3a2410"/>
                    <rect x="15" y="26" width="6" height="1" fill="#5a3820"/>
                    <rect x="19" y="30" width="1" height="1" fill="#d4a017"/>
                    <!-- timber beams angling along the A-frame -->
                    <rect x="3" y="28" width="2" height="6" fill="${p.beam}"/>
                    <rect x="31" y="28" width="2" height="6" fill="${p.beam}"/>
                    ${stoneAFrame}
                  </g>
                  <g class="hs-windows-lit">
                    <!-- attic window high up -->
                    <rect x="16" y="14" width="4" height="5" fill="#d4a017"/>
                  </g>
                  <g class="hs-roof" opacity="0">
                    <!-- the iconic steep triangle (roof reaches the foundation) -->
                    <polygon points="0,34 18,-2 36,34" fill="${p.roof}"/>
                    <polygon points="2,34 18,1 34,34" fill="${p.roofL}"/>
                    <polygon points="4,34 18,4 32,34" fill="${p.roof}"/>
                    <polygon points="6,34 18,7 30,34" fill="${p.roofL}" opacity="0.6"/>
                    <!-- horizontal tile rows for texture -->
                    <rect x="4" y="20" width="28" height="0.6" fill="${p.roofD}" opacity="0.6"/>
                    <rect x="8" y="14" width="20" height="0.6" fill="${p.roofD}" opacity="0.6"/>
                    <rect x="12" y="8" width="12" height="0.6" fill="${p.roofD}" opacity="0.6"/>
                    <!-- attic window frame -->
                    <rect x="15" y="13" width="6" height="7" fill="#3a2410"/>
                    <rect x="16" y="14" width="4" height="5" fill="#5a4830"/>
                    <rect x="18" y="14" width="0.6" height="5" fill="#3a2410"/>
                    <rect x="16" y="16" width="4" height="0.6" fill="#3a2410"/>
                    <!-- finial at top -->
                    <rect x="17.5" y="-6" width="1" height="4" fill="#3a2410"/>
                    <rect x="16" y="-4" width="4" height="1" fill="#d4a017"/>
                  </g>

                  <g class="up-1">
                    <!-- chimney + smoke on one side -->
                    <rect x="6" y="14" width="3" height="6" fill="#3a2410"/>
                    <rect x="6" y="14" width="3" height="1" fill="#5a3820"/>
                    <g class="chimney-smoke">
                      <circle cx="7.5" cy="12" r="1.4" fill="#d8d4c8" opacity="0.8"/>
                      <circle cx="6" cy="9" r="1.0" fill="#c8c4b8" opacity="0.7"/>
                    </g>
                    <!-- bench beside the door -->
                    <rect x="23" y="32" width="6" height="1" fill="#6a4828"/>
                    <rect x="24" y="33" width="1" height="2" fill="#6a4828"/>
                    <rect x="28" y="33" width="1" height="2" fill="#6a4828"/>
                  </g>

                  <g class="up-2">
                    <!-- flower pots flanking the door -->
                    <rect x="11" y="31" width="3" height="3" fill="#8a4828"/>
                    <rect x="11" y="31" width="3" height="1" fill="#a86038"/>
                    <rect x="11" y="29" width="3" height="2" fill="#3a5a28"/>
                    <rect x="11" y="28" width="1" height="1" fill="#e04060"/>
                    <rect x="13" y="28" width="1" height="1" fill="#f0c440"/>
                    <rect x="22" y="31" width="3" height="3" fill="#8a4828"/>
                    <rect x="22" y="31" width="3" height="1" fill="#a86038"/>
                    <rect x="22" y="29" width="3" height="2" fill="#3a5a28"/>
                    <rect x="22" y="28" width="1" height="1" fill="#8040b0"/>
                    <rect x="24" y="28" width="1" height="1" fill="#4080d0"/>
                    <!-- lantern at door -->
                    <rect x="14" y="26" width="1" height="2" fill="#3a2410"/>
                    <rect x="13" y="27" width="2" height="2" fill="#f0c440"/>
                  </g>

                  <g class="up-3">
                    <!-- shutters on attic window -->
                    <rect x="14" y="13" width="1.5" height="7" fill="${p.beam}"/>
                    <rect x="20.5" y="13" width="1.5" height="7" fill="${p.beam}"/>
                    <!-- garden plot in front -->
                    <rect x="2" y="36" width="32" height="2" fill="#4a3018" opacity="0.7"/>
                    <rect x="4" y="34" width="1" height="2" fill="#3a5a28"/>
                    <rect x="8" y="34" width="1" height="2" fill="#3a5a28"/>
                    <rect x="26" y="34" width="1" height="2" fill="#3a5a28"/>
                    <rect x="30" y="34" width="1" height="2" fill="#3a5a28"/>
                  </g>

                  <g class="up-4">
                    <!-- gold trim along the roof eaves -->
                    <line x1="0" y1="34" x2="36" y2="34" stroke="${trim}" stroke-width="1"/>
                    <!-- climbing vine -->
                    <rect x="32" y="20" width="1" height="14" fill="#3a5a28"/>
                    <rect x="31" y="22" width="2" height="1" fill="#5a7a36"/>
                    <rect x="31" y="26" width="2" height="1" fill="#5a7a36"/>
                    <rect x="31" y="30" width="2" height="1" fill="#5a7a36"/>
                    <rect x="30" y="22" width="1" height="1" fill="${flower}"/>
                    <rect x="33" y="28" width="1" height="1" fill="${flower2}"/>
                    <!-- top finial gold -->
                    <rect x="16" y="-4" width="4" height="1" fill="${trimL}"/>
                  </g>
                </svg>`;
              }

              if (variant === "longhouse") {
                return `<svg viewBox="0 0 56 32" xmlns="http://www.w3.org/2000/svg" overflow="visible">
                  <rect x="0" y="26" width="56" height="6" fill="#5a4030"/>
                  <rect x="0" y="26" width="56" height="2" fill="#7a5840"/>
                  <rect x="2" y="30" width="52" height="2" fill="#3a2818"/>
                  <g class="hs-walls" opacity="0">
                    <rect x="2" y="12" width="52" height="14" fill="${p.wall}"/>
                    <rect x="2" y="12" width="52" height="2" fill="${p.wallL}"/>
                    <rect x="2" y="24" width="52" height="2" fill="${p.wallD}"/>
                    <rect x="3" y="14" width="1.5" height="10" fill="${p.beam}"/>
                    <rect x="14" y="14" width="1.5" height="10" fill="${p.beam}"/>
                    <rect x="27" y="14" width="1.5" height="10" fill="${p.beam}"/>
                    <rect x="40" y="14" width="1.5" height="10" fill="${p.beam}"/>
                    <rect x="52.5" y="14" width="1.5" height="10" fill="${p.beam}"/>
                    ${stoneLonghouse}
                    <!-- main door -->
                    <rect x="24" y="17" width="5" height="9" fill="#3a2410"/>
                    <rect x="28" y="22" width="0.6" height="0.6" fill="#d4a017"/>
                    <!-- 3 windows -->
                    <rect x="6" y="16" width="4" height="4" fill="#5a4830"/>
                    <rect x="7" y="17" width="1" height="2" fill="#f0d890"/>
                    <rect x="9" y="17" width="1" height="2" fill="#f0d890"/>
                    <rect x="34" y="16" width="4" height="4" fill="#5a4830"/>
                    <rect x="35" y="17" width="1" height="2" fill="#f0d890"/>
                    <rect x="37" y="17" width="1" height="2" fill="#f0d890"/>
                    <rect x="44" y="16" width="4" height="4" fill="#5a4830"/>
                    <rect x="45" y="17" width="1" height="2" fill="#f0d890"/>
                    <rect x="47" y="17" width="1" height="2" fill="#f0d890"/>
                    <!-- hay-loft door at right end -->
                    <rect x="50" y="14" width="4" height="6" fill="#3a2410"/>
                    <rect x="50" y="14" width="4" height="1" fill="#5a3820"/>
                  </g>
                  <g class="hs-windows-lit">
                    <rect x="6" y="16" width="4" height="4" fill="#d4a017"/>
                    <rect x="34" y="16" width="4" height="4" fill="#d4a017"/>
                    <rect x="44" y="16" width="4" height="4" fill="#d4a017"/>
                  </g>
                  <g class="hs-roof" opacity="0">
                    <!-- low-pitched gable roof -->
                    <polygon points="0,12 28,4 56,12" fill="${p.roof}"/>
                    <polygon points="2,11 28,6 54,11" fill="${p.roofL}"/>
                    <rect x="0" y="11" width="56" height="2" fill="${p.roofD}"/>
                    <polygon points="6,9 28,5 50,9" fill="${p.roofD}" opacity="0.35"/>
                    <polygon points="10,8 28,5 46,8" fill="${p.roofD}" opacity="0.35"/>
                    <rect x="44" y="-2" width="3" height="8" fill="#3a2410"/>
                    <rect x="44" y="-2" width="3" height="2" fill="#5a3820"/>
                    <rect x="44" y="2" width="3" height="0.4" fill="#5a3820" opacity="0.6"/>
                  </g>

                  <g class="up-1">
                    <g class="chimney-smoke">
                      <circle cx="45.5" cy="-4" r="1.4" fill="#d8d4c8" opacity="0.8"/>
                      <circle cx="44" cy="-7" r="1.0" fill="#c8c4b8" opacity="0.7"/>
                    </g>
                    <!-- fence stretch along the long base -->
                    <rect x="-3" y="29" width="58" height="2" fill="#8a6840" opacity="0.6"/>
                    <rect x="0" y="27" width="1" height="4" fill="#5a3818"/>
                    <rect x="10" y="27" width="1" height="4" fill="#5a3818"/>
                    <rect x="20" y="27" width="1" height="4" fill="#5a3818"/>
                    <rect x="32" y="27" width="1" height="4" fill="#5a3818"/>
                    <rect x="42" y="27" width="1" height="4" fill="#5a3818"/>
                    <rect x="54" y="27" width="1" height="4" fill="#5a3818"/>
                  </g>

                  <g class="up-2">
                    <!-- planter boxes under each window -->
                    <rect x="5" y="20" width="6" height="2" fill="#6a4828"/>
                    <rect x="5" y="19" width="6" height="1" fill="#9a6838"/>
                    <rect x="6" y="18" width="1" height="1" fill="${flower}"/>
                    <rect x="8" y="18" width="1" height="1" fill="${flower2}"/>
                    <rect x="33" y="20" width="6" height="2" fill="#6a4828"/>
                    <rect x="33" y="19" width="6" height="1" fill="#9a6838"/>
                    <rect x="34" y="18" width="1" height="1" fill="#8040b0"/>
                    <rect x="36" y="18" width="1" height="1" fill="#e04060"/>
                    <rect x="43" y="20" width="6" height="2" fill="#6a4828"/>
                    <rect x="43" y="19" width="6" height="1" fill="#9a6838"/>
                    <rect x="44" y="18" width="1" height="1" fill="${accent}"/>
                    <rect x="46" y="18" width="1" height="1" fill="${flower2}"/>
                    <!-- awning over door -->
                    <rect x="22" y="16" width="9" height="1" fill="${p.roof}"/>
                    <rect x="22" y="16" width="9" height="0.5" fill="${p.roofL}"/>
                  </g>

                  <g class="up-3">
                    <!-- garden plot beside house -->
                    <rect x="-4" y="29" width="6" height="2" fill="#4a3018"/>
                    <rect x="-3" y="27" width="1" height="2" fill="#3a5a28"/>
                    <rect x="-1" y="27" width="1" height="2" fill="#3a5a28"/>
                    <rect x="0" y="26" width="1" height="1" fill="#e04060"/>
                    <!-- hanging laundry line -->
                    <line x1="14" y1="9" x2="40" y2="9" stroke="#3a2410" stroke-width="0.4"/>
                    <rect x="18" y="9" width="3" height="4" fill="#e0e4ec"/>
                    <rect x="24" y="9" width="3" height="4" fill="#4080d0"/>
                    <rect x="30" y="9" width="3" height="4" fill="#e04060"/>
                  </g>

                  <g class="up-4">
                    <!-- gold trim + climbing vine + signboard -->
                    <rect x="0" y="11" width="56" height="1" fill="${trim}"/>
                    <rect x="44" y="-2" width="3" height="1" fill="${trim}"/>
                    <!-- climbing vine on left side -->
                    <rect x="2" y="14" width="1" height="10" fill="#3a5a28"/>
                    <rect x="1" y="16" width="2" height="1" fill="#5a7a36"/>
                    <rect x="1" y="20" width="2" height="1" fill="#5a7a36"/>
                    <rect x="0" y="18" width="1" height="1" fill="${flower}"/>
                    <!-- hanging shop sign by door -->
                    <rect x="20" y="15" width="3" height="3" fill="${sign}"/>
                    <rect x="20" y="15" width="3" height="0.6" fill="#a8442a"/>
                    <rect x="21" y="16" width="1" height="1" fill="${trim}"/>
                  </g>
                </svg>`;
              }

              // default: cottage
              return `<svg viewBox="0 0 36 32" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="0" y="26" width="36" height="6" fill="#5a4030"/>
              <rect x="0" y="26" width="36" height="2" fill="#7a5840"/>
              <rect x="2" y="30" width="32" height="2" fill="#3a2818"/>
              <g class="hs-walls" opacity="0">
                <rect x="4" y="12" width="28" height="14" fill="${p.wall}"/>
                <rect x="4" y="12" width="28" height="2" fill="${p.wallL}"/>
                <rect x="4" y="24" width="28" height="2" fill="${p.wallD}"/>
                <rect x="6" y="14" width="2" height="10" fill="${p.beam}"/>
                <rect x="28" y="14" width="2" height="10" fill="${p.beam}"/>
                ${stoneCottage}
                <rect x="16" y="18" width="4" height="8" fill="#3a2410"/>
                <rect x="19" y="22" width="1" height="1" fill="#d4a017"/>
                <rect x="8" y="16" width="4" height="4" fill="#5a4830"/>
                <rect x="9" y="17" width="1" height="2" fill="#f0d890"/>
                <rect x="11" y="17" width="1" height="2" fill="#f0d890"/>
                <rect x="24" y="16" width="4" height="4" fill="#5a4830"/>
                <rect x="25" y="17" width="1" height="2" fill="#f0d890"/>
                <rect x="27" y="17" width="1" height="2" fill="#f0d890"/>
              </g>
              <g class="hs-windows-lit">
                <rect x="8" y="16" width="4" height="4" fill="#d4a017"/>
                <rect x="24" y="16" width="4" height="4" fill="#d4a017"/>
                <rect x="8" y="16" width="4" height="1" fill="#ffe080"/>
                <rect x="24" y="16" width="4" height="1" fill="#ffe080"/>
              </g>
              <g class="hs-roof" opacity="0">
                <polygon points="0,12 18,2 36,12" fill="${p.roof}"/>
                <polygon points="2,11 18,4 34,11" fill="${p.roofL}"/>
                <rect x="0" y="11" width="36" height="2" fill="${p.roofD}"/>
                <!-- tile rows for texture -->
                <polygon points="4,9 18,5 32,9" fill="${p.roofD}" opacity="0.4"/>
                <polygon points="6,7 18,3 30,7" fill="${p.roofD}" opacity="0.4"/>
                <rect x="22" y="-2" width="3" height="8" fill="#3a2410"/>
                <rect x="22" y="-2" width="3" height="2" fill="#5a3820"/>
                <!-- chimney brick lines -->
                <rect x="22" y="0" width="3" height="0.4" fill="#5a3820" opacity="0.6"/>
                <rect x="22" y="2" width="3" height="0.4" fill="#5a3820" opacity="0.6"/>
              </g>

              <!-- UPGRADE 1: chimney smoke + little garden + fence -->
              <g class="up-1">
                <g class="chimney-smoke">
                  <circle cx="23.5" cy="-4" r="1.4" fill="#d8d4c8" opacity="0.85"/>
                  <circle cx="22" cy="-7" r="1.0" fill="#c8c4b8" opacity="0.75"/>
                  <circle cx="24" cy="-10" r="0.7" fill="#b8b4a8" opacity="0.55"/>
                </g>
                <rect x="-4" y="29" width="6" height="3" fill="#8a6840"/>
                <rect x="0" y="27" width="1" height="5" fill="#5a3818"/>
                <rect x="34" y="29" width="6" height="3" fill="#8a6840"/>
                <rect x="35" y="27" width="1" height="5" fill="#5a3818"/>
                <rect x="3" y="29" width="3" height="3" fill="#3a5a28"/>
                <rect x="3" y="28" width="1" height="1" fill="#e04060"/>
                <rect x="5" y="28" width="1" height="1" fill="#f0c440"/>
              </g>

              <!-- UPGRADE 2: planter boxes under windows + door awning -->
              <g class="up-2">
                <rect x="7" y="20" width="6" height="2" fill="#6a4828"/>
                <rect x="7" y="19" width="6" height="1" fill="#9a6838"/>
                <rect x="8" y="18" width="1" height="1" fill="${flower}"/>
                <rect x="10" y="18" width="1" height="1" fill="${flower2}"/>
                <rect x="11" y="18" width="1" height="1" fill="#8040b0"/>
                <rect x="23" y="20" width="6" height="2" fill="#6a4828"/>
                <rect x="23" y="19" width="6" height="1" fill="#9a6838"/>
                <rect x="24" y="18" width="1" height="1" fill="${accent}"/>
                <rect x="26" y="18" width="1" height="1" fill="${flower}"/>
                <rect x="27" y="18" width="1" height="1" fill="${flower2}"/>
                <rect x="14" y="17" width="8" height="1" fill="${sign}"/>
                <rect x="14" y="17" width="8" height="0.5" fill="#a8442a"/>
              </g>

              <!-- UPGRADE 3: dormer window + garden plot -->
              <g class="up-3">
                <polygon points="12,8 18,2 24,8" fill="#6a2818"/>
                <polygon points="13,8 18,4 23,8" fill="#8a3a25"/>
                <rect x="14" y="8" width="8" height="4" fill="#a87858"/>
                <rect x="14" y="8" width="8" height="1" fill="#c89878"/>
                <rect x="15" y="9" width="2" height="3" fill="#5a4830"/>
                <rect x="15" y="9" width="1" height="3" fill="#f0d890"/>
                <rect x="19" y="9" width="2" height="3" fill="#5a4830"/>
                <rect x="19" y="9" width="1" height="3" fill="#f0d890"/>
                <!-- garden plot beside house -->
                <rect x="-5" y="28" width="6" height="2" fill="#4a3018"/>
                <rect x="-4" y="26" width="1" height="2" fill="#3a5a28"/>
                <rect x="-2" y="26" width="1" height="2" fill="#3a5a28"/>
                <rect x="0" y="26" width="1" height="2" fill="#3a5a28"/>
              </g>

              <!-- UPGRADE 4: gold roof trim + weathervane rooster + climbing vine -->
              <g class="up-4">
                <rect x="0" y="11" width="36" height="1" fill="${trim}"/>
                <rect x="22" y="-2" width="3" height="1" fill="${trim}"/>
                <rect x="22" y="-3" width="3" height="1" fill="${trimL}"/>
                <rect x="9" y="-3" width="1" height="6" fill="#3a2410"/>
                <rect x="6" y="-6" width="1" height="3" fill="#3a2410"/>
                <rect x="12" y="-6" width="1" height="3" fill="#3a2410"/>
                <rect x="7" y="-3" width="6" height="1" fill="#3a2410"/>
                <rect x="9" y="-7" width="2" height="1" fill="${trim}"/>
                <rect x="9" y="-8" width="1" height="1" fill="${trim}"/>
                <!-- climbing vine -->
                <rect x="32" y="16" width="1" height="10" fill="#3a5a28"/>
                <rect x="31" y="18" width="2" height="1" fill="#5a7a36"/>
                <rect x="31" y="22" width="2" height="1" fill="#5a7a36"/>
                <rect x="30" y="20" width="1" height="1" fill="#e04060"/>
              </g>
            </svg>`;
            }

            case "tower": return `<svg viewBox="0 0 32 64" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="2" y="58" width="28" height="6" fill="#5a4030"/>
              <rect x="2" y="58" width="28" height="2" fill="#7a5840"/>
              <!-- L1+ small bartizans: corbel-supported turrets attached partway up the main wall (not standing on the ground) -->
              <g class="up-1">
                <!-- LEFT bartizan, projecting outward from main wall edge at x=6 -->
                <rect x="0" y="36" width="6" height="1" fill="#80786a"/>
                <rect x="2" y="37" width="4" height="1" fill="#80786a"/>
                <rect x="4" y="38" width="2" height="1" fill="#80786a"/>
                <rect x="0" y="24" width="6" height="12" fill="#a8a098"/>
                <rect x="0" y="24" width="6" height="1" fill="#c8c0b0"/>
                <rect x="0" y="35" width="6" height="1" fill="#80786a"/>
                <rect x="2" y="28" width="2" height="4" fill="#1a1208"/>
                <rect x="0" y="22" width="2" height="2" fill="#80786a"/>
                <rect x="4" y="22" width="2" height="2" fill="#80786a"/>
                <polygon points="-1,22 3,16 7,22" fill="#8a3a25"/>
                <polygon points="0,22 3,18 6,22" fill="#a8442a"/>
                <!-- RIGHT bartizan (mirror), projecting from main wall edge at x=26 -->
                <rect x="26" y="36" width="6" height="1" fill="#80786a"/>
                <rect x="26" y="37" width="4" height="1" fill="#80786a"/>
                <rect x="26" y="38" width="2" height="1" fill="#80786a"/>
                <rect x="26" y="24" width="6" height="12" fill="#a8a098"/>
                <rect x="26" y="24" width="6" height="1" fill="#c8c0b0"/>
                <rect x="26" y="35" width="6" height="1" fill="#80786a"/>
                <rect x="28" y="28" width="2" height="4" fill="#1a1208"/>
                <rect x="26" y="22" width="2" height="2" fill="#80786a"/>
                <rect x="30" y="22" width="2" height="2" fill="#80786a"/>
                <polygon points="25,22 29,16 33,22" fill="#8a3a25"/>
                <polygon points="26,22 29,18 32,22" fill="#a8442a"/>
                <g class="hs-windows-lit">
                  <rect x="2" y="28" width="2" height="4" fill="#d4a017"/>
                  <rect x="28" y="28" width="2" height="4" fill="#d4a017"/>
                </g>
              </g>
              <!-- L3+ tall flanking turrets: bigger corbel-supported turrets attached lower, crowns rising above the main roof -->
              <g class="up-3">
                <!-- LEFT tall turret -->
                <rect x="-3" y="52" width="9" height="1" fill="#80786a"/>
                <rect x="-1" y="53" width="7" height="1" fill="#80786a"/>
                <rect x="1" y="54" width="5" height="1" fill="#80786a"/>
                <rect x="3" y="55" width="3" height="1" fill="#80786a"/>
                <rect x="-3" y="18" width="9" height="34" fill="#a8a098"/>
                <rect x="-3" y="18" width="9" height="1" fill="#c8c0b0"/>
                <rect x="-3" y="51" width="9" height="1" fill="#80786a"/>
                <rect x="-3" y="34" width="9" height="1" fill="#80786a"/>
                <rect x="0" y="26" width="2" height="4" fill="#1a1208"/>
                <rect x="0" y="40" width="2" height="4" fill="#1a1208"/>
                <rect x="-3" y="14" width="9" height="4" fill="#80786a"/>
                <polygon points="-4,14 1,2 6,14" fill="#8a3a25"/>
                <polygon points="-2,13 1,5 4,13" fill="#a8442a"/>
                <rect x="1" y="-4" width="1" height="6" fill="#5a3818"/>
                <rect x="2" y="-2" width="3" height="2" fill="#c84a35"/>
                <!-- RIGHT tall turret (mirror) -->
                <rect x="26" y="52" width="9" height="1" fill="#80786a"/>
                <rect x="26" y="53" width="7" height="1" fill="#80786a"/>
                <rect x="26" y="54" width="5" height="1" fill="#80786a"/>
                <rect x="26" y="55" width="3" height="1" fill="#80786a"/>
                <rect x="26" y="18" width="9" height="34" fill="#a8a098"/>
                <rect x="26" y="18" width="9" height="1" fill="#c8c0b0"/>
                <rect x="26" y="51" width="9" height="1" fill="#80786a"/>
                <rect x="26" y="34" width="9" height="1" fill="#80786a"/>
                <rect x="30" y="26" width="2" height="4" fill="#1a1208"/>
                <rect x="30" y="40" width="2" height="4" fill="#1a1208"/>
                <rect x="26" y="14" width="9" height="4" fill="#80786a"/>
                <polygon points="26,14 31,2 36,14" fill="#8a3a25"/>
                <polygon points="28,13 31,5 34,13" fill="#a8442a"/>
                <rect x="30" y="-4" width="1" height="6" fill="#5a3818"/>
                <rect x="31" y="-2" width="3" height="2" fill="#c84a35"/>
                <g class="hs-windows-lit">
                  <rect x="0" y="26" width="2" height="4" fill="#d4a017"/>
                  <rect x="0" y="40" width="2" height="4" fill="#d4a017"/>
                  <rect x="30" y="26" width="2" height="4" fill="#d4a017"/>
                  <rect x="30" y="40" width="2" height="4" fill="#d4a017"/>
                </g>
              </g>
              <g class="hs-walls" opacity="0">
                <rect x="6" y="16" width="20" height="42" fill="#a8a098"/>
                <rect x="6" y="16" width="20" height="2" fill="#c8c0b0"/>
                <rect x="6" y="56" width="20" height="2" fill="#80786a"/>
                ${stoneTexture(6, 18, 20, 38, "#5a544e", "#c8c0b0", "#80786a")}
                <rect x="6" y="16" width="2" height="40" fill="#80786a" opacity="0.45"/>
                <rect x="24" y="16" width="2" height="40" fill="#80786a" opacity="0.45"/>
                <rect x="7" y="18" width="2" height="2" fill="#c8c0b0" opacity="0.55"/>
                <rect x="23" y="25" width="2" height="2" fill="#5a544e" opacity="0.5"/>
                <rect x="7" y="39" width="2" height="2" fill="#5a544e" opacity="0.45"/>
                <rect x="9" y="26" width="2" height="6" fill="#1a1208"/>
                <rect x="21" y="26" width="2" height="6" fill="#1a1208"/>
                <rect x="15" y="38" width="2" height="8" fill="#1a1208"/>
                <rect x="14" y="48" width="4" height="10" fill="#3a2410"/>
              </g>
              <g class="hs-windows-lit">
                <rect x="9" y="26" width="2" height="6" fill="#d4a017"/>
                <rect x="21" y="26" width="2" height="6" fill="#d4a017"/>
                <rect x="15" y="38" width="2" height="8" fill="#d4a017"/>
              </g>
              <g class="hs-roof" opacity="0">
                <rect x="4" y="14" width="24" height="4" fill="#80786a"/>
                <rect x="4" y="10" width="3" height="4" fill="#80786a"/>
                <rect x="9" y="10" width="3" height="4" fill="#80786a"/>
                <rect x="14" y="10" width="4" height="4" fill="#80786a"/>
                <rect x="20" y="10" width="3" height="4" fill="#80786a"/>
                <rect x="25" y="10" width="3" height="4" fill="#80786a"/>
                <rect x="15" y="0" width="1" height="14" fill="#5a3818"/>
                <rect x="16" y="2" width="6" height="4" fill="#c84a35"/>
                <rect x="16" y="2" width="6" height="1" fill="#e06a45"/>
              </g>
            </svg>`;

            case "well": return `<svg viewBox="0 0 28 30" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="2" y="27" width="24" height="3" fill="#3a2818"/>
              <rect x="3" y="13" width="22" height="15" fill="#6f665d"/>
              <rect x="3" y="13" width="22" height="2" fill="#9a9088"/>
              <rect x="4" y="25" width="20" height="2" fill="#4a443e"/>
              <g class="hs-walls" opacity="0">
                <rect x="5" y="15" width="18" height="3" fill="#263f5f"/>
                <rect x="5" y="15" width="18" height="1" fill="#5a7fa0"/>
                ${stoneTexture(3, 18, 22, 9, "#4a443e", "#9a9088", "#6f665d")}
                <rect x="5" y="18" width="4" height="2" fill="#5a504a"/>
                <rect x="11" y="18" width="3" height="2" fill="#8a8580"/>
                <rect x="17" y="18" width="5" height="2" fill="#5a504a"/>
                <rect x="3" y="21" width="4" height="2" fill="#8a8580"/>
                <rect x="9" y="21" width="5" height="2" fill="#5a504a"/>
                <rect x="16" y="21" width="4" height="2" fill="#8a8580"/>
                <rect x="22" y="21" width="3" height="2" fill="#5a504a"/>
                <rect x="6" y="24" width="5" height="2" fill="#5a504a"/>
                <rect x="13" y="24" width="4" height="2" fill="#8a8580"/>
                <rect x="19" y="24" width="4" height="2" fill="#5a504a"/>
                <rect x="1" y="26" width="4" height="1" fill="#5a7a36"/>
                <rect x="23" y="26" width="3" height="1" fill="#5a7a36"/>
              </g>
              <g class="hs-roof" opacity="0">
                <rect x="3" y="4" width="2" height="11" fill="#4a2a14"/>
                <rect x="4" y="4" width="1" height="11" fill="#7a4828"/>
                <rect x="23" y="4" width="2" height="11" fill="#4a2a14"/>
                <rect x="23" y="4" width="1" height="11" fill="#7a4828"/>
                <polygon points="-1,5 14,-2 29,5" fill="#6a2818"/>
                <polygon points="1,4 14,0 27,4" fill="#a8442a"/>
                <rect x="0" y="5" width="28" height="2" fill="#3a1810"/>
                <rect x="5" y="2.5" width="18" height="0.7" fill="#c85838" opacity="0.65"/>
                <rect x="8" y="1" width="12" height="0.7" fill="#c85838" opacity="0.55"/>
                <rect x="8" y="8" width="12" height="2" fill="#4a2a14"/>
                <rect x="9" y="8" width="10" height="1" fill="#7a4828"/>
                <rect x="10" y="10" width="1" height="6" fill="#d4a888"/>
                <rect x="17" y="10" width="1" height="6" fill="#d4a888"/>
                <rect x="10" y="15" width="8" height="4" fill="#6a4828"/>
                <rect x="11" y="15" width="6" height="1" fill="#9a6838"/>
                <rect x="13" y="11" width="1" height="4" fill="#2a1a10"/>
                <rect x="12" y="14" width="4" height="3" fill="#5a504a"/>
                <rect x="12" y="14" width="4" height="1" fill="#8a8580"/>
                <rect x="18" y="7" width="5" height="1" fill="#d4a888"/>
                <rect x="22" y="6" width="1" height="3" fill="#d4a888"/>
              </g>
            </svg>`;

            case "signpost": return `<svg viewBox="0 0 22 32" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="9" y="7" width="3" height="25" fill="#4a2a14"/>
              <rect x="10" y="7" width="1" height="25" fill="#8a5a30"/>
              <rect x="7" y="29" width="7" height="3" fill="#3a2410"/>
              <g class="hs-walls" opacity="1">
                <polygon points="1,4 18,4 21,8 18,12 1,12" fill="#a87858"/>
                <rect x="1" y="4" width="17" height="1" fill="#c89878"/>
                <rect x="1" y="11" width="17" height="1" fill="#80583a"/>
                <rect x="4" y="6" width="4" height="1" fill="#3a2410"/>
                <rect x="9" y="6" width="5" height="1" fill="#3a2410"/>
                <rect x="15" y="6" width="2" height="1" fill="#3a2410"/>
                <rect x="4" y="8" width="3" height="1" fill="#3a2410"/>
                <rect x="9" y="8" width="2" height="1" fill="#3a2410"/>
                <rect x="12" y="8" width="4" height="1" fill="#3a2410"/>
                <rect x="4" y="10" width="11" height="1" fill="#5a3818" opacity="0.7"/>
                <rect x="10" y="5" width="2" height="2" fill="#d4a017"/>
                <rect x="18" y="8" width="1" height="1" fill="#3a2410"/>
                <rect x="8" y="14" width="6" height="5" fill="#7a4828"/>
                <rect x="8" y="14" width="6" height="1" fill="#b07848"/>
                <rect x="10" y="16" width="2" height="1" fill="#d4a017"/>
                <rect x="5" y="24" width="1" height="3" fill="#3a5a28"/>
                <rect x="4" y="25" width="3" height="1" fill="#5a7a36"/>
              </g>
            </svg>`;

            case "tavern": return tavernSVG(0);

            case "guildhall": return `<svg viewBox="0 0 62 64" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="2" y="56" width="58" height="8" fill="#3f3a34"/>
              <rect x="2" y="56" width="58" height="2" fill="#777068"/>
              <rect x="6" y="62" width="50" height="2" fill="#201d1a"/>
              <g class="hs-walls" opacity="0">
                <rect x="13" y="25" width="36" height="31" fill="#918b82"/>
                <rect x="13" y="25" width="36" height="2" fill="#c4beb2"/>
                <rect x="13" y="54" width="36" height="2" fill="#665f57"/>
                <rect x="13" y="34" width="36" height="1" fill="#6f685f" opacity="0.6"/>
                <rect x="13" y="44" width="36" height="1" fill="#6f685f" opacity="0.6"/>
                ${stoneTexture(13, 27, 36, 27, "#6f685f", "#c4beb2", "#817b74")}
                <rect x="13" y="25" width="3" height="29" fill="#706a62" opacity="0.58"/>
                <rect x="46" y="25" width="3" height="29" fill="#706a62" opacity="0.58"/>
                <rect x="14" y="27" width="2" height="2" fill="#c4beb2" opacity="0.55"/>
                <rect x="46" y="33" width="2" height="2" fill="#665f57" opacity="0.45"/>
                <rect x="14" y="47" width="2" height="2" fill="#665f57" opacity="0.45"/>
                <rect x="22" y="27" width="1" height="7" fill="#c4beb2" opacity="0.55"/>
                <rect x="36" y="35" width="1" height="9" fill="#6f685f" opacity="0.45"/>
                <rect x="20" y="46" width="1" height="8" fill="#6f685f" opacity="0.45"/>
                <rect x="27" y="45" width="8" height="11" fill="#2a211b"/>
                <rect x="28" y="45" width="6" height="3" fill="#18120e"/>
                <polygon points="27,45 31,40 35,45" fill="#5f574e"/>
                <rect x="26" y="43" width="10" height="2" fill="#c4beb2"/>
                <rect x="30" y="47" width="1" height="9" fill="#5c4938" opacity="0.8"/>
                <rect x="33" y="50" width="1" height="1" fill="#d4a017"/>
                <rect x="18" y="34" width="5" height="8" fill="#2a211b"/>
                <polygon points="18,34 20.5,30 23,34" fill="#2a211b"/>
                <rect x="39" y="34" width="5" height="8" fill="#2a211b"/>
                <polygon points="39,34 41.5,30 44,34" fill="#2a211b"/>
                <rect x="29" y="29" width="4" height="10" fill="#2a211b"/>
                <polygon points="29,29 31,25 33,29" fill="#2a211b"/>
                <rect x="30" y="30" width="2" height="8" fill="#71b8d6"/>
                <rect x="20" y="31" width="1" height="3" fill="#71b8d6"/>
                <rect x="41" y="31" width="1" height="3" fill="#71b8d6"/>
              </g>
              <g class="hs-roof" opacity="0">
                <polygon points="8,25 31,10 54,25" fill="#302c32"/>
                <polygon points="12,24 31,13 50,24" fill="#5b5360"/>
                <rect x="8" y="24" width="46" height="3" fill="#19171d"/>
                ${roofTileBands(0, 0, [[13,23,36],[18,20,26],[23,17,16]], "#19171d", 0.38)}
                <rect x="27" y="8" width="8" height="8" fill="#817b74"/>
                <rect x="27" y="8" width="8" height="2" fill="#b8b2aa"/>
                <rect x="28" y="13" width="6" height="1" fill="#665f57"/>
                <polygon points="25,8 31,0 37,8" fill="#302c32"/>
                <rect x="30" y="-6" width="2" height="6" fill="#d4a017"/>
                <rect x="27" y="-4" width="8" height="2" fill="#d4a017"/>
                <rect x="17" y="21" width="4" height="35" fill="#706a62" opacity="0.9"/>
                <rect x="41" y="21" width="4" height="35" fill="#706a62" opacity="0.9"/>
                <rect x="17" y="21" width="4" height="2" fill="#a8a098"/>
                <rect x="41" y="21" width="4" height="2" fill="#a8a098"/>
              </g>
              <g class="hs-windows-lit">
                <rect x="18" y="34" width="5" height="8" fill="#f0c440"/>
                <rect x="19" y="34" width="1" height="8" fill="#71b8d6" opacity="0.65"/>
                <rect x="21" y="34" width="1" height="8" fill="#c878d8" opacity="0.55"/>
                <rect x="39" y="34" width="5" height="8" fill="#f0c440"/>
                <rect x="40" y="34" width="1" height="8" fill="#71b8d6" opacity="0.65"/>
                <rect x="42" y="34" width="1" height="8" fill="#c878d8" opacity="0.55"/>
                <rect x="29" y="29" width="4" height="10" fill="#7bd0f0"/>
                <rect x="30" y="30" width="2" height="8" fill="#f0c440" opacity="0.75"/>
              </g>
              <g class="up-1">
                <rect x="7" y="39" width="10" height="17" fill="#817b74"/>
                <rect x="7" y="39" width="10" height="2" fill="#b8b2aa"/>
                ${stoneTexture(7, 41, 10, 14, "#665f57", "#b8b2aa", "#817b74")}
                <polygon points="5,39 12,31 19,39" fill="#302c32"/>
                <rect x="10" y="45" width="4" height="7" fill="#2a211b"/>
                <rect x="11" y="46" width="2" height="5" fill="#f0c440"/>
                <rect x="45" y="39" width="10" height="17" fill="#817b74"/>
                <rect x="45" y="39" width="10" height="2" fill="#b8b2aa"/>
                ${stoneTexture(45, 41, 10, 14, "#665f57", "#b8b2aa", "#817b74")}
                <polygon points="43,39 50,31 57,39" fill="#302c32"/>
                <rect x="48" y="45" width="4" height="7" fill="#2a211b"/>
                <rect x="49" y="46" width="2" height="5" fill="#f0c440"/>
                <rect x="9" y="56" width="5" height="2" fill="#6f685f"/>
                <rect x="48" y="56" width="5" height="2" fill="#6f685f"/>
              </g>
              <g class="up-2">
                <rect x="25" y="14" width="12" height="18" fill="#817b74"/>
                <rect x="25" y="14" width="12" height="2" fill="#b8b2aa"/>
                ${stoneTexture(25, 16, 12, 15, "#665f57", "#b8b2aa", "#817b74")}
                <rect x="25" y="30" width="12" height="2" fill="#665f57"/>
                <polygon points="23,14 31,3 39,14" fill="#302c32"/>
                ${roofTileBands(23, 3, [[3,9,10],[5,7,6]], "#19171d", 0.42)}
                <rect x="29" y="18" width="4" height="7" fill="#2a211b"/>
                <rect x="30" y="19" width="2" height="5" fill="#f0c440"/>
                <rect x="30" y="10" width="2" height="5" fill="#d4a017"/>
                <rect x="27" y="12" width="8" height="2" fill="#d4a017"/>
                <rect x="30" y="26" width="2" height="3" fill="#71b8d6"/>
              </g>
              <g class="up-3">
                <rect x="-3" y="47" width="12" height="9" fill="#817b74"/>
                <polygon points="-5,47 3,40 11,47" fill="#302c32"/>
                <rect x="53" y="47" width="12" height="9" fill="#817b74"/>
                <polygon points="51,47 59,40 67,47" fill="#302c32"/>
                <rect x="23" y="40" width="16" height="11" fill="#2a211b"/>
                <rect x="24" y="41" width="14" height="2" fill="#5c4938"/>
                <rect x="25" y="44" width="3" height="5" fill="#71b8d6"/>
                <rect x="30" y="43" width="3" height="6" fill="#f0c440"/>
                <rect x="35" y="44" width="3" height="5" fill="#c878d8"/>
                <rect x="29" y="40" width="1" height="11" fill="#d4a017" opacity="0.75"/>
                <rect x="34" y="40" width="1" height="11" fill="#d4a017" opacity="0.75"/>
                <rect x="24" y="46" width="14" height="1" fill="#d4a017" opacity="0.65"/>
              </g>
              <g class="up-4">
                <rect x="8" y="24" width="46" height="1" fill="#d4a017"/>
                <rect x="27" y="55" width="8" height="1" fill="#d4a017"/>
                <rect x="24" y="56" width="14" height="2" fill="#6f685f"/>
                <rect x="24" y="58" width="14" height="2" fill="#3f3a34"/>
                <rect x="21" y="60" width="20" height="2" fill="#6f685f"/>
                <rect x="18" y="62" width="26" height="2" fill="#3f3a34"/>
                <rect x="6" y="56" width="2" height="6" fill="#d4a017"/>
                <rect x="54" y="56" width="2" height="6" fill="#d4a017"/>
                <rect x="31" y="-10" width="1" height="4" fill="#d4a017"/>
                <rect x="28" y="-9" width="7" height="1" fill="#d4a017"/>
                <rect x="29" y="-12" width="5" height="1" fill="#d4a017"/>
              </g>
            </svg>`;

            case "mill": return `<svg viewBox="0 0 44 60" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="6" y="54" width="32" height="6" fill="#5a4030"/>
              <rect x="6" y="54" width="32" height="2" fill="#7a5840"/>
              <g class="hs-walls" opacity="0">
                <rect x="10" y="22" width="24" height="32" fill="#a87858"/>
                <rect x="10" y="22" width="24" height="2" fill="#c89878"/>
                <rect x="10" y="52" width="24" height="2" fill="#80583a"/>
                <rect x="18" y="42" width="8" height="12" fill="#3a2410"/>
                <rect x="22" y="48" width="1" height="1" fill="#d4a017"/>
                <rect x="13" y="30" width="4" height="4" fill="#5a4830"/>
                <rect x="27" y="30" width="4" height="4" fill="#5a4830"/>
              </g>
              <g class="hs-roof" opacity="0">
                <polygon points="6,22 38,22 22,8" fill="#6a2818"/>
                <polygon points="8,21 36,21 22,10" fill="#8a3a25"/>
                <rect x="20" y="10" width="4" height="4" fill="#3a2410"/>
                <g class="mill-blades">
                  <rect x="-10" y="11" width="64" height="3" fill="#8a6840"/>
                  <rect x="-10" y="11" width="64" height="1" fill="#a87838"/>
                  <rect x="20.5" y="-18" width="3" height="60" fill="#8a6840"/>
                  <rect x="20.5" y="-18" width="1" height="60" fill="#a87838"/>
                </g>
              </g>
              <g class="hs-windows-lit">
                <rect x="13" y="30" width="4" height="4" fill="#f0c440"/>
                <rect x="27" y="30" width="4" height="4" fill="#f0c440"/>
              </g>
              <g class="up-1">
                <rect x="4" y="52" width="8" height="2" fill="#6a4828"/>
                <rect x="5" y="49" width="6" height="3" fill="#c8a060"/>
                <rect x="5" y="49" width="6" height="1" fill="#e0c080"/>
                <rect x="32" y="50" width="8" height="4" fill="#7a5028"/>
                <rect x="33" y="49" width="6" height="1" fill="#9a6838"/>
                <rect x="34" y="51" width="1" height="3" fill="#5a3818"/>
                <rect x="38" y="51" width="1" height="3" fill="#5a3818"/>
              </g>
              <g class="up-2">
                <rect x="-2" y="40" width="12" height="14" fill="#8a6840"/>
                <rect x="-2" y="40" width="12" height="1.5" fill="#b08a58"/>
                <polygon points="-4,40 4,33 12,40" fill="#6a2818"/>
                <rect x="1" y="45" width="5" height="5" fill="#3a2410"/>
                <rect x="2" y="46" width="3" height="3" fill="#f0c440"/>
                <rect x="10" y="22" width="24" height="1" fill="#80583a"/>
                <rect x="13" y="38" width="18" height="1" fill="#80583a"/>
              </g>
              <g class="up-3">
                <rect x="34" y="30" width="6" height="20" fill="#5a3818"/>
                <rect x="35" y="31" width="4" height="18" fill="#7a4828"/>
                <rect x="33" y="33" width="8" height="2" fill="#3a2410"/>
                <rect x="33" y="39" width="8" height="2" fill="#3a2410"/>
                <rect x="33" y="45" width="8" height="2" fill="#3a2410"/>
                <rect x="6" y="54" width="32" height="1" fill="#d4a017"/>
                <rect x="21" y="-20" width="1" height="64" fill="#d4a017" opacity="0.75"/>
                <rect x="-12" y="12" width="68" height="1" fill="#d4a017" opacity="0.75"/>
              </g>
              <g class="up-4">
                <rect x="17" y="27" width="10" height="10" fill="#3a2410"/>
                <rect x="18" y="28" width="8" height="2" fill="#5a3820"/>
                <rect x="20" y="31" width="4" height="4" fill="#f0c440"/>
                <rect x="18" y="8" width="8" height="1" fill="#d4a017"/>
                <rect x="21" y="2" width="2" height="6" fill="#d4a017"/>
                <rect x="23" y="3" width="6" height="3" fill="#c84a35"/>
                <rect x="23" y="3" width="6" height="1" fill="#e06a45"/>
                <rect x="12" y="56" width="4" height="2" fill="#8a8580"/>
                <rect x="18" y="55" width="4" height="2" fill="#6a6258"/>
                <rect x="25" y="56" width="4" height="2" fill="#8a8580"/>
              </g>
            </svg>`;

            case "lamppost": return `<svg viewBox="0 0 18 38" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="4" y="32" width="10" height="4" fill="#1a1208"/>
              <rect x="2" y="35" width="14" height="3" fill="#1a1208"/>
              <rect x="5" y="31" width="8" height="1" fill="#5a544e"/>
              <rect x="7" y="10" width="3" height="23" fill="#2f302d"/>
              <rect x="8" y="10" width="1" height="23" fill="#6a645c"/>
              <rect x="7" y="16" width="3" height="1" fill="#1a1208"/>
              <rect x="7" y="24" width="3" height="1" fill="#1a1208"/>
              <rect x="4" y="8" width="10" height="2" fill="#2f302d"/>
              <rect x="3" y="9" width="2" height="2" fill="#5a544e"/>
              <rect x="13" y="9" width="2" height="2" fill="#5a544e"/>
              <rect x="3" y="2" width="12" height="8" fill="#2f302d"/>
              <rect x="3" y="2" width="12" height="2" fill="#6a645c"/>
              <rect x="4" y="4" width="10" height="5" fill="#15120f"/>
              <rect x="6" y="0" width="6" height="2" fill="#2f302d"/>
              <rect x="7" y="-2" width="4" height="2" fill="#6a645c"/>
              <rect x="5" y="4" width="1" height="5" fill="#6a645c"/>
              <rect x="9" y="4" width="1" height="5" fill="#6a645c"/>
              <rect x="13" y="4" width="1" height="5" fill="#6a645c"/>
              <path d="M 2 13 Q 7 16 8 20" stroke="#5a544e" stroke-width="0.8" fill="none"/>
              <path d="M 16 13 Q 11 16 10 20" stroke="#5a544e" stroke-width="0.8" fill="none"/>
              <g class="up-1">
                <rect x="1" y="35" width="16" height="1" fill="#8a8580"/>
                <rect x="2" y="36" width="4" height="1" fill="#6a6258"/>
                <rect x="8" y="36" width="4" height="1" fill="#8a8580"/>
                <rect x="14" y="36" width="2" height="1" fill="#6a6258"/>
                <rect x="6" y="30" width="6" height="1" fill="#8a8580"/>
              </g>
              <g class="up-2">
                <rect x="5" y="9" width="8" height="1" fill="#8a8580"/>
                <rect x="7" y="15" width="3" height="1" fill="#8a8580"/>
                <rect x="7" y="23" width="3" height="1" fill="#8a8580"/>
              </g>
              <g class="up-3">
                <rect x="6" y="-3" width="6" height="1" fill="#8a8580"/>
                <rect x="8" y="-5" width="2" height="2" fill="#5a544e"/>
                <rect x="8" y="10" width="1" height="20" fill="#8a8580" opacity="0.45"/>
              </g>
              <g class="up-4">
                <rect x="4" y="31" width="10" height="1" fill="#8a8580"/>
                <rect x="2" y="34" width="14" height="1" fill="#6a6258"/>
                <rect x="4" y="2" width="10" height="1" fill="#8a8580"/>
              </g>
              <g class="hs-windows-lit">
                <rect x="5" y="4" width="9" height="5" fill="#f0c440"/>
                <rect x="6" y="4" width="7" height="2" fill="#ffe080"/>
                <rect x="8" y="5" width="3" height="1" fill="#ffffff"/>
                <rect x="4" y="2" width="10" height="8" fill="#f0c440" opacity="0.18"/>
              </g>
            </svg>`;

            case "garden": return `<svg viewBox="0 0 32 18" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="1" y="12" width="30" height="6" fill="#4a3018"/>
              <rect x="1" y="12" width="30" height="1" fill="#7a5830"/>
              <rect x="3" y="15" width="26" height="1" fill="#3a2410" opacity="0.55"/>
              <rect x="0" y="9" width="32" height="1" fill="#8a6840"/>
              <rect x="1" y="8" width="2" height="5" fill="#6a4828"/>
              <rect x="7" y="8" width="2" height="5" fill="#6a4828"/>
              <rect x="14" y="8" width="2" height="5" fill="#6a4828"/>
              <rect x="22" y="8" width="2" height="5" fill="#6a4828"/>
              <rect x="29" y="8" width="2" height="5" fill="#6a4828"/>
              <rect x="3" y="7" width="1" height="6" fill="#3a5a28"/>
              <rect x="8" y="6" width="1" height="7" fill="#3a5a28"/>
              <rect x="13" y="7" width="1" height="6" fill="#3a5a28"/>
              <rect x="18" y="5" width="1" height="8" fill="#3a5a28"/>
              <rect x="24" y="6" width="1" height="7" fill="#3a5a28"/>
              <rect x="28" y="8" width="1" height="5" fill="#3a5a28"/>
              <rect x="2" y="5" width="3" height="3" fill="#e04060"/>
              <rect x="7" y="4" width="3" height="3" fill="#f0c440"/>
              <rect x="12" y="5" width="3" height="3" fill="#8040b0"/>
              <rect x="17" y="3" width="3" height="3" fill="#4080d0"/>
              <rect x="23" y="4" width="3" height="3" fill="#f08850"/>
              <rect x="27" y="6" width="3" height="3" fill="#d85858"/>
              <rect x="3" y="5" width="1" height="1" fill="#ff8090"/>
              <rect x="8" y="4" width="1" height="1" fill="#ffe080"/>
              <rect x="18" y="3" width="1" height="1" fill="#70b0f0"/>
              <rect x="5" y="10" width="3" height="1" fill="#5a7a36"/>
              <rect x="10" y="9" width="3" height="1" fill="#5a7a36"/>
              <rect x="16" y="10" width="3" height="1" fill="#5a7a36"/>
              <rect x="21" y="9" width="3" height="1" fill="#5a7a36"/>
              <rect x="25" y="14" width="3" height="2" fill="#5a504a"/>
              <rect x="26" y="13" width="2" height="1" fill="#8a8580"/>
            </svg>`;

            case "statue": return `<svg viewBox="0 0 22 38" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="2" y="31" width="18" height="7" fill="#5f574e"/>
              <rect x="2" y="31" width="18" height="2" fill="#8a8580"/>
              <rect x="0" y="36" width="22" height="2" fill="#3f3a34"/>
              <rect x="5" y="34" width="12" height="1" fill="#3f3a34"/>
              <rect x="8" y="32" width="6" height="2" fill="#d4a017"/>
              <rect x="9" y="32" width="4" height="1" fill="#f0c440"/>
              <g class="hs-walls" opacity="0">
                <rect x="7" y="15" width="8" height="16" fill="#a8a098"/>
                <rect x="7" y="15" width="8" height="2" fill="#c8c0b0"/>
                ${stoneTexture(7, 17, 8, 12, "#80786a", "#c8c0b0", "#918b82")}
                <rect x="5" y="17" width="2" height="10" fill="#918b82"/>
                <rect x="15" y="17" width="2" height="10" fill="#918b82"/>
                <rect x="8" y="21" width="6" height="1" fill="#80786a"/>
                <rect x="8" y="25" width="6" height="1" fill="#80786a"/>
                <rect x="6" y="27" width="10" height="4" fill="#80786a"/>
                <rect x="9" y="18" width="1" height="8" fill="#c8c0b0" opacity="0.55"/>
                <rect x="14" y="20" width="1" height="6" fill="#6a6258" opacity="0.55"/>
                <rect x="5" y="30" width="12" height="1" fill="#c8c0b0" opacity="0.35"/>
                <rect x="3" y="29" width="2" height="2" fill="#5a7a36" opacity="0.65"/>
                <rect x="16" y="29" width="2" height="2" fill="#5a7a36" opacity="0.55"/>
              </g>
              <g class="hs-roof" opacity="0">
                <rect x="8" y="8" width="6" height="7" fill="#a8a098"/>
                <rect x="8" y="8" width="6" height="2" fill="#c8c0b0"/>
                <rect x="7" y="4" width="8" height="4" fill="#d4a017"/>
                <rect x="7" y="4" width="8" height="1" fill="#f0c440"/>
                <rect x="8" y="2" width="2" height="2" fill="#d4a017"/>
                <rect x="11" y="0" width="2" height="2" fill="#d4a017"/>
                <rect x="13" y="2" width="2" height="2" fill="#d4a017"/>
                <rect x="17" y="0" width="1" height="16" fill="#dfe4ec"/>
                <rect x="17" y="0" width="0.5" height="16" fill="#ffffff"/>
                <rect x="16" y="16" width="4" height="1" fill="#6a4828"/>
                <polygon points="6,12 2,16 6,18" fill="#8a8580"/>
                <rect x="3" y="15" width="3" height="1" fill="#c8c0b0"/>
                <rect x="13" y="11" width="1" height="1" fill="#4a4438"/>
                <rect x="9" y="11" width="1" height="1" fill="#4a4438"/>
              </g>
            </svg>`;

            case "campfire": return `<svg viewBox="0 0 34 24" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="2" y="18" width="30" height="3" fill="#2a1a10"/>
              <rect x="3" y="20" width="4" height="3" fill="#6a6258"/>
              <rect x="9" y="21" width="4" height="2" fill="#8a8580"/>
              <rect x="16" y="21" width="4" height="2" fill="#6a6258"/>
              <rect x="23" y="21" width="4" height="2" fill="#8a8580"/>
              <rect x="29" y="20" width="3" height="3" fill="#6a6258"/>
              <rect x="6" y="15" width="10" height="3" fill="#6a4828"/>
              <rect x="7" y="15" width="8" height="1" fill="#9a6838"/>
              <rect x="18" y="15" width="10" height="3" fill="#5a3818"/>
              <rect x="19" y="15" width="8" height="1" fill="#8a6840"/>
              <rect x="11" y="14" width="12" height="3" fill="#7a5028"/>
              <rect x="12" y="14" width="10" height="1" fill="#a87838"/>
              <rect x="8" y="16" width="2" height="1" fill="#3a2410"/>
              <rect x="24" y="16" width="2" height="1" fill="#3a2410"/>
              <g class="hs-roof" opacity="0">
                <polygon points="10,15 16,2 22,15" fill="#d84818"/>
                <polygon points="14,15 21,4 27,15" fill="#f08850"/>
                <polygon points="12,14 17,5 22,14" fill="#f0c440"/>
                <polygon points="15,14 18,8 21,14" fill="#fff4a0"/>
                <rect x="16" y="0" width="1" height="3" fill="#fff4a0"/>
                <rect x="21" y="2" width="1" height="2" fill="#f0c440"/>
                <rect x="24" y="6" width="1" height="2" fill="#f08850"/>
                <rect x="13" y="3" width="1" height="2" fill="#f08850"/>
              </g>
            </svg>`;

            case "castle": return castleSVG(palette, 0);

            case "marketstall": return marketstallSVG(palette, 0);

            case "guardpost": return `<svg viewBox="0 0 24 50" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <!-- foundation -->
              <rect x="0" y="44" width="24" height="6" fill="#5a4030"/>
              <rect x="0" y="44" width="24" height="2" fill="#7a5840"/>
              <rect x="1" y="48" width="22" height="2" fill="#3a2818"/>
              <!-- stage 1: stone base -->
              <g class="hs-walls" opacity="0">
                <rect x="3" y="14" width="18" height="30" fill="#a8a098"/>
                <rect x="3" y="14" width="18" height="2" fill="#c8c0b0"/>
                <rect x="3" y="42" width="18" height="2" fill="#80786a"/>
                ${stoneTexture(3, 16, 18, 26, "#706a62", "#c8c0b0", "#9a9088")}
                <rect x="3" y="14" width="2" height="28" fill="#80786a" opacity="0.5"/>
                <rect x="19" y="14" width="2" height="28" fill="#80786a" opacity="0.5"/>
                <!-- block hints -->
                <rect x="6" y="20" width="3" height="1.5" fill="#80786a"/>
                <rect x="15" y="20" width="3" height="1.5" fill="#80786a"/>
                <rect x="9" y="26" width="3" height="1.5" fill="#9a9088"/>
                <rect x="6" y="32" width="3" height="1.5" fill="#80786a"/>
                <rect x="15" y="32" width="3" height="1.5" fill="#80786a"/>
                <rect x="5" y="40" width="4" height="2" fill="#5a7a36" opacity="0.7"/>
                <rect x="16" y="39" width="3" height="2" fill="#5a7a36" opacity="0.55"/>
                <!-- arrow slit + small window -->
                <rect x="11" y="22" width="1.5" height="6" fill="#1a1208"/>
                <rect x="10" y="34" width="4" height="6" fill="#1a1208"/>
                <!-- door at base -->
                <rect x="10" y="38" width="4" height="6" fill="#3a2410"/>
                <rect x="9" y="37" width="6" height="1" fill="#80786a"/>
              </g>
              <!-- stage 2: crenellations + watchman + bow + brazier -->
              <g class="hs-roof" opacity="0">
                <!-- battlements -->
                <rect x="1" y="10" width="22" height="4" fill="#80786a"/>
                <rect x="1" y="10" width="22" height="1" fill="#c8c0b0" opacity="0.45"/>
                <rect x="1" y="6" width="3" height="4" fill="#80786a"/>
                <rect x="6" y="6" width="3" height="4" fill="#80786a"/>
                <rect x="11" y="6" width="3" height="4" fill="#80786a"/>
                <rect x="16" y="6" width="3" height="4" fill="#80786a"/>
                <rect x="20" y="6" width="3" height="4" fill="#80786a"/>
                <rect x="2" y="6" width="1" height="3" fill="#c8c0b0" opacity="0.45"/>
                <rect x="17" y="6" width="1" height="3" fill="#c8c0b0" opacity="0.45"/>
                <!-- watchman body -->
                <rect x="10" y="0" width="4" height="6" fill="#3a3050"/>
                <rect x="9" y="2" width="6" height="2" fill="#3a3050"/>
                <!-- helmet -->
                <rect x="10" y="-3" width="4" height="3" fill="#8a8580"/>
                <rect x="10" y="-3" width="4" height="0.6" fill="#c8c0b0"/>
                <rect x="11" y="-4" width="2" height="1" fill="#c84a35"/>
                <!-- bow + drawn arrow -->
                <path d="M 7 1 Q 5 4 7 7" stroke="#5a3818" stroke-width="0.6" fill="none"/>
                <rect x="5" y="3" width="3" height="0.6" fill="#3a2410"/>
                <rect x="2" y="3" width="3" height="0.6" fill="#3a2410"/>
                <!-- pennant on side -->
                <rect x="20" y="-2" width="0.6" height="6" fill="#5a3818"/>
                <polygon points="20.6,-1 24,0 20.6,2" fill="#c84a35"/>
              </g>
              <!-- brazier glow + window lit -->
              <g class="hs-windows-lit">
                <rect x="10" y="34" width="4" height="6" fill="#d4a017"/>
                <rect x="11" y="22" width="1.5" height="6" fill="#d4a017"/>
                <!-- brazier (top, between crenellations) -->
                <rect x="2" y="6" width="2" height="3" fill="#f08850"/>
                <rect x="2" y="5" width="2" height="1" fill="#fff4a0"/>
                <rect x="20" y="6" width="2" height="3" fill="#f08850"/>
                <rect x="20" y="5" width="2" height="1" fill="#fff4a0"/>
              </g>
            </svg>`;

            case "blacksmith": return `<svg viewBox="0 0 46 44" xmlns="http://www.w3.org/2000/svg" overflow="visible">
              <rect x="0" y="42" width="46" height="2" fill="#3a2818"/>
              <rect x="0" y="40" width="46" height="2" fill="#5a4030"/>
              <g class="hs-walls" opacity="0">
                <rect x="2" y="24" width="32" height="16" fill="#a8a098"/>
                <rect x="2" y="24" width="32" height="1.5" fill="#c8c0b0"/>
                <rect x="2" y="38.5" width="32" height="1.5" fill="#80786a"/>
                ${stoneTexture(2, 25, 32, 14, "#706a62", "#c8c0b0", "#9a9088")}
                <rect x="4" y="28" width="4" height="1.5" fill="#80786a"/>
                <rect x="10" y="28" width="4" height="1.5" fill="#80786a"/>
                <rect x="16" y="28" width="4" height="1.5" fill="#80786a"/>
                <rect x="22" y="28" width="4" height="1.5" fill="#80786a"/>
                <rect x="28" y="28" width="4" height="1.5" fill="#80786a"/>
                <rect x="6" y="33" width="4" height="1.5" fill="#9a9088"/>
                <rect x="14" y="33" width="4" height="1.5" fill="#9a9088"/>
                <rect x="22" y="33" width="4" height="1.5" fill="#9a9088"/>
                <rect x="30" y="33" width="2" height="1.5" fill="#9a9088"/>
                <rect x="2" y="12" width="32" height="12" fill="#6a4828"/>
                <rect x="2" y="12" width="32" height="1" fill="#8a6840"/>
                <rect x="4" y="12" width="1.5" height="12" fill="#3a2410"/>
                <rect x="12" y="12" width="1.5" height="12" fill="#3a2410"/>
                <rect x="20" y="12" width="1.5" height="12" fill="#3a2410"/>
                <rect x="28" y="12" width="1.5" height="12" fill="#3a2410"/>
                <rect x="14" y="30" width="8" height="10" fill="#1a0e06"/>
                <rect x="14" y="29.5" width="8" height="1" fill="#3a2410"/>
                <rect x="13" y="29" width="10" height="1.5" fill="#5a3818"/>
                <rect x="6" y="36" width="6" height="2" fill="#3a3030"/>
                <rect x="7" y="34" width="4" height="2" fill="#5a544e"/>
                <rect x="7" y="34" width="4" height="0.5" fill="#8a8580"/>
                <rect x="8" y="33" width="2" height="1" fill="#5a544e"/>
                <rect x="5" y="31" width="1" height="6" fill="#3a3030"/>
                <rect x="4" y="31" width="3" height="1" fill="#8a8580"/>
                <rect x="9" y="31" width="2" height="1" fill="#8a8580"/>
                <rect x="10" y="30" width="1" height="3" fill="#3a3030"/>
                <rect x="26" y="36" width="3" height="1" fill="#5a544e"/>
                <rect x="26" y="34" width="3" height="1" fill="#5a544e"/>
                <rect x="26" y="38" width="3" height="1" fill="#3a3030"/>
                <rect x="30" y="35" width="1" height="4" fill="#3a3030"/>
                <rect x="29" y="35" width="3" height="1" fill="#8a8580"/>
              </g>
              <g class="hs-roof" opacity="0">
                <rect x="26" y="0" width="6" height="14" fill="#80786a"/>
                <rect x="26" y="0" width="6" height="1" fill="#a8a098"/>
                <rect x="25" y="0" width="8" height="1.5" fill="#5a544e"/>
                <rect x="27" y="3" width="4" height="0.8" fill="#5a544e"/>
                <rect x="27" y="7" width="4" height="0.8" fill="#5a544e"/>
                <rect x="27" y="-3" width="4" height="2" fill="#aaa6a0" opacity="0.6"/>
                <rect x="28" y="-6" width="3" height="2" fill="#bbb8b0" opacity="0.45"/>
                <rect x="29" y="-9" width="3" height="2" fill="#c8c4bc" opacity="0.3"/>
                <polygon points="0,12 36,12 32,4 4,4" fill="#3a3848"/>
                <polygon points="2,12 34,12 30,5 6,5" fill="#4a4858"/>
                <rect x="0" y="11" width="36" height="1.5" fill="#2a2838"/>
                ${roofTileBands(0, 4, [[5,6,26],[9,4,18],[14,2,8]], "#2a2838", 0.45)}
                <rect x="6" y="7" width="3" height="0.8" fill="#3a3848"/>
                <rect x="12" y="7" width="3" height="0.8" fill="#3a3848"/>
                <rect x="18" y="7" width="3" height="0.8" fill="#3a3848"/>
                <rect x="24" y="7" width="3" height="0.8" fill="#3a3848"/>
                <rect x="38" y="14" width="0.6" height="4" fill="#3a2410"/>
                <rect x="35" y="18" width="8" height="6" fill="#5a3818"/>
                <rect x="35" y="18" width="8" height="0.8" fill="#7a4828"/>
                <rect x="35" y="23.2" width="8" height="0.8" fill="#3a2410"/>
                <rect x="37" y="21" width="4" height="1" fill="#3a3030"/>
                <rect x="38" y="20" width="2" height="1" fill="#5a544e"/>
                <rect x="41" y="19.5" width="0.6" height="2.5" fill="#3a2410"/>
                <rect x="40.6" y="19" width="1.4" height="1" fill="#5a544e"/>
              </g>
              <g class="hs-windows-lit">
                <rect x="14" y="30" width="8" height="10" fill="#f08850"/>
                <rect x="14" y="30" width="8" height="2" fill="#fff4a0"/>
                <rect x="15" y="32" width="6" height="4" fill="#ff5020" opacity="0.6"/>
                <rect x="27" y="0" width="4" height="1" fill="#f08850" opacity="0.7"/>
              </g>
            </svg>`;
          }
          return "";
        }

        // No "campfire" — adventurer-camp only. Wide variety so the realm
        // grows into a proper medieval village.
        const BUILDER_KIND_WEIGHTS = [
          "house", "house", "house", "house", "house", "house",
          "tower", "tower", "tower",
          "castle", "castle",
          "well", "well",
          "signpost",
          "tavern", "tavern",
          "guildhall", "guildhall",
          "mill",
          "lamppost", "lamppost",
          "garden", "garden",
          "statue",
          "blacksmith", "blacksmith",
        ];
        function canRepeatStructureKind(kind) {
          return kind === "house" || kind === "tower" || kind === "marketstall";
        }
        function structureKindExists(kind) {
          if (kind === "castle") return hasCastleOrPendingBuild();
          return pendingStructureKindCount(kind) > 0
              || houses.some((h) => h.kind === kind && h.el.isConnected);
        }
        function canBuildStructureKind(kind) {
          return !!kind && (canRepeatStructureKind(kind) || !structureKindExists(kind));
        }
        function pickBuilderKind() {
          const missing = BUILDER_KIND_WEIGHTS.filter((kind) => !structureKindExists(kind) && canBuildStructureKind(kind));
          if (missing.length > 0) return pick(missing);
          const repeatable = BUILDER_KIND_WEIGHTS.filter((kind) => kind === "house" || kind === "tower");
          return repeatable.length > 0 ? pick(repeatable) : null;
        }

        function spawnBuilder(targetX, kind, onDone, fastStarter = false) {
          if (reduced) { if (onDone) onDone(); return true; }
          // Pick a kind if not provided. Houses & towers more common than wells/signs/campfires.
          if (!kind) kind = pickBuilderKind();
          if (!canBuildStructureKind(kind)) return false;
          const reservedCastleBuild = kind === "castle";
          if (reservedCastleBuild && !reserveCastleBuild()) return false;
          const reservedPendingKind = !reservedCastleBuild && reservePendingStructureKind(kind);
          const palette = kind === "house"
            ? { ...pick(HOUSE_PALETTES), variant: pick(HOUSE_VARIANTS) }
            : kind === "marketstall"
              ? pick(MARKET_PALETTES)
            : null;
          // Sole castle is always built dead-center
          if (kind === "castle") targetX = W() / 2;
          if (kind === "castle") {
            makeRoomForMainCastle(0);
          } else if (!structureSpotIsFree(targetX, kind, palette, 0)) {
            const openX = findOpenSpot(kind, palette, 0);
            if (openX == null) {
              if (reservedCastleBuild) clearCastleBuildReservation();
              if (reservedPendingKind) clearPendingStructureKind(kind);
              return false;
            }
            targetX = openX;
          }
          const lj = makePerson("builder", targetX > W() / 2 ? "right" : "left", { bottom: 40 });
          const fromLeft = targetX > W() / 2;
          const startX = fromLeft ? -20 : W() + 20;
          const stopX = targetX + (fromLeft ? -8 : 42);
          lj.style.left = startX + "px";
          const walkDist = Math.abs(stopX - startX);
          const walkTime = fastStarter ? Math.min(walkDist / 260, 2.2) : walkDist / 50;
          requestAnimationFrame(() => {
            lj.style.transition = `left ${walkTime}s linear`;
            lj.style.left = stopX + "px";
          });

          setTimeout(() => {
            lj.classList.add("working");
            // emit dust puffs every ~250ms while building
            const dustTimer = setInterval(() => {
              spawnParticle(targetX + (Math.random() - 0.5) * 12, 48 + Math.random() * 16, "dust");
            }, 240);
            const breakground = {
              house: "A builder breaks ground for a house.",
              tower: "A builder begins a watchtower.",
              well: "A builder digs a well.",
              signpost: "A builder plants a signpost.",
              lamppost: "A builder sets a street-light base beside the road.",
              campfire: "A traveler arranges logs for a fire.",
              blacksmith: "A builder lays the foundation for a forge.",
            };
            logEvent(breakground[kind] || "A builder breaks ground.", "good");

            const h = document.createElement("div");
            h.className = "house";
            h.dataset.kind = kind;
            if (palette && palette.variant) h.dataset.variant = palette.variant;
            h.innerHTML = structureSVG(kind, palette);
            h.style.left = targetX + "px";
            treesLayer.appendChild(h);
            const rec = { el: h, x: targetX, kind, stage: 0, upgrade: 0, palette };
            h.dataset.upgrade = "0";
            setStructureStage(rec, 0);
            applyLane(rec, pickLane(targetX, kind, palette, 0));
            houses.push(rec);
            if (reservedPendingKind) clearPendingStructureKind(kind);
            if (reservedCastleBuild) clearCastleBuildReservation();

            const midDelay = kind === "signpost" || kind === "lamppost" || kind === "garden" ? 0
                           : kind === "campfire" ? 2500
                           : kind === "well" ? 3500
                           : kind === "castle" ? 7000
                           : kind === "tavern" || kind === "guildhall" ? 4500
                           : kind === "mill" ? 4000
                           : kind === "statue" ? 3500
                           : kind === "blacksmith" ? 4000
                           : 3500;
            const doneDelay = kind === "signpost" ? 2000
                            : kind === "lamppost" ? 2200
                            : kind === "garden" ? 1800
                            : kind === "campfire" ? 4000
                            : kind === "well" ? 5500
                            : kind === "tower" ? 9000
                            : kind === "castle" ? 14000
                            : kind === "tavern" || kind === "guildhall" ? 10000
                            : kind === "mill" ? 8000
                            : kind === "statue" ? 6500
                            : kind === "blacksmith" ? 8500
                            : 8000;
            const log = STRUCTURE_BUILD_LOG[kind] || STRUCTURE_BUILD_LOG.house;

            if (midDelay > 0) {
              setTimeout(() => {
                if (!h.isConnected) return;
                setStructureStage(rec, 1);
                h.querySelectorAll(".hs-walls").forEach((el) => el.setAttribute("opacity", 1));
                if (log.mid) logEvent(log.mid);
              }, fastStarter ? Math.min(midDelay, 1300) : midDelay);
            }
            setTimeout(() => {
              if (!h.isConnected) return;
              setStructureStage(rec, 2);
              h.querySelectorAll(".hs-walls").forEach((el) => el.setAttribute("opacity", 1));
              h.querySelectorAll(".hs-roof").forEach((el) => el.setAttribute("opacity", 1));
              logEvent(log.done, "good");
              lj.classList.remove("working");
              clearInterval(dustTimer);
              // Signpost gets a destination label
              if (kind === "signpost") {
                const labels = ["Tavern →", "Mill →", "Old Mines →", "King's Road", "Market →", "Bridge →", "Forge →", "Sanctum →"];
                const txt = labels[Math.floor(Math.random() * labels.length)];
                const lbl = document.createElement("div");
                lbl.className = "sign-label";
                lbl.textContent = txt;
                lbl.style.left = (targetX + 11) + "px";
                treesLayer.appendChild(lbl);
                logEvent(`"${txt}" reads the new sign.`);
              }
              if (kind === "lamppost") {
                setStreetLightUpgrade(rec, streetLightUpgradeForRoad(parseInt(world.dataset.road || "0", 10)), true);
              }
              const exitX = fromLeft ? W() + 20 : -20;
              const exitDur = Math.abs(exitX - stopX) / (fastStarter ? 200 : 50);
              lj.style.transition = `left ${exitDur}s linear`;
              lj.style.left = exitX + "px";
              setTimeout(() => lj.remove(), exitDur * 1000 + 500);
              if (onDone) onDone(rec);
              scheduleAmbientRefresh(140);
            }, fastStarter ? Math.min(doneDelay, 3200) : doneDelay);
          }, walkTime * 1000 + 100);
          return true;
        }

        function destroyHouse(rec) {
          // Buildings are protected — no destruction in this realm
          return;
        }

        /* ============= LUMBERJACK ============= */
        function spawnLumberjack() {
          if (document.hidden || reduced) return;
          const grown = trees.filter((t) => t.stage >= 3);
          if (grown.length === 0) return;
          const target = grown[Math.floor(Math.random() * grown.length)];
          const tx = target.x;
          const fromLeft = tx > W() / 2;
          const startX = fromLeft ? -20 : W() + 20;
          const stopX = tx + (fromLeft ? 2 : 8);
          const lj = makePerson("lumberjack", fromLeft ? "right" : "left", { bottom: 40 });
          lj.style.left = startX + "px";
          const walkDist = Math.abs(stopX - startX);
          const walkTime = walkDist / 50;
          logEvent("A lumberjack spies a fine tree.");
          requestAnimationFrame(() => {
            lj.style.transition = `left ${walkTime}s linear`;
            lj.style.left = stopX + "px";
          });
          setTimeout(() => {
            if (!target.el.isConnected) {
              const exitX = fromLeft ? W() + 20 : -20;
              lj.style.transition = `left 6s linear`;
              lj.style.left = exitX + "px";
              setTimeout(() => lj.remove(), 6500);
              return;
            }
            lj.classList.add("chopping");
            // emit wood chips every ~200ms during the chop
            const chipTimer = setInterval(() => {
              spawnParticle(tx + (Math.random() - 0.5) * 6, 48 + Math.random() * 8, "chip");
            }, 180);
            setTimeout(() => {
              clearInterval(chipTimer);
              target.el.classList.add("falling");
              removeTree(target);
              setTimeout(() => target.el.remove(), 1500);
              lj.classList.remove("chopping");
              logEvent("A lumberjack felled a tree.", "good");
              const exitX = fromLeft ? W() + 20 : -20;
              const exitDist = Math.abs(exitX - stopX);
              const exitTime = exitDist / 50;
              lj.style.transition = `left ${exitTime}s linear`;
              lj.style.left = exitX + "px";
              setTimeout(() => lj.remove(), exitTime * 1000 + 500);
              // Builder arrives after lumberjack leaves
              setTimeout(() => spawnBuilder(target.x), 5000);
            }, 3500);
          }, walkTime * 1000 + 100);
        }

        /* ============= DRAGON SVG ============= */
        const DRAGON_PALETTES = [
          { name: "ember",   body: "#7a2818", bodyL: "#a83828", bodyD: "#3a1010", eye: "#f0c440", horn: "#1a0808", belly: "#c84a35" },
          { name: "forest",  body: "#2a5a30", bodyL: "#3a7a40", bodyD: "#142818", eye: "#ffc080", horn: "#1a0a06", belly: "#4a8a50" },
          { name: "shadow",  body: "#2a2238", bodyL: "#4a3858", bodyD: "#0a0814", eye: "#c84a35", horn: "#0a0814", belly: "#4a4060" },
          { name: "ice",     body: "#3a6878", bodyL: "#5a8a9a", bodyD: "#1a2a36", eye: "#fff080", horn: "#0a1218", belly: "#7aa0b0" },
        ];

        function dragonSVG(p) {
          // viewBox 56 x 26, facing right
          return `<svg viewBox="0 0 56 26" xmlns="http://www.w3.org/2000/svg">
            <!-- tail (segmented) -->
            <rect x="2" y="13" width="3" height="2" fill="${p.body}"/>
            <rect x="5" y="12" width="4" height="3" fill="${p.body}"/>
            <rect x="5" y="12" width="4" height="1" fill="${p.bodyL}"/>
            <rect x="0" y="13" width="2" height="1" fill="${p.bodyD}"/>
            <!-- spike on tail tip -->
            <rect x="0" y="11" width="2" height="2" fill="${p.bodyD}"/>

            <!-- main body -->
            <rect x="9" y="10" width="20" height="6" fill="${p.body}"/>
            <rect x="9" y="10" width="20" height="1" fill="${p.bodyL}"/>
            <rect x="11" y="15" width="16" height="1" fill="${p.bodyD}"/>
            <!-- belly stripe -->
            <rect x="13" y="14" width="12" height="2" fill="${p.belly}" opacity="0.7"/>

            <!-- back spikes -->
            <rect x="11" y="8" width="2" height="2" fill="${p.bodyD}"/>
            <rect x="15" y="7" width="2" height="3" fill="${p.bodyD}"/>
            <rect x="19" y="7" width="2" height="3" fill="${p.bodyD}"/>
            <rect x="23" y="8" width="2" height="2" fill="${p.bodyD}"/>

            <!-- legs -->
            <rect x="12" y="16" width="3" height="4" fill="${p.body}"/>
            <rect x="12" y="19" width="3" height="1" fill="${p.bodyD}"/>
            <rect x="22" y="16" width="3" height="4" fill="${p.body}"/>
            <rect x="22" y="19" width="3" height="1" fill="${p.bodyD}"/>

            <!-- neck -->
            <rect x="29" y="9" width="4" height="4" fill="${p.body}"/>
            <rect x="29" y="9" width="4" height="1" fill="${p.bodyL}"/>
            <!-- head -->
            <rect x="33" y="7" width="8" height="6" fill="${p.body}"/>
            <rect x="33" y="7" width="8" height="1" fill="${p.bodyL}"/>
            <rect x="41" y="9" width="2" height="3" fill="${p.body}"/>
            <!-- jaw -->
            <rect x="36" y="12" width="6" height="2" fill="${p.bodyD}"/>
            <rect x="40" y="11" width="1" height="1" fill="#fff"/>
            <rect x="42" y="11" width="1" height="1" fill="#fff"/>
            <!-- eye -->
            <rect x="36" y="9" width="2" height="2" fill="${p.eye}"/>
            <rect x="37" y="10" width="1" height="1" fill="#000"/>
            <!-- horns -->
            <rect x="35" y="5" width="1" height="2" fill="${p.horn}"/>
            <rect x="34" y="3" width="1" height="2" fill="${p.horn}"/>
            <rect x="39" y="5" width="1" height="2" fill="${p.horn}"/>
            <rect x="38" y="3" width="1" height="2" fill="${p.horn}"/>

            <!-- wings: upper -->
            <g class="dr-wing-up">
              <polygon points="13,9 24,9 28,-2 23,4 18,-2 14,4" fill="${p.bodyD}"/>
              <polygon points="15,9 24,9 26,1 22,5 18,1 16,5" fill="${p.body}"/>
            </g>
            <!-- wings: lower (further back) -->
            <g class="dr-wing-dn">
              <polygon points="14,12 22,12 24,22 20,16 17,22 14,16" fill="${p.bodyD}" opacity="0.5"/>
            </g>
          </svg>`;
        }

        function makeDragon(palette) {
          const d = document.createElement("div");
          d.className = "dragon";
          d.innerHTML = dragonSVG(palette || pick(DRAGON_PALETTES));
          return d;
        }

        /* ============= DRAGON MILESTONES ============= */
        // Dragons are hard-gated — the village must reach economic + defensive
        // maturity before any threat appears.
        let firstSmallDragonAnnounced = false;
        let firstHugeDragonAnnounced  = false;
        const activeDragons = []; // {el, hp, isHuge}

        function countCompleted(kind) {
          return houses.filter((h) => h.kind === kind && h.stage >= 2).length;
        }
        function smallDragonReady() {
          const tier = parseInt(world.dataset.road || "0", 10);
          return tier >= 3
            && countCompleted("castle") >= 1
            && countCompleted("marketstall") >= 4
            && countCompleted("guardpost") >= 1;
        }
        function hugeDragonReady() {
          const tier = parseInt(world.dataset.road || "0", 10);
          return tier >= 5
            && houses.some((h) => h.kind === "castle" && (h.upgrade || 0) >= CASTLE_HUGE_DRAGON_TARGET_LEVEL)
            && countCompleted("marketstall") >= 6
            && countCompleted("guardpost") >= 1;
        }
        function registerDragon(el, isHuge) {
          const rec = { el, hp: isHuge ? 14 : 4, isHuge };
          activeDragons.push(rec);
          el.__dragonRec = rec;
          // Kick off the arrow-volley loop if a guard post can shoot
          if (typeof startVolleyLoopIfNeeded === "function") startVolleyLoopIfNeeded();
          return rec;
        }
        function unregisterDragon(el) {
          const i = activeDragons.findIndex((r) => r.el === el);
          if (i >= 0) activeDragons.splice(i, 1);
        }

        /* ============= DRAGON FLY-BY ============= */
        function spawnDragon() {
          if (document.hidden || reduced) return;
          if (!smallDragonReady()) return; // hard gate
          if (!firstSmallDragonAnnounced) {
            firstSmallDragonAnnounced = true;
            logEvent("A dark shadow falls over the realm — dragons return.", "bad");
          }
          const d = makeDragon();
          d.classList.add("flyby");
          const dur = 14 + Math.random() * 10;
          d.style.animationDuration = dur + "s";
          d.style.top = (40 + Math.random() * (H() * 0.3)) + "px";
          dragonsLayer.appendChild(d);
          const rec = registerDragon(d, false);
          // Keyframe-driven; just clean up after the animation
          setTimeout(() => {
            unregisterDragon(d);
            d.remove();
          }, dur * 1000 + 500);
          // If guard posts shoot it down, end the flyby early
          rec.onDefeat = () => {
            d.style.animation = "none";
            d.style.transition = "left 2.2s ease-out, top 2.2s ease-out, opacity 2.2s ease";
            d.style.top = "20px";
            d.style.left = (W() + 80) + "px";
            d.style.opacity = "0.4";
            logEvent("Arrows drive the dragon back!", "good");
          };
        }

        /* ============= DRAGON ATTACK ============= */
        function dragonAttack(target) {
          if (!target || !target.el.isConnected || reduced) return;
          if (target.kind === "castle" && (target.upgrade || 0) >= CASTLE_NORMAL_ATTACK_IMMUNE_LEVEL) {
            logEvent("A dragon swoops in but recoils — the great castle is too well-fortified!");
            return;
          }
          if (!smallDragonReady()) return; // hard gate
          if (!firstSmallDragonAnnounced) {
            firstSmallDragonAnnounced = true;
            logEvent("A dark shadow falls over the realm — dragons return.", "bad");
          }
          const d = makeDragon(DRAGON_PALETTES[0]); // ember dragon for attacks
          d.style.top = "60px";
          d.style.left = "-60px";
          dragonsLayer.appendChild(d);
          const rec = registerDragon(d, false);
          logEvent("A dragon descends upon a house!", "bad");

          // Approach
          requestAnimationFrame(() => {
            d.style.transition = "left 4.5s linear, top 4.5s ease-in";
            d.style.left = (target.x - 8) + "px";
            d.style.top = (H() - 130) + "px";
          });

          // Fire breath
          const burnTimeout = setTimeout(() => {
            if (rec.defeated) return;
            for (let i = 0; i < 4; i++) {
              setTimeout(() => {
                const f = document.createElement("div");
                f.className = "fire-breath";
                f.style.left = (target.x + 16 + (Math.random() * 12 - 6)) + "px";
                f.style.bottom = (60 + Math.random() * 14) + "px";
                dragonsLayer.appendChild(f);
                setTimeout(() => f.remove(), 1500);
              }, i * 180);
            }
            destroyHouse(target);
            logEvent("The house is burned to ash!", "bad");
          }, 4700);

          // Fly away
          const flyOff = setTimeout(() => {
            d.style.transition = "left 4.5s linear, top 4.5s ease-out";
            d.style.left = (W() + 60) + "px";
            d.style.top = "40px";
          }, 6200);

          const cleanup = setTimeout(() => {
            unregisterDragon(d);
            d.remove();
          }, 11000);

          rec.onDefeat = () => {
            clearTimeout(burnTimeout);
            clearTimeout(flyOff);
            clearTimeout(cleanup);
            d.style.transition = "left 2.2s ease-out, top 2.2s ease-out, opacity 2.2s ease";
            d.style.left = (W() + 80) + "px";
            d.style.top = "30px";
            d.style.opacity = "0.4";
            logEvent("Arrows drive the dragon back!", "good");
            setTimeout(() => { unregisterDragon(d); d.remove(); }, 2400);
          };
        }

        /* ============= HORSEMAN ATTACK ============= */
        function horsemanSVG() {
          return `<svg viewBox="0 0 28 26" xmlns="http://www.w3.org/2000/svg">
            <!-- horse body -->
            <rect x="2" y="14" width="20" height="6" fill="#3a2418"/>
            <rect x="2" y="14" width="20" height="2" fill="#5a3a28"/>
            <!-- horse head -->
            <rect x="20" y="11" width="6" height="5" fill="#3a2418"/>
            <rect x="20" y="11" width="6" height="1" fill="#5a3a28"/>
            <rect x="25" y="13" width="1" height="2" fill="#1a1208"/>
            <!-- horse mane -->
            <rect x="17" y="10" width="4" height="3" fill="#1a1208"/>
            <!-- horse legs -->
            <rect x="4" y="20" width="2" height="6" fill="#1a1208"/>
            <rect x="9" y="20" width="2" height="6" fill="#1a1208"/>
            <rect x="14" y="20" width="2" height="6" fill="#1a1208"/>
            <rect x="19" y="20" width="2" height="6" fill="#1a1208"/>
            <!-- tail -->
            <rect x="0" y="13" width="2" height="6" fill="#1a1208"/>
            <!-- rider armor -->
            <rect x="8" y="6" width="8" height="9" fill="#8890a0"/>
            <rect x="8" y="6" width="8" height="2" fill="#b8c0d0"/>
            <rect x="8" y="13" width="8" height="2" fill="#555a68"/>
            <!-- helmet -->
            <rect x="9" y="1" width="6" height="6" fill="#8890a0"/>
            <rect x="9" y="1" width="6" height="2" fill="#b8c0d0"/>
            <rect x="9" y="4" width="6" height="1" fill="#222"/>
            <!-- plume -->
            <rect x="11" y="-2" width="2" height="3" fill="#c84a35"/>
            <!-- sword -->
            <g class="hr-sword">
              <rect x="16" y="3" width="1" height="9" fill="#e0e4ec"/>
              <rect x="15" y="11" width="3" height="1" fill="#888"/>
              <rect x="16" y="12" width="1" height="2" fill="#6a4828"/>
            </g>
            <!-- shield -->
            <rect x="6" y="9" width="3" height="5" fill="#c84a35"/>
            <rect x="6" y="9" width="3" height="1" fill="#e06a45"/>
            <rect x="7" y="11" width="1" height="1" fill="#d4a017"/>
          </svg>`;
        }

        function horsemanAttack(target) {
          if (!target || !target.el.isConnected || reduced) return;
          if (target.kind === "castle" && (target.upgrade || 0) >= CASTLE_NORMAL_ATTACK_IMMUNE_LEVEL) {
            logEvent("A horseman charges the castle but turns away — its walls are too strong!");
            return;
          }
          const h = document.createElement("div");
          h.className = "horseman";
          h.innerHTML = horsemanSVG();
          const fromLeft = Math.random() > 0.5;
          const startX = fromLeft ? -40 : W() + 40;
          const stopX = target.x + (fromLeft ? -16 : 28);
          if (!fromLeft) h.style.transform = "scaleX(-1)";
          h.style.left = startX + "px";
          peopleLayer.appendChild(h);

          const dur = Math.abs(stopX - startX) / 160; // gallop speed
          logEvent("An armored horseman charges in!", "bad");
          requestAnimationFrame(() => {
            h.style.transition = `left ${dur}s linear`;
            h.style.left = stopX + "px";
          });
          setTimeout(() => {
            h.classList.add("attacking");
            setTimeout(() => {
              destroyHouse(target);
              logEvent("The horseman smashes the house!", "bad");
              h.classList.remove("attacking");
              const exitX = fromLeft ? W() + 40 : -40;
              const exitDur = Math.abs(exitX - stopX) / 160;
              h.style.transition = `left ${exitDur}s linear`;
              h.style.left = exitX + "px";
              setTimeout(() => h.remove(), exitDur * 1000 + 400);
            }, 2200);
          }, dur * 1000 + 100);
        }

        function attackRandomHouse() {
          // Only attack worthwhile buildings - houses & towers; fortified castles repel normal attacks.
          const attackable = houses.filter((h) =>
            h.stage >= 2
            && (h.kind === "house" || h.kind === "tower" || (h.kind === "castle" && (h.upgrade || 0) < CASTLE_NORMAL_ATTACK_IMMUNE_LEVEL))
          );
          if (attackable.length === 0) return;
          const target = attackable[Math.floor(Math.random() * attackable.length)];
          // Dragon raids only appear once the small-dragon milestone is met
          const tryDragon = smallDragonReady() && Math.random() < 0.5;
          (tryDragon ? dragonAttack : horsemanAttack)(target);
        }

        // Find a free grass spot using real structure footprints, not just anchor points.
        function findOpenSpot(kind = null, palette = null, upgrade = 0, opts = {}) {
          const sideMargin = opts.margin ?? Math.max(42, Math.min(100, W() * 0.1));
          const preferredSide = opts.preferredSide ?? preferredOpenSide(kind);
          const usableWidth = Math.max(1, W() - sideMargin * 2);
          let bestX = null;
          let bestScore = -Infinity;

          for (let i = 0; i < 140; i++) {
            let minX = sideMargin;
            let maxX = W() - sideMargin;
            if (preferredSide && i < 90) {
              if (preferredSide === "left") maxX = Math.min(maxX, W() / 2 - 24);
              else minX = Math.max(minX, W() / 2 + 24);
            }
            if (maxX <= minX) {
              minX = sideMargin;
              maxX = sideMargin + usableWidth;
            }
            const x = minX + Math.random() * Math.max(1, maxX - minX);
            if (!structureSpotIsFree(x, kind, palette, upgrade, opts)) continue;

            const side = x < W() / 2 ? "left" : "right";
            const sideBonus = preferredSide && side === preferredSide ? W() * 0.35 : 0;
            const gapScore = Math.min(180, nearestStructureGap(x, kind, palette, upgrade, opts.currentRec || null));
            const score = sideBonus + gapScore + Math.random() * 8;
            if (score > bestScore) {
              bestScore = score;
              bestX = x;
            }
          }

          return bestX;
        }
        function spawnLoneBuilder() {
          if (document.hidden || reduced) return;
          const kind = pickBuilderKind();
          if (!kind) return;
          const x = kind === "castle" ? W() / 2 : findOpenSpot(kind);
          if (x == null) return;
          spawnBuilder(x, kind);
        }

        /* ============= UPGRADER ============= */
        function maxUpgradeForStructure(kind) {
          if (kind === "castle") return CASTLE_MAX_UPGRADE;
          if (kind === "marketstall") return 1;
          return 4;
        }

        // Castle level-ups should not outpace village growth — each tier requires
        // a growing population of mature houses before the upgrader will touch it.
        function castleHouseGate(nextLevel) {
          return nextLevel <= 4 ? nextLevel * 2 : 8 + (nextLevel - 4) * 3;
        }
        function matureHouseCount() {
          let n = 0;
          for (const h of houses) {
            if (h.kind === "house" && h.stage >= 2 && h.el.isConnected) n++;
          }
          return n;
        }
        function spawnUpgrader() {
          if (document.hidden || reduced) return;
          const matureHouses = matureHouseCount();
          const upgradeable = houses.filter((h) => {
            const nextUpgrade = (h.upgrade || 0) + 1;
            const nextX = projectedStructureXForUpgrade(h, nextUpgrade);
            return h.stage >= 2
              && h.el.dataset.upgrading !== "1"
              && (h.upgrade || 0) < maxUpgradeForStructure(h.kind)
              && (h.kind === "house" || h.kind === "tower" || h.kind === "castle"
                  || h.kind === "tavern" || h.kind === "guildhall" || h.kind === "mill"
                  || h.kind === "marketstall")
              && (h.kind !== "castle" || matureHouses >= castleHouseGate(nextUpgrade))
              && (h.kind === "castle" || structureSpotIsFree(nextX, h.kind, h.palette, nextUpgrade, { currentRec: h }));
          });
          if (upgradeable.length === 0) return;
          // When non-castle structures are upgradeable, bias picks away from the castle so it
          // doesn't dominate the pool once smaller buildings have capped out.
          const nonCastle = upgradeable.filter((h) => h.kind !== "castle");
          const pool = (nonCastle.length > 0 && Math.random() < 0.75) ? nonCastle : upgradeable;
          const target = pool[Math.floor(Math.random() * pool.length)];
          const fromLeft = target.x > W() / 2;
          const startX = fromLeft ? -20 : (W() + 20);
          const stopX = target.x + (fromLeft ? -8 : 40);
          const dir = fromLeft ? "right" : "left";
          const upgr = makePerson("builder", dir, { bottom: 40, silent: true });
          upgr.style.left = startX + "px";

          const walkTime = Math.abs(stopX - startX) / 50;
          requestAnimationFrame(() => {
            upgr.style.transition = `left ${walkTime}s linear`;
            upgr.style.left = stopX + "px";
          });

          const nextLevel = (target.upgrade || 0) + 1;
          const labels = {
            house: ["expands the cottage", "adds a second story to the cottage", "fortifies the cottage with stone", "transforms the cottage into a manor"],
            tower: ["reinforces the watchtower", "adds lamps and shieldwork to the watchtower", "fortifies the tower with iron", "crowns the tower with a grand spire"],
            castle: [
              "fortifies the castle walls",
              "raises new castle towers",
              "crowns the castle with banners",
              "transforms the castle into a mighty bastion",
              "links the rear curtain towers",
              "adds an observatory wing to the keep",
              "bridges the high keeps",
              "raises a royal archive gallery",
              "builds the banner court gatehouse",
              "crowns the citadel with a celestial spire",
            ],
            tavern: ["adds a hearth to the tavern", "extends the tavern's common room", "builds an inn alongside the tavern", "makes the tavern the realm's grandest"],
            guildhall: ["reinforces the guildhall", "adds a guildmaster's wing", "raises a guildhall tower", "makes the guildhall renowned across the land"],
            mill: ["reinforces the mill's frame", "adds a second pair of sails", "builds a granary by the mill", "makes the mill the realm's busiest"],
            marketstall: ["adds a second counter to the stall"],
          };
          const label = (labels[target.kind] || ["upgrades the structure"])[nextLevel - 1] || "improves the building";
          logEvent(`A master builder arrives and ${label}.`, "good");

          setTimeout(() => {
            if (!target.el.isConnected) {
              upgr.remove();
              return;
            }
            upgr.classList.add("working");
            beginUpgradeConstruction(target);
            const dustTimer = setInterval(() => {
              spawnParticle(target.x + 24 + (Math.random() - 0.5) * 40, 50 + Math.random() * 22, "dust");
            }, 220);
            // Big upgrade structures take longer
            const buildTime = target.kind === "castle" ? 15000
                            : target.kind === "marketstall" ? 9000
                            : 8000;
            setTimeout(() => {
              clearInterval(dustTimer);
              if (!target.el.isConnected) {
                upgr.remove();
                return;
              }
              upgr.classList.remove("working");
              const nextX = projectedStructureXForUpgrade(target, nextLevel);
              if (target.kind === "castle") makeRoomForMainCastle(nextLevel);
              target.upgrade = nextLevel;
              setStructureAnchorX(target, nextX);
              target.el.dataset.upgrade = String(nextLevel);
              // Per-tier full redraws — each upgrade swaps in a separately drawn,
              // more detailed asset (never CSS-scale). Buildings without a per-tier generator
              // still fall back to the additive up-N overlay pattern.
              if (target.kind === "marketstall") {
                target.el.innerHTML = marketstallSVG(target.palette, nextLevel);
              } else if (target.kind === "castle") {
                target.el.innerHTML = castleSVG(target.palette, nextLevel);
              } else if (target.kind === "tower") {
                target.el.innerHTML = upgradedTowerSVG(target.palette, nextLevel);
              } else if (target.kind === "house") {
                target.el.innerHTML = houseUpgradeSVG(target.palette, nextLevel);
              } else if (target.kind === "mill") {
                target.el.innerHTML = millSVG(nextLevel);
              } else if (target.kind === "tavern") {
                target.el.innerHTML = tavernSVG(nextLevel);
              } else if (target.kind === "guildhall") {
                target.el.innerHTML = guildhallUpgradeSVG(nextLevel);
              }
              revealCompletedStructure(target.el);
              finishUpgradeConstruction(target);
              applyLane(target, pickLane(target.x, target.kind, target.palette, nextLevel, target));
              for (let i = 0; i < 10; i++) {
                setTimeout(() => spawnSparkle(target.x + 24, 80, "#f0d060"), i * 70);
              }
              logEvent(`The building reaches Level ${nextLevel}!`, "good");
              if (target.kind === "castle" && nextLevel === CASTLE_NORMAL_ATTACK_IMMUNE_LEVEL) {
                logEvent("The Grand Castle stands invincible — only a colossal dragon could threaten it now!", "good");
              } else if (target.kind === "castle" && nextLevel === CASTLE_MAX_UPGRADE) {
                logEvent("The Celestial Citadel is complete — the realm has never seen higher walls.", "good");
              }
              scheduleAmbientRefresh(140);
              const exitX = fromLeft ? (W() + 20) : -20;
              const exitDur = Math.abs(exitX - stopX) / 50;
              upgr.style.transition = `left ${exitDur}s linear`;
              upgr.style.left = exitX + "px";
              setTimeout(() => upgr.remove(), exitDur * 1000 + 500);
            }, buildTime);
          }, walkTime * 1000 + 100);
        }

        /* ============= HUGE DRAGON (only threat to fortified castles) ============= */
        function hugeDragonSVG() {
          // Bigger, scarier version of the ember dragon
          const p = { body: "#5a1010", bodyL: "#8a2020", bodyD: "#2a0606", eye: "#ffa040", horn: "#0a0000", belly: "#c84a35" };
          return `<svg viewBox="0 0 56 26" xmlns="http://www.w3.org/2000/svg">
            <rect x="0" y="13" width="3" height="2" fill="${p.bodyD}"/>
            <rect x="0" y="11" width="3" height="3" fill="${p.bodyD}"/>
            <rect x="2" y="13" width="4" height="2" fill="${p.body}"/>
            <rect x="5" y="11" width="5" height="4" fill="${p.body}"/>
            <rect x="5" y="11" width="5" height="1" fill="${p.bodyL}"/>
            <rect x="9" y="9" width="22" height="8" fill="${p.body}"/>
            <rect x="9" y="9" width="22" height="1" fill="${p.bodyL}"/>
            <rect x="11" y="16" width="18" height="1" fill="${p.bodyD}"/>
            <rect x="13" y="14" width="14" height="3" fill="${p.belly}" opacity="0.7"/>
            <rect x="10" y="6" width="3" height="3" fill="${p.bodyD}"/>
            <rect x="15" y="5" width="3" height="4" fill="${p.bodyD}"/>
            <rect x="20" y="5" width="3" height="4" fill="${p.bodyD}"/>
            <rect x="25" y="5" width="3" height="4" fill="${p.bodyD}"/>
            <rect x="12" y="17" width="3" height="5" fill="${p.body}"/>
            <rect x="12" y="21" width="3" height="1" fill="${p.bodyD}"/>
            <rect x="24" y="17" width="3" height="5" fill="${p.body}"/>
            <rect x="24" y="21" width="3" height="1" fill="${p.bodyD}"/>
            <rect x="31" y="8" width="4" height="5" fill="${p.body}"/>
            <rect x="31" y="8" width="4" height="1" fill="${p.bodyL}"/>
            <rect x="35" y="6" width="10" height="8" fill="${p.body}"/>
            <rect x="35" y="6" width="10" height="1" fill="${p.bodyL}"/>
            <rect x="45" y="9" width="3" height="3" fill="${p.body}"/>
            <rect x="38" y="13" width="8" height="3" fill="${p.bodyD}"/>
            <rect x="43" y="12" width="1" height="1" fill="#fff"/>
            <rect x="45" y="12" width="1" height="1" fill="#fff"/>
            <rect x="38" y="8" width="3" height="3" fill="${p.eye}"/>
            <rect x="39" y="9" width="2" height="2" fill="#000"/>
            <rect x="36" y="2" width="2" height="4" fill="${p.horn}"/>
            <rect x="34" y="0" width="2" height="3" fill="${p.horn}"/>
            <rect x="41" y="2" width="2" height="4" fill="${p.horn}"/>
            <rect x="39" y="0" width="2" height="3" fill="${p.horn}"/>
            <g class="dr-wing-up">
              <polygon points="11,8 26,8 32,-6 25,1 19,-6 14,1" fill="${p.bodyD}"/>
              <polygon points="13,8 25,8 28,-1 23,3 19,-1 16,3" fill="${p.body}"/>
            </g>
            <g class="dr-wing-dn">
              <polygon points="12,13 24,13 28,24 22,16 18,24 14,16" fill="${p.bodyD}" opacity="0.6"/>
            </g>
          </svg>`;
        }

        function spawnHugeDragon() {
          if (document.hidden || reduced) return;
          // Pick a castle that has reached normal-attack immunity.
          const targets = houses.filter((h) => h.kind === "castle" && (h.upgrade || 0) >= CASTLE_HUGE_DRAGON_TARGET_LEVEL && h.el.isConnected);
          if (targets.length === 0) return;
          const target = targets[Math.floor(Math.random() * targets.length)];

          const d = document.createElement("div");
          d.className = "dragon huge";
          d.innerHTML = hugeDragonSVG();
          d.style.top = "30px";
          d.style.left = "-110px";
          dragonsLayer.appendChild(d);
          const rec = registerDragon(d, true);
          logEvent("A COLOSSAL DRAGON darkens the sky! The realm trembles.", "bad");

          // Slow, deliberate approach
          requestAnimationFrame(() => {
            d.style.transition = "left 6s linear, top 6s ease-in";
            d.style.left = (target.x - 24) + "px";
            d.style.top = (H() - 200) + "px";
          });

          // Massive fire breath onslaught
          const fireOnslaught = setTimeout(() => {
            if (rec.defeated) return;
            logEvent("It unleashes a torrent of fire upon the castle!", "bad");
            for (let i = 0; i < 14; i++) {
              setTimeout(() => {
                const fire = document.createElement("div");
                fire.className = "fire-breath";
                fire.style.width = "44px";
                fire.style.height = "40px";
                fire.style.left = (target.x + 20 + (Math.random() - 0.5) * 36) + "px";
                fire.style.bottom = (60 + Math.random() * 60) + "px";
                dragonsLayer.appendChild(fire);
                setTimeout(() => fire.remove(), 1800);
              }, i * 140);
            }
            // Castle ultimately falls
            setTimeout(() => {
              if (target.el.isConnected) {
                target.el.classList.add("crumbling");
                const i = houses.indexOf(target);
                if (i >= 0) houses.splice(i, 1);
                setTimeout(() => target.el.remove(), 1700);
                logEvent("The Grand Castle crumbles to ruin under the colossal dragon's wrath!", "bad");
              }
            }, 2400);
          }, 6200);

          // Soar away
          const soarAway = setTimeout(() => {
            d.style.transition = "left 6s linear, top 6s ease-out";
            d.style.left = (W() + 110) + "px";
            d.style.top = "30px";
          }, 11000);
          const cleanup = setTimeout(() => {
            unregisterDragon(d);
            d.remove();
          }, 17500);

          rec.onDefeat = () => {
            clearTimeout(fireOnslaught);
            clearTimeout(soarAway);
            clearTimeout(cleanup);
            d.style.transition = "left 3s ease-out, top 3s ease-out, opacity 3s ease";
            d.style.left = (W() + 140) + "px";
            d.style.top = "20px";
            d.style.opacity = "0.4";
            logEvent("Volleys force the great dragon to retreat!", "good");
            setTimeout(() => { unregisterDragon(d); d.remove(); }, 3200);
          };
        }

        function maybeHugeDragon() {
          if (!hugeDragonReady()) return; // hard gate
          if (!firstHugeDragonAnnounced) {
            firstHugeDragonAnnounced = true;
            logEvent("The horizon trembles. Something vast stirs in the mountains.", "bad");
          }
          spawnHugeDragon();
        }

        /* ============= MARKETSTALLS + MERCHANTS + CUSTOMERS ============= */
        const MARKET_ANCHORS = ["tavern", "well", "guildhall", "marketstall", "blacksmith"];
        const STALL_CAP = 14;
        const ROAD_MARKET_POSITIONS = [0.18, 0.82, 0.28, 0.72, 0.10, 0.90, 0.38, 0.62];
        const MARKET_TARGETS_BY_ROAD = [0, 1, 3, 5, 8, 11];
        function marketStallCount() {
          return houses.filter((h) => h.kind === "marketstall").length;
        }
        function targetMarketStallCountForRoad(tier) {
          return MARKET_TARGETS_BY_ROAD[Math.max(0, Math.min(tier, MARKET_TARGETS_BY_ROAD.length - 1))] || 0;
        }
        function isRoadsideMarketSpotFree(candidate) {
          return structureSpotIsFree(candidate, "marketstall", null, 0, {
            margin: 48,
            treeGap: 42,
          });
        }
        function marketPressureAt(x) {
          return houses
            .filter((h) => h.kind === "marketstall" && h.el.isConnected)
            .reduce((sum, h) => sum + Math.max(0, 180 - Math.abs(h.x - x)), 0);
        }
        function findRoadsideMarketSpot() {
          const candidates = [];
          ROAD_MARKET_POSITIONS.forEach((pos) => {
            const base = pos * W();
            [0, -22, 22, -42, 42].forEach((offset) => {
              candidates.push(base + offset + (Math.random() - 0.5) * 10);
            });
          });
          candidates.sort((a, b) => marketPressureAt(a) - marketPressureAt(b));
          for (const candidate of candidates) {
            if (isRoadsideMarketSpotFree(candidate)) return candidate;
          }

          const anchors = houses.filter((h) => MARKET_ANCHORS.includes(h.kind) && h.stage >= 2);
          for (let i = 0; i < 20 && anchors.length > 0; i++) {
            const a = pick(anchors);
            const candidate = a.x + (Math.random() < 0.5 ? -1 : 1) * (72 + Math.random() * 120);
            if (isRoadsideMarketSpotFree(candidate)) return candidate;
          }
          return findOpenSpot("marketstall", null, 0, { margin: 48, treeGap: 42 });
        }
        function spawnStallBuilder() {
          if (document.hidden || reduced) return;
          if (marketStallCount() >= STALL_CAP) return;
          const x = findRoadsideMarketSpot();
          if (x == null) return;
          spawnBuilder(x, "marketstall", spawnMerchantAt);
        }

        function ensureRoadsideMarkets(tier) {
          const target = Math.min(STALL_CAP, targetMarketStallCountForRoad(tier));
          const missing = target - marketStallCount();
          if (missing <= 0) return;
          for (let i = 0; i < missing; i++) {
            setTimeout(spawnStallBuilder, 1200 + i * 4200);
          }
        }

        function spawnMerchantAt(stallRec) {
          if (!stallRec || !stallRec.el.isConnected) return;
          const m = document.createElement("div");
          m.className = "person merchant stall-merchant";
          m.dataset.dir = "right";
          m.innerHTML = personSVG("merchant");
          m.style.left = (stallRec.x + 4) + "px";
          m.style.bottom = "46px";
          treesLayer.appendChild(m);
          stallRec.merchantEl = m;
        }

        const CUSTOMER_LOGS = {
          buy: [
            "A villager buys bread at the market.",
            "A traveler purchases cloth from a stall.",
            "Coins clink — wares change hands at the market.",
            "A peasant haggles for cheese, then pays.",
            "A traveler trades silver for wine.",
          ],
          argue: [
            "Voices rise at the market — a dispute!",
            "A customer storms off, shouting at the merchant.",
            "Words turn sharp at a stall — a haggle gone wrong.",
          ],
          browse: [
            "A long bargain at the stall draws onlookers.",
            "A noble inspects every basket on the counter.",
          ],
        };

        function maybeStopAtStall(personEl) {
          if (!personEl || !personEl.isConnected) return false;
          if (personEl.dataset.usedStall === "1") return false;
          // Use currently rendered left (mid-animation), not the destination
          const cs = getComputedStyle(personEl);
          const px = parseFloat(cs.left || "0");
          const tier = parseInt(world.dataset.road || "0", 10);
          const stalls = houses.filter((h) => h.kind === "marketstall" && h.stage >= 2 && Math.abs(h.x - px) < 40);
          if (stalls.length === 0) return false;
          const stall = stalls[Math.floor(Math.random() * stalls.length)];
          personEl.dataset.usedStall = "1";
          const roll = Math.random();
          // 75% ignore, 20% purchase, 4% argue, 1% browse
          if (roll < 0.75) return false;
          // pause at stall
          personEl.style.transition = "left 0.8s linear";
          personEl.style.left = (stall.x + 4) + "px";
          if (roll < 0.95) {
            // purchase
            const isNoble = tier >= 5 && Math.random() < 0.18;
            const pauseMs = 1500 + Math.random() * 1000 + (isNoble ? 2000 : 0);
            setTimeout(() => {
              if (!personEl.isConnected) return;
              const coinCount = isNoble ? 5 + Math.floor(Math.random() * 3) : 2 + Math.floor(Math.random() * 2);
              for (let i = 0; i < coinCount; i++) {
                setTimeout(() => spawnCoin(stall.x + 8 + (Math.random() - 0.5) * 6, 60), i * 110);
              }
              if (Math.random() < 0.4) {
                const ops = CUSTOMER_LOGS.buy;
                logEvent(ops[Math.floor(Math.random() * ops.length)]);
              }
              if (stall.merchantEl) stall.merchantEl.classList.add("trading");
              setTimeout(() => { if (stall.merchantEl) stall.merchantEl.classList.remove("trading"); }, 700);
            }, pauseMs * 0.5);
            // continue walking after pause
            setTimeout(() => resumeWalker(personEl), pauseMs);
          } else if (roll < 0.99) {
            // argue
            const pauseMs = 1600;
            personEl.classList.add("arguing");
            if (stall.merchantEl) stall.merchantEl.classList.add("arguing");
            spawnArgueBang(stall.x + 4, 80);
            spawnArgueBang(personEl, 90);
            const ops = CUSTOMER_LOGS.argue;
            logEvent(ops[Math.floor(Math.random() * ops.length)], "bad");
            setTimeout(() => {
              personEl.classList.remove("arguing");
              if (stall.merchantEl) stall.merchantEl.classList.remove("arguing");
              resumeWalker(personEl, 1.5); // storm off faster
            }, pauseMs);
          } else {
            // long browse
            const pauseMs = 4500 + Math.random() * 1500;
            const ops = CUSTOMER_LOGS.browse;
            logEvent(ops[Math.floor(Math.random() * ops.length)]);
            const coinTimer = setInterval(() => spawnCoin(stall.x + 8, 60), 700);
            setTimeout(() => clearInterval(coinTimer), pauseMs - 200);
            setTimeout(() => resumeWalker(personEl), pauseMs);
          }
          return true;
        }

        function resumeWalker(p, speedMul) {
          if (!p || !p.isConnected) return;
          const dir = p.dataset.dir || "right";
          const exitX = dir === "left" ? -20 : (W() + 20);
          const curX = parseFloat(p.style.left || "0");
          const baseSpeed = 14;
          const dist = Math.abs(exitX - curX);
          const dur = dist / (baseSpeed * (speedMul || 1));
          p.style.transition = `left ${dur}s linear`;
          p.style.left = exitX + "px";
          setTimeout(() => { if (p.isConnected) p.remove(); }, dur * 1000 + 500);
        }

        function spawnCoin(x, bottom) {
          const c = document.createElement("div");
          c.className = "coin";
          c.style.left = x + "px";
          c.style.bottom = bottom + "px";
          c.style.setProperty("--vx", ((Math.random() - 0.5) * 12) + "px");
          treesLayer.appendChild(c);
          setTimeout(() => c.remove(), 1500);
        }

        function spawnArgueBang(target, bottom) {
          const x = typeof target === "number" ? target : parseFloat(target.style.left || "0");
          const e = document.createElement("div");
          e.className = "argue-bang";
          e.textContent = "!";
          e.style.left = (x + 2) + "px";
          e.style.bottom = bottom + "px";
          treesLayer.appendChild(e);
          setTimeout(() => e.remove(), 1200);
        }

        /* ============= GUARD POSTS + ARROW VOLLEYS ============= */
        const GUARDPOST_CAP = 1;
        function spawnGuardpostBuilder() {
          if (document.hidden || reduced) return;
          if (!canBuildStructureKind("guardpost")) return;
          if (houses.filter((h) => h.kind === "guardpost").length >= GUARDPOST_CAP) return;
          // Spread along the road — avoid spawning within 200px of another guardpost
          let x = null;
          for (let i = 0; i < 30 && x == null; i++) {
            const candidate = 80 + Math.random() * (W() - 160);
            const free = !houses.some((h) => h.kind === "guardpost" && Math.abs(h.x - candidate) < 200)
                      && structureSpotIsFree(candidate, "guardpost", null, 0, { treeGap: 80 });
            if (free) x = candidate;
          }
          if (x == null) x = findOpenSpot("guardpost");
          if (x == null) return;
          spawnBuilder(x, "guardpost");
        }

        // Volley tick — every ~700ms while any dragon is on-screen, each guard post
        // fires an arrow at a (locked) target position read at fire time.
        let volleyTimer = null;
        function startVolleyLoopIfNeeded() {
          if (volleyTimer) return;
          volleyTimer = setInterval(() => {
            if (activeDragons.length === 0) {
              clearInterval(volleyTimer);
              volleyTimer = null;
              return;
            }
            const posts = houses.filter((h) => h.kind === "guardpost" && h.stage >= 2 && h.el.isConnected);
            if (posts.length === 0) return;
            for (const post of posts) {
              // Stagger so volleys don't all fire on the same frame
              const delay = Math.random() * 600;
              setTimeout(() => {
                const target = activeDragons[Math.floor(Math.random() * activeDragons.length)];
                if (!target || !target.el.isConnected || target.defeated) return;
                fireArrowAt(post, target);
              }, delay);
            }
          }, 700);
        }

        function fireArrowAt(post, dragon) {
          if (!post.el.isConnected || !dragon.el.isConnected) return;
          const dragonRect = dragon.el.getBoundingClientRect();
          const worldRect = world.getBoundingClientRect();
          const tx = (dragonRect.left + dragonRect.width / 2) - worldRect.left;
          const ty = (dragonRect.top  + dragonRect.height / 2) - worldRect.top;
          const fromX = post.x + 12;
          const fromY = worldRect.height - 90; // top of guard post
          const a = document.createElement("div");
          a.className = "arrow";
          a.style.left = fromX + "px";
          a.style.top  = fromY + "px";
          const dx = tx - fromX, dy = ty - fromY;
          const angle = Math.atan2(dy, dx) * 180 / Math.PI;
          a.style.setProperty("--ang", angle + "deg");
          dragonsLayer.appendChild(a);
          // animate via transition to landing point
          requestAnimationFrame(() => {
            a.style.transition = "left 0.4s linear, top 0.4s linear, opacity 0.3s ease 0.3s";
            a.style.left = tx + "px";
            a.style.top  = ty + "px";
          });
          setTimeout(() => {
            // 70% hit
            if (Math.random() < 0.7 && !dragon.defeated) {
              dragon.hp--;
              dragon.el.classList.add("flinch");
              setTimeout(() => dragon.el.classList.remove("flinch"), 200);
              // small hit sparkle
              const s = document.createElement("div");
              s.className = "arrow-hit";
              s.style.left = tx + "px";
              s.style.top = ty + "px";
              dragonsLayer.appendChild(s);
              setTimeout(() => s.remove(), 400);
              if (dragon.hp <= 0 && !dragon.defeated) {
                dragon.defeated = true;
                if (dragon.onDefeat) dragon.onDefeat();
              }
            }
            a.remove();
          }, 420);
        }

        /* ============= SOLAR HALO ============= */
        function maybeSolarHalo() {
          if (reduced) return;
          const phase = world.dataset.time || "day";
          // Only during day/dawn/dusk — never at night
          if (phase === "night") return;
          // 60% chance to actually show — keeps it "rare"
          if (Math.random() < 0.4) return;
          world.classList.add("has-halo");
          logEvent("A shimmering halo crowns the sun!", "good");
          setTimeout(() => world.classList.remove("has-halo"), 25000 + Math.random() * 12000);
        }

        /* ============= ROAD UPGRADES (world-level) ============= */
        // Tier 0 = grass (no road strip); 1..5 = dirt → packed → stone → cobble → flagstone
        const ROAD_NAMES = ["grass", "dirt", "packed dirt", "stone", "cobblestone", "flagstone"];
        const ROAD_LOG = [
          "",                                                             // 0 (grass — starting state, no transition log)
          "A dirt path is trodden across the realm.",                     // 1
          "The road is packed flat by daily traffic.",                    // 2
          "Stone slabs are laid along the road.",                         // 3
          "Cobblestones are set into the king's road.",                   // 4
          "Master masons finish the road in great flagstones.",           // 5
        ];
        // Required completed structures to upgrade INTO each tier
        const ROAD_THRESHOLDS = [0, 2, 5, 9, 14, 20];
        const ROAD_STREET_LIGHT_POSITIONS = [0.26, 0.74, 0.12, 0.88, 0.4, 0.6];
        const pendingStreetLights = [];
        function streetLightUpgradeForRoad(tier) {
          return Math.max(0, Math.min(4, (tier | 0) - 1));
        }
        function targetStreetLightCountForRoad(tier) {
          const target = tier <= 0 ? 0 : Math.min(ROAD_STREET_LIGHT_POSITIONS.length, tier + 1);
          return canRepeatStructureKind("lamppost") ? target : Math.min(target, 1);
        }
        function streetLightGap() {
          return Math.max(42, Math.min(72, W() * 0.085));
        }
        function activeStreetLights() {
          return houses.filter((h) => h.kind === "lamppost" && h.el.isConnected);
        }
        function hasStreetLightNear(x) {
          const gap = streetLightGap();
          return activeStreetLights().some((h) => Math.abs(h.x - x) < gap)
              || pendingStreetLights.some((px) => Math.abs(px - x) < gap);
        }
        function findStreetLightSpot(pos) {
          const base = Math.max(24, Math.min(W() - 24, pos * W()));
          const offsets = [0, -28, 28, -52, 52, -78, 78];
          for (const offset of offsets) {
            const x = Math.max(24, Math.min(W() - 24, base + offset));
            if (hasStreetLightNear(x)) continue;
            if (trees.some((t) => Math.abs(t.x - x) < 30)) continue;
            return x;
          }
          return null;
        }
        function setStreetLightUpgrade(rec, level, silent = false) {
          if (!rec || rec.kind !== "lamppost" || !rec.el.isConnected) return false;
          level = Math.max(0, Math.min(4, level | 0));
          if ((rec.upgrade || 0) >= level) return false;
          rec.upgrade = level;
          rec.el.dataset.upgrade = String(level);
          revealCompletedStructure(rec.el);
          applyLane(rec, pickLane(rec.x, rec.kind, rec.palette, level, rec));
          if (!silent) {
            for (let i = 0; i < 5; i++) {
              setTimeout(() => spawnSparkle(rec.x + 9, 88, "#f0d060"), i * 90);
            }
          }
          return true;
        }
        function ensureRoadStreetLights(tier) {
          if (tier <= 0 || reduced) return;
          const targetUpgrade = streetLightUpgradeForRoad(tier);
          const upgraded = activeStreetLights()
            .filter((rec) => rec.stage >= 2)
            .filter((rec) => setStreetLightUpgrade(rec, targetUpgrade)).length;
          const targetCount = targetStreetLightCountForRoad(tier);
          let plannedCount = activeStreetLights().length + pendingStreetLights.length;
          let added = 0;
          ROAD_STREET_LIGHT_POSITIONS.forEach((pos, i) => {
            if (plannedCount >= targetCount) return;
            setTimeout(() => {
              if (!canBuildStructureKind("lamppost")) return;
              if (activeStreetLights().length + pendingStreetLights.length >= targetCount) return;
              const x = findStreetLightSpot(pos);
              if (x == null) return;
              pendingStreetLights.push(x);
              const started = spawnBuilder(x, "lamppost", (rec) => {
                const idx = pendingStreetLights.findIndex((px) => Math.abs(px - x) < 1);
                if (idx >= 0) pendingStreetLights.splice(idx, 1);
                setStreetLightUpgrade(rec, targetUpgrade, true);
              });
              if (!started) {
                const idx = pendingStreetLights.findIndex((px) => Math.abs(px - x) < 1);
                if (idx >= 0) pendingStreetLights.splice(idx, 1);
              }
            }, i * 750);
            plannedCount++;
            added++;
          });
          if (added > 0 && targetUpgrade > 0) {
            logEvent("Road crews add and refit street lights for the upgraded road.", "good");
          } else if (added > 0) {
            logEvent("Road crews raise street lights along the new path.", "good");
          } else if (upgraded > 0 && targetUpgrade > 0) {
            logEvent("Street lights are refitted for the upgraded road.", "good");
          }
        }
        function setRoadLevel(n) {
          n = Math.max(0, Math.min(5, n | 0));
          const cur = parseInt(world.dataset.road || "0", 10);
          if (n === cur) return;
          world.dataset.road = n;
          if (n > 0 && ROAD_LOG[n]) logEvent(ROAD_LOG[n], "good");
          ensureRoadStreetLights(n);
          ensureRoadsideMarkets(n);
          scheduleAmbientRefresh(160);
        }
        function tryUpgradeRoad() {
          const cur = parseInt(world.dataset.road || "0", 10);
          if (cur >= 5) return;
          // Need at least a few buildings for the road work to make sense
          const builtCount = houses.filter((h) => h.stage >= 2).length;
          if (builtCount < ROAD_THRESHOLDS[cur + 1]) return;
          // Spawn a road-builder visibly hammering at a random point
          if (reduced) { setRoadLevel(cur + 1); return; }
          const x = W() * (0.25 + Math.random() * 0.5);
          const lj = makePerson("builder", x > W() / 2 ? "right" : "left", { bottom: 40, silent: true });
          const fromLeft = x > W() / 2;
          const startX = fromLeft ? -20 : (W() + 20);
          lj.style.left = startX + "px";
          const walkTime = Math.abs(x - startX) / 50;
          requestAnimationFrame(() => {
            lj.style.transition = `left ${walkTime}s linear`;
            lj.style.left = x + "px";
          });
          setTimeout(() => {
            lj.classList.add("working");
            const dustTimer = setInterval(() => {
              spawnParticle(x + (Math.random() - 0.5) * 30, 50 + Math.random() * 12, "dust");
            }, 200);
            setTimeout(() => {
              clearInterval(dustTimer);
              lj.classList.remove("working");
              setRoadLevel(cur + 1);
              const exitX = fromLeft ? (W() + 20) : -20;
              const exitDur = Math.abs(exitX - x) / 50;
              lj.style.transition = `left ${exitDur}s linear`;
              lj.style.left = exitX + "px";
              setTimeout(() => lj.remove(), exitDur * 1000 + 500);
            }, 5000);
          }, walkTime * 1000 + 100);
        }

        /* ============= CAMEL CARAVAN ============= */
        function camelSVG() {
          return `<svg viewBox="0 0 32 22" xmlns="http://www.w3.org/2000/svg">
            <!-- legs -->
            <rect x="5" y="14" width="2" height="8" fill="#9a6838"/>
            <rect x="11" y="14" width="2" height="8" fill="#a87838"/>
            <rect x="19" y="14" width="2" height="8" fill="#9a6838"/>
            <rect x="25" y="14" width="2" height="8" fill="#a87838"/>
            <rect x="5" y="20" width="2" height="2" fill="#5a3818"/>
            <rect x="11" y="20" width="2" height="2" fill="#5a3818"/>
            <rect x="19" y="20" width="2" height="2" fill="#5a3818"/>
            <rect x="25" y="20" width="2" height="2" fill="#5a3818"/>
            <!-- body -->
            <rect x="4" y="10" width="22" height="6" fill="#c89858"/>
            <rect x="4" y="10" width="22" height="1" fill="#e0b878"/>
            <rect x="4" y="15" width="22" height="1" fill="#a87838"/>
            <!-- humps -->
            <rect x="7" y="6" width="6" height="4" fill="#c89858"/>
            <rect x="7" y="5" width="6" height="2" fill="#a87838"/>
            <rect x="14" y="6" width="6" height="4" fill="#c89858"/>
            <rect x="14" y="5" width="6" height="2" fill="#a87838"/>
            <!-- packs strapped between humps -->
            <rect x="13" y="8" width="1" height="2" fill="#5a3818"/>
            <rect x="20" y="8" width="1" height="2" fill="#5a3818"/>
            <!-- neck -->
            <rect x="22" y="6" width="2" height="6" fill="#c89858"/>
            <rect x="22" y="6" width="1" height="6" fill="#a87838"/>
            <!-- head -->
            <rect x="23" y="4" width="5" height="4" fill="#c89858"/>
            <rect x="23" y="4" width="5" height="1" fill="#e0b878"/>
            <rect x="27" y="5" width="1" height="1" fill="#1a0a0a"/>
            <!-- ear -->
            <rect x="24" y="3" width="2" height="1" fill="#a87838"/>
            <!-- tail -->
            <rect x="2" y="12" width="3" height="2" fill="#a87838"/>
            <rect x="1" y="13" width="2" height="2" fill="#5a3818"/>
          </svg>`;
        }

        function spawnCamelCaravan() {
          if (document.hidden || reduced) return;
          const dir = Math.random() > 0.5 ? "left" : "right";
          const dur = 55 + Math.random() * 25;
          const sign = dir === "right" ? 1 : -1;

          // Lead camel rider (a peasant in earthy clothes)
          const rider = makePerson("", dir, { bottom: 6, silent: true });
          const startBase = dir === "left" ? (W() + 30) : -30;
          rider.style.left = startBase + "px";
          requestAnimationFrame(() => {
            rider.style.transition = `left ${dur}s linear`;
            rider.style.left = (dir === "left" ? -30 : (W() + 30)) + "px";
          });
          setTimeout(() => rider.remove(), dur * 1000 + 500);

          // Camels (2-4)
          const camelCount = 2 + Math.floor(Math.random() * 3);
          for (let i = 0; i < camelCount; i++) {
            const c = document.createElement("div");
            c.className = "camel";
            c.innerHTML = camelSVG();
            if (dir === "left") c.style.transform = "scaleX(-1)";
            const offset = -sign * (24 + i * 30);
            c.style.left = (startBase + offset) + "px";
            c.style.bottom = (3 + Math.random() * 4) + "px";
            c.style.animationDelay = (Math.random() * 0.3) + "s";
            peopleLayer.appendChild(c);
            requestAnimationFrame(() => {
              c.style.transition = `left ${dur}s linear`;
              c.style.left = ((dir === "left" ? -30 : (W() + 30)) + offset) + "px";
            });
            setTimeout(() => c.remove(), dur * 1000 + 500);
          }

          // Optional second rider at the rear
          if (Math.random() > 0.4) {
            const rear = makePerson("warrior", dir, { bottom: 6, silent: true });
            const rearOffset = -sign * (24 + camelCount * 30);
            rear.style.left = (startBase + rearOffset) + "px";
            requestAnimationFrame(() => {
              rear.style.transition = `left ${dur}s linear`;
              rear.style.left = ((dir === "left" ? -30 : (W() + 30)) + rearOffset) + "px";
            });
            setTimeout(() => rear.remove(), dur * 1000 + 500);
          }

          logEvent("A camel caravan crosses the realm, packs heavy with spice.", "good");
        }

        /* ============= APOCALYPSE CYCLE ============= */
        let developedSince = null;
        let apocalypseTriggered = false;

        function isFullyDeveloped() {
          const buildings = houses.filter((h) => h.stage >= 2 && h.kind !== "campfire" && h.kind !== "signpost");
          if (buildings.length < 8) return false;
          const avgUpgrade = buildings.reduce((s, h) => s + (h.upgrade || 0), 0) / buildings.length;
          return avgUpgrade >= 2.4 || buildings.length >= 14;
        }

        function checkDevelopment() {
          if (apocalypseTriggered) return;
          if (isFullyDeveloped()) {
            if (developedSince === null) {
              developedSince = performance.now();
              logEvent("The realm flourishes! A great medieval city stands tall.", "good");
            } else if ((performance.now() - developedSince) > 24000) {
              apocalypse();
            }
          } else {
            developedSince = null;
          }
        }

        function apocalypse() {
          apocalypseTriggered = true;
          logEvent("The sky darkens... a terrible roar echoes!", "bad");
          setTimeout(() => logEvent("Doom is upon the realm!", "bad"), 2500);

          const sweepDur = 12; // seconds for full screen sweep
          const d = document.createElement("div");
          d.className = "dragon huge apocalypse-dragon";
          d.innerHTML = hugeDragonSVG();
          d.style.top = (H() * 0.35) + "px";
          d.style.left = "-150px";
          dragonsLayer.appendChild(d);
          requestAnimationFrame(() => {
            d.style.transition = `left ${sweepDur}s linear, top ${sweepDur}s ease-in-out`;
            d.style.left = (W() + 150) + "px";
            d.style.top = (H() * 0.45) + "px";
          });

          const buildings = houses.filter((h) => h.stage >= 2);
          buildings.forEach((target) => {
            const passTime = (target.x / W()) * sweepDur * 1000 + 800;
            setTimeout(() => {
              if (!target.el.isConnected) return;
              for (let j = 0; j < 6; j++) {
                setTimeout(() => {
                  const fire = document.createElement("div");
                  fire.className = "fire-breath";
                  fire.style.width = "40px";
                  fire.style.height = "36px";
                  fire.style.left = (target.x + 10 + (Math.random() - 0.5) * 32) + "px";
                  fire.style.bottom = (60 + Math.random() * 50) + "px";
                  dragonsLayer.appendChild(fire);
                  setTimeout(() => fire.remove(), 1600);
                }, j * 110);
              }
              target.el.classList.add("crumbling");
              const i = houses.indexOf(target);
              if (i >= 0) houses.splice(i, 1);
              setTimeout(() => target.el.remove(), 1500);
            }, passTime);
          });

          // Also burn trees in the path
          [
            { list: trees.slice(), remove: removeTree },
            { list: backTrees.slice(), remove: removeBackTree },
            { list: hillTrees.slice(), remove: removeHillTree },
          ].forEach((group) => {
            group.list.forEach((tree) => {
              const passTime = (tree.x / W()) * sweepDur * 1000 + 800;
              setTimeout(() => {
                if (!tree.el.isConnected) return;
                tree.el.classList.add("falling");
                group.remove(tree);
                setTimeout(() => tree.el.remove(), 1500);
              }, passTime);
            });
          });

          // Flee all walkers off-screen
          peopleLayer.querySelectorAll(".person, .sheep, .horseman, .dog, .cart").forEach((el) => {
            const cur = parseFloat(getComputedStyle(el).left);
            const target = cur < W() / 2 ? -50 : (W() + 50);
            const dist = Math.abs(target - cur);
            el.style.transition = `left ${dist / 200}s linear`;
            el.style.left = target + "px";
            setTimeout(() => { if (el.isConnected) el.remove(); }, (dist / 200) * 1000 + 200);
          });

          // Cleanup + rebirth
          setTimeout(() => {
            d.remove();
            logEvent("The realm lies in ashes... but life endures. Let it rise again.", "weather");
            apocalypseTriggered = false;
            developedSince = null;
            // Reset the road back to dirt — the world rises anew
            world.dataset.road = "0";
            scheduleAmbientRefresh(300);
            // Seed fresh trees so future builders have something to chop.
            setTimeout(() => plantTreeBurst(true, 5, 180), 1500);
            setTimeout(() => plantBackTreeBurst(true, Math.ceil(backTreeLimit() * 0.35), 80), 1300);
            setTimeout(() => plantHillTreeBurst(true, Math.ceil((hillTreeLayerLimit("far") + hillTreeLayerLimit("near")) * 0.3), 75), 1200);
          }, (sweepDur + 2) * 1000);
        }

        /* ============= SPAWN LOOPS ============= */
        // Default rate-scale curve: indexed by current road tier (0..5).
        // Higher tier => faster spawn (interval divided by scale).
        const DEFAULT_RATE_SCALE = [1.0, 1.1, 1.3, 1.5, 1.7, 2.0];
        function loop(fn, min, max, opts) {
          if (document.hidden) {
            setTimeout(() => loop(fn, min, max, opts), Math.max(min, 3000));
            return;
          }
          const o = opts || {};
          const tier = parseInt(world.dataset.road || "0", 10);
          const minRoad = o.minRoad ?? 0;
          if (tier < minRoad) {
            // not yet eligible — wait and try again at original interval
            setTimeout(() => loop(fn, min, max, opts), min + Math.random() * (max - min));
            return;
          }
          fn();
          const scale = (o.rateScale && o.rateScale[tier]) || 1.0;
          const interval = (min + Math.random() * (max - min)) / scale;
          setTimeout(() => loop(fn, min, max, opts), interval);
        }

        // Establish a visible home base on the first frame. The remaining
        // structures still arrive through the builder flow as the village grows.
        setTimeout(() => {
          plantTreeBurst(true, 8, 55);
          plantBackTreeBurst(true, Math.ceil(backTreeLimit() * 0.45), 35);
          plantHillTreeBurst(true, Math.ceil((hillTreeLayerLimit("far") + hillTreeLayerLimit("near")) * 0.48), 32);
        }, 200);

        function buildStarterStructure(seed) {
          spawnBuilder(seed.pos * W(), seed.kind, (rec) => {
            const upgrade = seed.up || 0;
            if (!rec || upgrade <= 0) return;
            let nextX = projectedStructureXForUpgrade(rec, upgrade);
            if (!structureSpotIsFree(nextX, rec.kind, rec.palette, upgrade, { currentRec: rec })) {
              const openX = findOpenSpot(rec.kind, rec.palette, upgrade, { currentRec: rec });
              if (openX != null) nextX = openX;
            }
            rec.upgrade = upgrade;
            setStructureAnchorX(rec, nextX);
            rec.el.dataset.upgrade = String(upgrade);
            if (rec.kind === "marketstall") {
              rec.el.innerHTML = marketstallSVG(rec.palette, upgrade);
            } else if (rec.kind === "castle") {
              rec.el.innerHTML = castleSVG(rec.palette, upgrade);
            } else if (rec.kind === "tower") {
              rec.el.innerHTML = upgradedTowerSVG(rec.palette, upgrade);
            } else if (rec.kind === "house") {
              rec.el.innerHTML = houseUpgradeSVG(rec.palette, upgrade);
            } else if (rec.kind === "mill") {
              rec.el.innerHTML = millSVG(upgrade);
            } else if (rec.kind === "tavern") {
              rec.el.innerHTML = tavernSVG(upgrade);
            } else if (rec.kind === "guildhall") {
              rec.el.innerHTML = guildhallUpgradeSVG(upgrade);
            }
            revealCompletedStructure(rec.el);
            applyLane(rec, pickLane(rec.x, rec.kind, rec.palette, upgrade, rec));
            scheduleAmbientRefresh(140);
          }, true);
        }
        function buildStaticStarter(seed) {
          const kind = seed.kind;
          const palette = kind === "house"
            ? { ...pick(HOUSE_PALETTES), variant: pick(HOUSE_VARIANTS) }
            : kind === "marketstall" ? pick(MARKET_PALETTES) : null;
          let x = seed.pos * W();
          if (!structureSpotIsFree(x, kind, palette, 0)) x = findOpenSpot(kind, palette, 0);
          if (x == null) return;
          const el = document.createElement("div");
          el.className = "house";
          el.dataset.kind = kind;
          el.dataset.upgrade = "0";
          if (palette?.variant) el.dataset.variant = palette.variant;
          el.innerHTML = structureSVG(kind, palette);
          el.style.left = x + "px";
          treesLayer.appendChild(el);
          const rec = { el, x, kind, stage: 2, upgrade: 0, palette };
          houses.push(rec);
          setStructureStage(rec, 2);
          el.querySelectorAll(".hs-walls, .hs-roof").forEach((part) => part.setAttribute("opacity", 1));
          applyLane(rec, pickLane(x, kind, palette, 0, rec));
        }
        buildStaticStarter(STARTER_STRUCTURE_SEEDS[0]);
        buildStaticStarter(STARTER_STRUCTURE_SEEDS[6]);
        setTimeout(() => {
          if (reduced) {
            STARTER_STRUCTURE_SEEDS.forEach((seed, i) => {
              if (i !== 0 && i !== 6) buildStaticStarter(seed);
            });
            return;
          }
          STARTER_STRUCTURE_SEEDS.forEach((seed, i) => {
            if (i !== 0 && i !== 6) setTimeout(() => buildStarterStructure(seed), 200 + i * 1200);
          });
        }, 600);
        setTimeout(() => scheduleAmbientRefresh(0), 900);

        if (!reduced) {
          setTimeout(() => logEvent("Adventurer enters the realm.", "good"), 500);

          // Mixed person spawner — most lone, some grouped
          function spawnRandomTraveler() {
            const r = Math.random();
            if (r < 0.18) spawnGroup();
            else spawnPerson();
          }

          const RS = DEFAULT_RATE_SCALE;
          setTimeout(() => loop(spawnRandomTraveler, 10000, 18000, { minRoad: 0, rateScale: RS }), 800);
          setTimeout(() => loop(spawnHorse, 25000, 55000, { minRoad: 2, rateScale: RS }), 11000);
          setTimeout(() => loop(spawnCaravan, 80000, 150000, { minRoad: 3, rateScale: RS }), 40000);
          setTimeout(() => loop(spawnDuel, 45000, 95000, { minRoad: 1, rateScale: RS }), 30000);
          setTimeout(spawnLegionnairesCentury, 18000);
          setTimeout(() => loop(spawnLegionnairesCentury, 110000, 210000, { minRoad: 0, rateScale: RS }), 65000);
          setTimeout(() => loop(spawnArmy, 180000, 320000, { minRoad: 5, rateScale: RS }), 120000);
          // Rebalanced: small dragon flyby — 120-240s (was 35-80s), self-gated by milestone
          setTimeout(() => loop(spawnDragon, 120000, 240000), 8000);
          setTimeout(() => loop(() => plantTreeBurst(false, 2, 250), 4000, 8500), 2000);
          setTimeout(() => loop(() => plantBackTreeBurst(false, Math.random() < 0.55 ? 1 : 2, 240), 5500, 12000), 2600);
          setTimeout(() => loop(() => plantHillTreeBurst(false, Math.random() < 0.65 ? 1 : 2, 220), 7000, 15000), 3200);
          setTimeout(() => loop(spawnLumberjack, 28000, 60000, { minRoad: 0, rateScale: RS }), 18000);
          setTimeout(() => loop(spawnLoneBuilder, 4500, 11000, { minRoad: 0, rateScale: RS }), 3500);
          // Realm is at peace — buildings are protected (no destruction loops)
          // Weather-aware cloud spawning — sparse when clear/cloudy; denser for rain/storm
          function cloudLoop() {
            if (!document.hidden) randomCloud();
            let min = 20000, max = 40000;
            if (weather === "cloudy") { min = 5500; max = 9000; }
            else if (weather === "rain")  { min = 2500; max = 4500; }
            else if (weather === "storm") { min = 1800; max = 3000; }
            setTimeout(cloudLoop, min + Math.random() * (max - min));
          }
          setTimeout(cloudLoop, 1000);
          // New loops
          // Sheep no longer spawn alone — only with the shepherd
          setTimeout(() => loop(spawnDog, 60000, 120000, { minRoad: 2, rateScale: RS }), 22000);
          setTimeout(() => loop(spawnBandit, 70000, 150000, { minRoad: 1, rateScale: RS }), 50000);
          setTimeout(() => loop(plantCropPatch, 50000, 100000, { minRoad: 2, rateScale: RS }), 25000);
          setTimeout(() => loop(spawnWedding, 150000, 280000, { minRoad: 2, rateScale: RS }), 65000);
          setTimeout(() => loop(spawnRoyalCastle, 280000, 480000, { minRoad: 4, rateScale: RS }), 140000);
          setTimeout(() => loop(spawnSkyWizard, 60000, 130000, { minRoad: 4, rateScale: RS }), 25000);
          setTimeout(() => loop(spawnFlyingCastle, 200000, 360000, { minRoad: 4, rateScale: RS }), 70000);
          setTimeout(() => loop(spawnAdventurerCamp, 70000, 140000, { minRoad: 1, rateScale: RS }), 20000);
          setTimeout(() => loop(maybeSolarHalo, 260000, 480000), 95000);
          setTimeout(() => loop(spawnShepherdFlock, 110000, 200000), 38000);
          setTimeout(() => loop(spawnUpgrader, 14000, 32000), 7000);
          // checkDevelopment / huge dragon disabled — the realm has been declared invulnerable
          setTimeout(() => loop(tryUpgradeRoad, 35000, 80000), 18000);
          setTimeout(() => loop(spawnCamelCaravan, 95000, 180000, { minRoad: 3, rateScale: RS }), 55000);
          // NEW: marketstalls + guard posts
          setTimeout(() => loop(spawnStallBuilder, 10000, 20000, { minRoad: 1, rateScale: RS }), 12000);
          setTimeout(() => loop(spawnGuardpostBuilder, 40000, 90000, { minRoad: 3, rateScale: RS }), 50000);
          setTimeout(ambientParticleLoop, 1800);
          setTimeout(skyLifeLoop, 2600);
          setTimeout(microLoop, 4200);
        }

        // Snapshot the live simulation for the page. DOM writes only happen when counts change.
        const realmBuildings = document.getElementById("realm-buildings");
        const realmTrees = document.getElementById("realm-trees");
        const realmRoad = document.getElementById("realm-road");
        function updateRealmStats() {
          if (document.hidden) return;
          const values = [
            [realmBuildings, String(houses.filter((h) => h.stage >= 2).length)],
            [realmTrees, String(trees.length + backTrees.length + hillTrees.length)],
            [realmRoad, ROAD_NAMES[Number(world.dataset.road) || 0]],
          ];
          for (const [el, value] of values) {
            if (el && el.textContent !== value) el.textContent = value;
          }
        }
        updateRealmStats();
        _setInterval(updateRealmStats, 1800);
      })();

      // Discord copy-to-clipboard
      (function () {
        const btn = document.getElementById("discord-btn");
        if (!btn) return;
        const orig = btn.innerHTML;
        btn.addEventListener("click", () => {
          navigator.clipboard && navigator.clipboard.writeText("step_dev");
          btn.innerHTML = '<span class="ico">✓</span>copied!';
          setTimeout(() => { btn.innerHTML = orig; }, 1500);
        });
      })();

      // LVL = current age. Bio "Six years" = floor(career-months / 12), as an English word.
      (function () {
        const now = new Date();
        const yearEl = document.getElementById("footer-year");
        if (yearEl) yearEl.textContent = String(now.getFullYear());

        const birth = new Date(2002, 4, 12);
        const bdayThisYear = new Date(now.getFullYear(), birth.getMonth(), birth.getDate());
        let age = now.getFullYear() - birth.getFullYear();
        if (now < bdayThisYear) age--;
        const lvlEl = document.getElementById("player-level");
        if (lvlEl) lvlEl.textContent = age;

        const careerStart = new Date(2019, 10, 1);
        const months =
          (now.getFullYear() - careerStart.getFullYear()) * 12 +
          (now.getMonth() - careerStart.getMonth());
        const years = Math.floor(months / 12);
        const words = ["zero","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen","twenty"];
        const word = words[years] ? words[years].replace(/^./, c => c.toUpperCase()) : String(years);
        const yEl = document.getElementById("years-at-rockbite");
        if (yEl) yEl.textContent = word;
      })();
